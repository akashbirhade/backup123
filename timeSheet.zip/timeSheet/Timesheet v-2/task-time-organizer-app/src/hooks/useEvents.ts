
import { useState, useEffect } from 'react';

interface Event {
  id: string;
  name: string;
  date: string;
  type: 'holiday' | 'half-day' | 'event';
  description?: string;
  isRecurring: boolean;
  createdAt: string;
}

export const useEvents = () => {
  const [events, setEvents] = useState<Event[]>([]);

  // Load events from localStorage on mount
  useEffect(() => {
    const savedEvents = localStorage.getItem('adminEvents');
    if (savedEvents) {
      try {
        const parsedEvents = JSON.parse(savedEvents);
        setEvents(parsedEvents);
      } catch (error) {
        console.error('Error parsing saved events:', error);
        setEvents(getDefaultEvents());
      }
    } else {
      setEvents(getDefaultEvents());
    }
  }, []);

  // Save events to localStorage whenever events change
  useEffect(() => {
    localStorage.setItem('adminEvents', JSON.stringify(events));
  }, [events]);

  const getDefaultEvents = (): Event[] => [
    {
      id: '1',
      name: 'New Year Day',
      date: '2025-01-01',
      type: 'holiday',
      description: 'Public Holiday',
      isRecurring: true,
      createdAt: '2025-01-01T00:00:00Z'
    },
    {
      id: '2',
      name: 'Independence Day',
      date: '2025-08-15',
      type: 'holiday',
      description: 'National Holiday',
      isRecurring: true,
      createdAt: '2025-01-01T00:00:00Z'
    }
  ];

  const addEvent = (event: Omit<Event, 'id' | 'createdAt'>) => {
    const newEvent: Event = {
      ...event,
      id: `event_${Date.now()}`,
      createdAt: new Date().toISOString()
    };
    setEvents(prev => [...prev, newEvent]);
    return newEvent;
  };

  const updateEvent = (id: string, updates: Partial<Event>) => {
    setEvents(prev => prev.map(event => 
      event.id === id ? { ...event, ...updates } : event
    ));
  };

  const deleteEvent = (id: string) => {
    setEvents(prev => prev.filter(event => event.id !== id));
  };

  const getEventsForDateRange = (startDate: Date, endDate: Date): Event[] => {
    const currentYear = new Date().getFullYear();
    
    return events.filter(event => {
      const eventDate = new Date(event.date);
      
      // For recurring events, check if the event occurs in the current year within the date range
      if (event.isRecurring) {
        const recurringDate = new Date(currentYear, eventDate.getMonth(), eventDate.getDate());
        return recurringDate >= startDate && recurringDate <= endDate;
      }
      
      // For non-recurring events, check the exact date
      return eventDate >= startDate && eventDate <= endDate;
    });
  };

  return {
    events,
    addEvent,
    updateEvent,
    deleteEvent,
    getEventsForDateRange
  };
};
