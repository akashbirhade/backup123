
import React from 'react';
import { format } from 'date-fns';
import DateRangePicker from '@/components/DateRangePicker';
import { Badge } from '@/components/ui/badge';

interface TimesheetHeaderProps {
  employeeName: string;
  startDate: Date;
  endDate: Date;
  isAdmin: boolean;
  onDateChange: (start: Date, end: Date) => void;
}

const TimesheetHeader: React.FC<TimesheetHeaderProps> = ({
  employeeName,
  startDate,
  endDate,
  isAdmin,
  onDateChange
}) => {
  return (
    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Weekly Timesheet</h1>
        <p className="text-muted-foreground">
          {employeeName} - {format(startDate, "MMM d")} to {format(endDate, "MMM d, yyyy")}
        </p>
        {isAdmin && (
          <div className="mt-1">
            <Badge variant="outline" className="bg-primary/10">
              Viewing as Admin
            </Badge>
          </div>
        )}
      </div>
      <DateRangePicker onDateChange={onDateChange} />
    </div>
  );
};

export default TimesheetHeader;
