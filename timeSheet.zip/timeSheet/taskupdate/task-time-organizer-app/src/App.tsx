
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Layout from "./components/Layout";
import Dashboard from "./pages/Dashboard";
import Timesheet from "./pages/Timesheet";
import Calendar from "./pages/Calendar";
import Projects from "./pages/Projects";
import Reports from "./pages/Reports";
import Profile from "./pages/Profile";
import Settings from "./pages/Settings";
import NotFound from "./pages/NotFound";
import Login from "./pages/Login";
import AdminDashboard from "./pages/AdminDashboard";
import { AuthProvider, useAuth } from "./context/AuthContext";
import AuthGuard from "./components/AuthGuard";
import CompanyHolidays from "./pages/CompanyHolidays";

const queryClient = new QueryClient();

const AppRoutes = () => {
  const { user } = useAuth();
  
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      
      {/* Protected routes */}
      <Route 
        path="/" 
        element={
          <AuthGuard>
            <Layout>
              {user?.role === 'admin' ? <AdminDashboard /> : <Dashboard />}
            </Layout>
          </AuthGuard>
        } 
      />
      <Route 
        path="/calendar" 
        element={
          <AuthGuard>
            <Layout><Calendar /></Layout>
          </AuthGuard>
        } 
      />
      <Route 
        path="/timesheet" 
        element={
          <AuthGuard>
            <Layout><Timesheet /></Layout>
          </AuthGuard>
        } 
      />
      <Route 
        path="/projects" 
        element={
          <AuthGuard>
            <Layout><Projects /></Layout>
          </AuthGuard>
        } 
      />
      <Route 
        path="/reports" 
        element={
          <AuthGuard allowedRoles={['admin']}>
            <Layout><Reports /></Layout>
          </AuthGuard>
        } 
      />
      <Route 
        path="/company-holidays" 
        element={
          <AuthGuard allowedRoles={['admin']}>
            <Layout><CompanyHolidays /></Layout>
          </AuthGuard>
        } 
      />
      <Route 
        path="/profile" 
        element={
          <AuthGuard>
            <Layout><Profile /></Layout>
          </AuthGuard>
        } 
      />
      <Route 
        path="/settings" 
        element={
          <AuthGuard>
            <Layout><Settings /></Layout>
          </AuthGuard>
        } 
      />
      
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <AuthProvider>
        <BrowserRouter>
          <AppRoutes />
          <Toaster />
          <Sonner />
        </BrowserRouter>
      </AuthProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
