import React, { useRef } from 'react';
import { HotTable } from '@handsontable/react';
import 'handsontable/dist/handsontable.full.min.css';
import axios from 'axios';
import Handsontable from 'handsontable';
import { registerCellType, DateCellType } from 'handsontable/cellTypes';

registerCellType(DateCellType);

const TaskSpreadsheet = () => {
  const hotRef = useRef(null);

  const columns = [
    { data: 'taskId', type: 'text' },
    { data: 'task', type: 'text' },
    { data: 'description', type: 'text' },
    { data: 'accountable', type: 'text' },
    { data: 'assigner', type: 'text' },
    { data: 'uiAssignedTo', type: 'text' },
    { data: 'uiAssignedDate', type: 'date', dateFormat: 'DD-MM-YYYY', correctFormat: true },
  ];

  const data = [
    { taskId: 'impjob72401', task: 'General Tab', description: '', accountable: 'ashish', assigner: 'ashish', uiAssignedTo: '', uiAssignedDate: '' },
    { taskId: 'impjob72402', task: 'Shipment Tab', description: 'Add remaining field in imp_ship_container', accountable: 'ashish', assigner: 'ashish', uiAssignedTo: 'aakash', uiAssignedDate: '18-07-2024' },
  ];

  const handleAfterChange = async (changes, source) => {
    if (source === 'loadData' || !changes) return;
    console.log('Changes:', changes);

    // Example: API call for each changed cell
    for (const [row, prop, oldValue, newValue] of changes) {
      const updatedRow = hotRef.current.hotInstance.getSourceDataAtRow(row);
      try {
        await axios.post('https://yourapi.com/update-task', updatedRow);
        console.log('Row updated successfully:', updatedRow);
      } catch (err) {
        console.error('Error updating row:', err);
      }
    }
  };

  return (
    <div>
      <HotTable
        ref={hotRef}
        data={data}
        colHeaders={['Task ID', 'Task', 'Description', 'Accountable', 'Assigner', 'UI Assigned To', 'UI Assigned Date']}
        columns={columns}
        licenseKey="non-commercial-and-evaluation"
        stretchH="all"
        rowHeaders={true}
        width="100%"
        height="500px"
        afterChange={handleAfterChange}
      />
    </div>
  );
};

export default TaskSpreadsheet;
