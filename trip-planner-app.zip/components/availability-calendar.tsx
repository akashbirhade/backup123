"use client"

import { useState } from "react"
import { Calendar } from "@/components/ui/calendar"
import { cn } from "@/lib/utils"

export function AvailabilityCalendar({ bookedDates = [], className }) {
  const [month, setMonth] = useState(new Date())

  // Function to determine if a date is booked
  const isDateBooked = (date) => {
    if (!date || !Array.isArray(bookedDates)) return false

    return bookedDates.some((bookedDateStr) => {
      try {
        const bookingDate = new Date(bookedDateStr)

        // Check if the date is valid before comparing
        if (isNaN(bookingDate.getTime())) return false

        return (
          date.getDate() === bookingDate.getDate() &&
          date.getMonth() === bookingDate.getMonth() &&
          date.getFullYear() === bookingDate.getFullYear()
        )
      } catch (error) {
        // If there's any error parsing the date, skip this comparison
        return false
      }
    })
  }

  // Custom day renderer
  const renderDay = (day, selectedDays, dayProps) => {
    // Make sure day is a valid date object
    if (!day || !(day instanceof Date)) {
      return <div {...dayProps}>{dayProps.children}</div>
    }

    const isBooked = isDateBooked(day)

    return (
      <div
        {...dayProps}
        className={cn(dayProps.className, "relative", isBooked && "bg-red-100 text-red-900 hover:bg-red-200")}
      >
        {day.getDate()}
        {isBooked && <div className="absolute bottom-0 left-0 right-0 h-1 bg-red-500"></div>}
      </div>
    )
  }

  return (
    <div className={cn("p-3 bg-white rounded-md border", className)}>
      <div className="mb-4">
        <h3 className="text-lg font-medium mb-2">Availability</h3>
        <div className="flex items-center text-sm">
          <div className="flex items-center mr-4">
            <div className="w-3 h-3 bg-emerald-100 border border-emerald-500 rounded-sm mr-1"></div>
            <span>Available</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 bg-red-100 border border-red-500 rounded-sm mr-1"></div>
            <span>Booked</span>
          </div>
        </div>
      </div>

      <Calendar
        mode="single"
        month={month}
        onMonthChange={setMonth}
        className="rounded-md border"
        components={{
          Day: ({ day, selectedDays, ...props }) => renderDay(day, selectedDays, props),
        }}
      />
    </div>
  )
}
