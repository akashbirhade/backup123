
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/context/AuthContext';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { UserCog, Calendar as CalendarIcon, ClipboardList } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

// Mock employee data
const EMPLOYEES = [
  {
    id: 'e1',
    name: 'Akash Birhade',
    email: 'employee@example.com',
    department: 'Engineering',
    position: 'Software Engineer',
    joinDate: '2023-01-15',
    totalHours: 160,
    pendingTimesheets: 0,
    avatarUrl: ''
  },
  {
    id: 'e2',
    name: 'John Doe',
    email: 'john@example.com',
    department: 'Design',
    position: 'UX Designer',
    joinDate: '2023-02-10',
    totalHours: 155,
    pendingTimesheets: 1,
    avatarUrl: ''
  },
  {
    id: 'e3',
    name: 'Jane Smith',
    email: 'jane@example.com',
    department: 'Product',
    position: 'Product Manager',
    joinDate: '2023-03-05',
    totalHours: 162,
    pendingTimesheets: 2,
    avatarUrl: ''
  }
];

const AdminDashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('employees');

  const viewEmployeeTimesheet = (employeeId: string) => {
    navigate(`/timesheet?employeeId=${employeeId}`);
  };

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Admin Dashboard</h1>
          <p className="text-muted-foreground">
            Welcome back, {user?.name}! Manage your team's timesheets and records.
          </p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-4">
          <TabsTrigger value="employees" className="flex items-center gap-2">
            <UserCog className="h-4 w-4" /> Employees
          </TabsTrigger>
          <TabsTrigger value="timesheets" className="flex items-center gap-2">
            <ClipboardList className="h-4 w-4" /> Timesheets
          </TabsTrigger>
        </TabsList>

        <TabsContent value="employees">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {EMPLOYEES.map((employee) => (
              <Card key={employee.id} className="overflow-hidden">
                <CardHeader className="bg-primary/5 pb-4">
                  <div className="flex items-center gap-4">
                    <Avatar className="h-16 w-16 border-2 border-white">
                      <AvatarImage src={employee.avatarUrl} />
                      <AvatarFallback className="text-xl">
                        {employee.name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <CardTitle>{employee.name}</CardTitle>
                      <CardDescription>{employee.position}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="grid gap-3">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Department:</span>
                      <span className="font-medium">{employee.department}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Email:</span>
                      <span className="font-medium">{employee.email}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Hours this month:</span>
                      <span className="font-medium">{employee.totalHours}h</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Pending Timesheets:</span>
                      <span className={`font-medium ${employee.pendingTimesheets > 0 ? 'text-orange-500' : 'text-green-500'}`}>
                        {employee.pendingTimesheets}
                      </span>
                    </div>

                    <div className="mt-4 flex gap-2">
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="flex-1" 
                        onClick={() => viewEmployeeTimesheet(employee.id)}
                      >
                        <ClipboardList className="h-4 w-4 mr-2" />
                        View Timesheet
                      </Button>
                      <Button size="sm" variant="outline" className="flex-1">
                        <CalendarIcon className="h-4 w-4 mr-2" />
                        Calendar
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="timesheets">
          <Card>
            <CardHeader>
              <CardTitle>Pending Approvals</CardTitle>
              <CardDescription>Timesheets requiring your review and approval</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="border rounded-md overflow-hidden">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-muted/50">
                      <th className="py-3 px-4 text-left font-medium">Employee</th>
                      <th className="py-3 px-4 text-left font-medium">Week</th>
                      <th className="py-3 px-4 text-left font-medium">Total Hours</th>
                      <th className="py-3 px-4 text-left font-medium">Status</th>
                      <th className="py-3 px-4 text-center font-medium">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-t">
                      <td className="py-3 px-4">John Doe</td>
                      <td className="py-3 px-4">May 1 - May 7, 2025</td>
                      <td className="py-3 px-4">38.5</td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-1 text-xs rounded-full bg-yellow-100 text-yellow-800">
                          Pending
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex justify-center gap-2">
                          <Button size="sm" variant="outline">Review</Button>
                        </div>
                      </td>
                    </tr>
                    <tr className="border-t">
                      <td className="py-3 px-4">Jane Smith</td>
                      <td className="py-3 px-4">May 1 - May 7, 2025</td>
                      <td className="py-3 px-4">40</td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-1 text-xs rounded-full bg-yellow-100 text-yellow-800">
                          Pending
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex justify-center gap-2">
                          <Button size="sm" variant="outline">Review</Button>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdminDashboard;
