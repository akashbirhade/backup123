
import React from 'react';

const Logo = () => {
  return (
    <div className="flex items-center gap-2">
      <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center text-white font-bold">
        P
      </div>
      <span className="font-bold text-primary text-xl">PERISCOPE</span>
    </div>
  );
};

export default Logo;
