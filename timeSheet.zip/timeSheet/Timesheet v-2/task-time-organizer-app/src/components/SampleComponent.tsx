import React, { useEffect, useState } from 'react';
import { usersApi, reportsApi } from '@/integrations/api/client';
import { User, Report } from '@/integrations/api/types';
import TaskSpreadsheet from '@/components/TaskSpreadsheet';
import EmployeeGrid from './EmployeeGrid';

const SampleComponent: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [performance, setPerformance] = useState<Record<number, Report['summary']>>({});

  useEffect(() => {
    const fetchUsersAndPerformance = async () => {
      setLoading(true);
      const usersRes = await usersApi.getUsers();
      if (usersRes.success && usersRes.data) {
        setUsers(usersRes.data);
        // Fetch performance for each user (last 30 days)
        const endDate = new Date();
        const startDate = new Date();
        startDate.setDate(endDate.getDate() - 30);
        const perf: Record<number, Report['summary']> = {};
        await Promise.all(usersRes.data.map(async (user) => {
          const reportRes = await reportsApi.generateReport('weekly', {
            startDate: startDate.toISOString().slice(0, 10),
            endDate: endDate.toISOString().slice(0, 10),
            userId: user.id,
          });
          if (reportRes.success && reportRes.data) {
            perf[user.id] = reportRes.data.summary;
          }
        }));
        setPerformance(perf);
      }
      setLoading(false);
    };
    fetchUsersAndPerformance();
  }, []);

  if (loading) return <div>Loading employees...</div>;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Sample Component</h1>
        <p className="text-muted-foreground">
          Sample Component
        </p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
       
      </div>
      {/* Task Spreadsheet below employee grid */}
      <div className="mt-10">
        <h3 className="text-lg font-semibold mb-2">Task Spreadsheet</h3>
        <TaskSpreadsheet />
        <EmployeeGrid/>
      </div>
    </div>
  );
};

export default SampleComponent;
