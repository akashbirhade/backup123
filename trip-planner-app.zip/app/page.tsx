import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Globe, DollarSign, Compass, MapPin, Check } from "lucide-react"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section with Search */}
      <header className="bg-gradient-to-r from-teal-500 to-emerald-600 text-white">
        <div className="container mx-auto px-4 py-16 md:py-24">
          <div className="max-w-3xl mx-auto text-center mb-8">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">Plan Your Perfect Trip with AI</h1>
            <p className="text-xl md:text-2xl mb-8">
              Personalized travel itineraries based on your preferences, budget, and destination
            </p>
          </div>

          {/* Search Form */}
          <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-lg p-6">
            <div className="grid md:grid-cols-3 gap-4">
              <div>
                <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-1">
                  Location
                </label>
                <select
                  id="location"
                  className="w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
                >
                  <option value="">Select destination</option>
                  <option value="paris">Paris, France</option>
                  <option value="bali">Bali, Indonesia</option>
                  <option value="tokyo">Tokyo, Japan</option>
                  <option value="newyork">New York, USA</option>
                  <option value="rome">Rome, Italy</option>
                </select>
              </div>
              <div>
                <label htmlFor="dates" className="block text-sm font-medium text-gray-700 mb-1">
                  Dates
                </label>
                <input
                  type="text"
                  id="dates"
                  placeholder="Check-in — Check-out"
                  className="w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
                />
              </div>
              <div className="flex items-end">
                <Link href="/properties" className="w-full">
                  <Button size="lg" className="w-full bg-emerald-600 hover:bg-emerald-700">
                    Search Properties
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">How It Works</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <FeatureCard
              icon={<Globe className="h-10 w-10 text-emerald-500" />}
              title="Choose Your Destination"
              description="Select where you want to go and when you plan to travel"
            />
            <FeatureCard
              icon={<DollarSign className="h-10 w-10 text-emerald-500" />}
              title="Set Your Budget"
              description="Tell us how much you want to spend on your adventure"
            />
            <FeatureCard
              icon={<Compass className="h-10 w-10 text-emerald-500" />}
              title="Get AI Recommendations"
              description="Receive a personalized itinerary with places to visit, eat, and stay"
            />
          </div>
        </div>
      </section>

      {/* Featured Properties Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold">Featured Properties</h2>
            <div className="flex items-center">
              <span className="mr-2 text-sm">Currency:</span>
              <select className="rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500 text-sm">
                <option value="USD">USD ($)</option>
                <option value="EUR">EUR (€)</option>
                <option value="GBP">GBP (£)</option>
                <option value="JPY">JPY (¥)</option>
                <option value="INR">INR (₹)</option>
              </select>
            </div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <PropertyCard
              image="/placeholder.svg?height=200&width=350"
              title="Luxury Villa with Pool"
              location="Bali, Indonesia"
              price="$120"
              rating={4.9}
              reviews={128}
            />
            <PropertyCard
              image="/placeholder.svg?height=200&width=350"
              title="Eiffel Tower Apartment"
              location="Paris, France"
              price="$95"
              rating={4.7}
              reviews={84}
            />
            <PropertyCard
              image="/placeholder.svg?height=200&width=350"
              title="Beachfront Cottage"
              location="Santorini, Greece"
              price="$150"
              rating={4.8}
              reviews={112}
            />
            <PropertyCard
              image="/placeholder.svg?height=200&width=350"
              title="Mountain Cabin"
              location="Aspen, Colorado"
              price="$85"
              rating={4.6}
              reviews={76}
            />
            <PropertyCard
              image="/placeholder.svg?height=200&width=350"
              title="Historic City Loft"
              location="Rome, Italy"
              price="$110"
              rating={4.5}
              reviews={92}
            />
            <PropertyCard
              image="/placeholder.svg?height=200&width=350"
              title="Seaside Resort Room"
              location="Cancun, Mexico"
              price="$130"
              rating={4.7}
              reviews={104}
            />
          </div>

          <div className="text-center mt-8">
            <Link href="/properties">
              <Button variant="outline" className="border-emerald-600 text-emerald-600 hover:bg-emerald-50">
                View All Properties
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose Our Planner</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <BenefitCard title="AI-Powered Planning" description="Smart algorithms that understand your travel style" />
            <BenefitCard
              title="Optimized Routes"
              description="Efficient paths to see everything without wasting time"
            />
            <BenefitCard title="Local Insights" description="Discover hidden gems and authentic experiences" />
            <BenefitCard title="Customizable Itineraries" description="Easily adjust plans to match your preferences" />
          </div>
        </div>
      </section>

      {/* Host Your Property Section */}
      <section className="py-16 bg-emerald-50">
        <div className="container mx-auto px-4">
          <div className="md:flex items-center justify-between">
            <div className="md:w-1/2 mb-8 md:mb-0">
              <h2 className="text-3xl font-bold mb-4">Become a Host</h2>
              <p className="text-lg mb-6 max-w-md">
                List your property on our platform and earn extra income by hosting travelers from around the world.
              </p>
              <Link href="/host">
                <Button className="bg-emerald-600 hover:bg-emerald-700">List Your Property</Button>
              </Link>
            </div>
            <div className="md:w-1/2">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-xl font-semibold mb-4">Why Host with Us?</h3>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <div className="bg-emerald-100 rounded-full p-1 mr-3 mt-0.5">
                      <Check className="h-4 w-4 text-emerald-600" />
                    </div>
                    <span>Reach millions of potential guests</span>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-emerald-100 rounded-full p-1 mr-3 mt-0.5">
                      <Check className="h-4 w-4 text-emerald-600" />
                    </div>
                    <span>Set your own availability and house rules</span>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-emerald-100 rounded-full p-1 mr-3 mt-0.5">
                      <Check className="h-4 w-4 text-emerald-600" />
                    </div>
                    <span>Secure payments and host protection</span>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-emerald-100 rounded-full p-1 mr-3 mt-0.5">
                      <Check className="h-4 w-4 text-emerald-600" />
                    </div>
                    <span>24/7 customer support</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-emerald-50">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready for Your Next Adventure?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Create your personalized travel plan in minutes and explore the world with confidence
          </p>
          <Link href="/create-trip">
            <Button size="lg" className="bg-emerald-600 text-white hover:bg-emerald-700">
              Create Your Trip Plan
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto bg-gray-800 text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <p>© {new Date().getFullYear()} AI Trip Planner. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}

function FeatureCard({ icon, title, description }) {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md text-center">
      <div className="flex justify-center mb-4">{icon}</div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  )
}

function BenefitCard({ title, description }) {
  return (
    <div className="border border-gray-200 p-6 rounded-lg hover:shadow-md transition-shadow">
      <h3 className="text-lg font-semibold mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  )
}

function PropertyCard({ image, title, location, price, rating, reviews }) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <div className="relative h-48 w-full">
        <img src={image || "/placeholder.svg"} alt={title} className="w-full h-full object-cover" />
        <div className="absolute top-3 right-3 bg-white rounded-full px-2 py-1 text-xs font-medium text-emerald-600">
          Featured
        </div>
      </div>
      <div className="p-4">
        <h3 className="font-semibold text-lg mb-1">{title}</h3>
        <p className="text-gray-600 text-sm mb-2 flex items-center">
          <MapPin className="h-3 w-3 mr-1" />
          {location}
        </p>
        <div className="flex justify-between items-center">
          <div className="font-medium">
            {price} <span className="text-gray-500 text-sm">/ night</span>
          </div>
          <div className="flex items-center text-sm">
            <span className="text-amber-500 mr-1">★</span>
            <span>{rating}</span>
            <span className="text-gray-500 ml-1">({reviews})</span>
          </div>
        </div>
      </div>
    </div>
  )
}
