
import React from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const Projects = () => {
  // Dummy data for projects
  const projects = [
    { 
      id: 'p1',
      name: 'Project Alpha', 
      client: 'Client A',
      status: 'active',
      startDate: '2025-01-15',
      endDate: '2025-06-30',
      budget: 240,
      used: 180,
    },
    { 
      id: 'p2',
      name: 'Project Beta', 
      client: 'Client B',
      status: 'active',
      startDate: '2025-03-01',
      endDate: '2025-08-15',
      budget: 160,
      used: 64,
    },
    { 
      id: 'p3',
      name: 'Project Gamma', 
      client: 'Client A',
      status: 'active',
      startDate: '2025-02-15',
      endDate: '2025-05-30',
      budget: 120,
      used: 98,
    },
    { 
      id: 'p4',
      name: 'Project Delta', 
      client: 'Client C',
      status: 'upcoming',
      startDate: '2025-05-15',
      endDate: '2025-09-30',
      budget: 200,
      used: 0,
    },
    { 
      id: 'p5',
      name: 'Project Epsilon', 
      client: 'Client B',
      status: 'completed',
      startDate: '2024-10-01',
      endDate: '2025-03-31',
      budget: 180,
      used: 175,
    },
  ];

  const renderStatus = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-500">Active</Badge>;
      case 'completed':
        return <Badge variant="secondary">Completed</Badge>;
      case 'upcoming':
        return <Badge className="bg-blue-500">Upcoming</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Projects</h1>
        <p className="text-muted-foreground">
          Overview of all projects and their hour allocations
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Projects</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Project Name</TableHead>
                <TableHead>Client</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Start Date</TableHead>
                <TableHead>End Date</TableHead>
                <TableHead className="text-right">Hours Budget</TableHead>
                <TableHead className="text-right">Hours Used</TableHead>
                <TableHead className="text-right">Remaining</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {projects.map((project) => {
                const remaining = project.budget - project.used;
                const percentUsed = ((project.used / project.budget) * 100).toFixed(1);
                
                return (
                  <TableRow key={project.id}>
                    <TableCell className="font-medium">{project.name}</TableCell>
                    <TableCell>{project.client}</TableCell>
                    <TableCell>{renderStatus(project.status)}</TableCell>
                    <TableCell>{project.startDate}</TableCell>
                    <TableCell>{project.endDate}</TableCell>
                    <TableCell className="text-right">{project.budget} hrs</TableCell>
                    <TableCell className="text-right">{project.used} hrs ({percentUsed}%)</TableCell>
                    <TableCell className={`text-right font-medium ${
                      remaining < 0 ? 'text-red-600' : 
                      remaining < project.budget * 0.2 ? 'text-amber-600' : 
                      'text-green-600'
                    }`}>
                      {remaining} hrs
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};

export default Projects;
