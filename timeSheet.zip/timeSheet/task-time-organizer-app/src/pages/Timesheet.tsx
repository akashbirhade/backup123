import React, { useState, useEffect } from 'react';
import { addDays, format } from 'date-fns';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import DateRangePicker from '@/components/DateRangePicker';
import TimeEntry from '@/components/TimeEntry';
import { Timesheet as TimesheetType, Project, Task } from '@/types/timesheet';
import { Plus, Save, Edit, Check } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';

// Dummy data for projects
const dummyProjects = [
  { id: 'p1', name: 'Project Alpha', clientId: 'c1', clientName: 'Client A' },
  { id: 'p2', name: 'Project Beta', clientId: 'c2', clientName: 'Client B' },
  { id: 'p3', name: 'Project Gamma', clientId: 'c1', clientName: 'Client A' },
  { id: 'p4', name: 'Project Delta', clientId: 'c3', clientName: 'Client C' },
];

const Timesheet = () => {
  const [startDate, setStartDate] = useState<Date>(new Date());
  const [endDate, setEndDate] = useState<Date>(new Date());
  const [days, setDays] = useState<Date[]>([]);
  const [timesheet, setTimesheet] = useState<TimesheetType | null>(null);
  const [selectedProject, setSelectedProject] = useState<string>('');
  const [newTaskDescription, setNewTaskDescription] = useState<string>('');
  const [editingTask, setEditingTask] = useState<string | null>(null);
  const [editedTaskDescription, setEditedTaskDescription] = useState<string>('');


  const dayStatusOptions = [
  { value: '', label: 'None', color: '' },
  { value: 'wfh', label: 'WFH', color: 'bg-blue-100 text-blue-800' },
  { value: 'leave', label: 'Leave', color: 'bg-red-100 text-red-800' },
  { value: 'halfday', label: 'Half Day', color: 'bg-yellow-100 text-yellow-800' },
  { value: 'holiday', label: 'Holiday', color: 'bg-gray-200 text-gray-700' },
];

const [dayStatus, setDayStatus] = useState<string[]>([]);

// Update dayStatus when days change
useEffect(() => {
  setDayStatus(Array(days.length).fill(''));
}, [days.length]);

// Helper to get color class
const getStatusColor = (status: string) => {
  return dayStatusOptions.find(opt => opt.value === status)?.color || '';
};

  // Generate day headers
  useEffect(() => {
    if (startDate && endDate) {
      const daysList = [];
      let currentDay = new Date(startDate);
      while (currentDay <= endDate) {
        daysList.push(new Date(currentDay));
        currentDay = addDays(currentDay, 1);
      }
      setDays(daysList);
    }
  }, [startDate, endDate]);

  // Initialize or update timesheet
  useEffect(() => {
    if (startDate && endDate) {
      // In a real app, you'd load from an API
      const initialTimesheet: TimesheetType = {
        id: 'ts1',
        employeeId: 'e1',
        employeeName: 'Akash Birhade',
        weekStarting: startDate,
        weekEnding: endDate,
        projects: [
          {
            id: 'p1',
            name: 'Project Alpha',
            clientId: 'c1',
            clientName: 'Client A',
            tasks: [
              {
                id: 't1',
                projectId: 'p1',
                description: 'Creating UI for SMB Lead and review code structure',
                hours: ['8', '8', '8', '6', '4', '0', '0']
              },
              {
                id: 't2',
                projectId: 'p1',
                description: 'Meeting on Estimation',
                hours: ['0', '0', '0', '2', '0', '0', '0']
              },
              {
                id: 't3',
                projectId: 'p1',
                description: 'Estimation of model',
                hours: ['0', '0', '0', '0', '0', '4', '0']
              }
            ]
          }
        ],
        status: 'draft',
        totalHours: [8, 8, 8, 8, 4, 4, 0]
      };
      setTimesheet(initialTimesheet);
    }
  }, [startDate, endDate]);

  const handleDateChange = (start: Date, end: Date) => {
    setStartDate(start);
    setEndDate(end);
  };

  const handleHoursChange = (value: string, dayIndex: number, taskId: string) => {
    if (!timesheet) return;

    const updatedTimesheet = { ...timesheet };
    const numValue = value === '' ? '0' : value;

    // Update the hours for the specific task
    updatedTimesheet.projects = updatedTimesheet.projects.map(project => {
      const updatedTasks = project.tasks.map(task => {
        if (task.id === taskId) {
          const updatedHours = [...task.hours];
          updatedHours[dayIndex] = value;
          return { ...task, hours: updatedHours };
        }
        return task;
      });
      return { ...project, tasks: updatedTasks };
    });

    // Recalculate total hours for each day
    const totalDays = updatedTimesheet.totalHours.length;
    const newTotalHours = Array(totalDays).fill(0);

    updatedTimesheet.projects.forEach(project => {
      project.tasks.forEach(task => {
        task.hours.forEach((hourStr, idx) => {
          const hours = hourStr === '' ? 0 : parseFloat(hourStr);
          if (!isNaN(hours)) {
            newTotalHours[idx] += hours;
          }
        });
      });
    });

    updatedTimesheet.totalHours = newTotalHours;
    setTimesheet(updatedTimesheet);
  };

  const handleAddTask = () => {
    if (!selectedProject || !newTaskDescription || !timesheet) return;

    const projectToUpdate = timesheet.projects.find(p => p.id === selectedProject);
    
    if (!projectToUpdate) {
      // Project doesn't exist in timesheet yet, add it
      const projectData = dummyProjects.find(p => p.id === selectedProject);
      if (!projectData) return;
      
      const newProject: Project = {
        ...projectData,
        tasks: [
          {
            id: `t${Date.now()}`,
            projectId: selectedProject,
            description: newTaskDescription,
            hours: Array(days.length).fill('0')
          }
        ]
      };
      
      const updatedTimesheet = {
        ...timesheet,
        projects: [...timesheet.projects, newProject]
      };
      
      setTimesheet(updatedTimesheet);
    } else {
      // Project exists, just add the task
      const newTask: Task = {
        id: `t${Date.now()}`,
        projectId: selectedProject,
        description: newTaskDescription,
        hours: Array(days.length).fill('0')
      };
      
      const updatedTimesheet = {
        ...timesheet,
        projects: timesheet.projects.map(project => {
          if (project.id === selectedProject) {
            return {
              ...project,
              tasks: [...project.tasks, newTask]
            };
          }
          return project;
        })
      };
      
      setTimesheet(updatedTimesheet);
    }
    
    // Reset form
    setNewTaskDescription('');
  };

  const handleSubmitTimesheet = () => {
    // In a real app, you'd send to an API
    toast.success("Timesheet submitted successfully!");
    if (timesheet) {
      setTimesheet({
        ...timesheet,
        status: 'submitted'
      });
    }
  };

  const calculateWeeklyTotal = (taskHours: string[]) => {
    return taskHours.reduce((total, hours) => {
      return total + (hours === '' ? 0 : parseFloat(hours));
    }, 0);
  };

  const calculateTotalHours = () => {
    if (!timesheet) return 0;
    
    return timesheet.totalHours.reduce((sum, hours) => sum + hours, 0);
  };

  const handleEditDescription = (taskId: string, currentDescription: string) => {
    setEditingTask(taskId);
    setEditedTaskDescription(currentDescription);
  };

  const handleSaveDescription = (taskId: string) => {
    if (!timesheet) return;

    const updatedTimesheet = {
      ...timesheet,
      projects: timesheet.projects.map(project => ({
        ...project,
        tasks: project.tasks.map(task =>
          task.id === taskId
            ? { ...task, description: editedTaskDescription }
            : task
        ),
      })),
    };

    setTimesheet(updatedTimesheet);
    setEditingTask(null);
    toast.success("Task description updated!");
  };

  if (!timesheet) {
    return <div className="flex justify-center items-center h-64">Loading timesheet...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Weekly Timesheet</h1>
          <p className="text-muted-foreground">
            {timesheet.employeeName} - {format(startDate, "MMM d")} to {format(endDate, "MMM d, yyyy")}
          </p>
        </div>
        <DateRangePicker onDateChange={handleDateChange} />
      </div>

      <Card>
        <CardHeader className="bg-primary text-white">
          <CardTitle>Weekly Time Sheet</CardTitle>
        </CardHeader>

        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr>
                <th className="timesheet-header w-48 whitespace-nowrap">Client Name</th>
                <th className="timesheet-header w-48 whitespace-nowrap">Project Name</th>
                <th className="timesheet-header flex-1 whitespace-nowrap">JIRA Issue/Work Description</th>
                {days.map((day, i) => (
                  <th key={i} className="timesheet-header whitespace-nowrap">
                    <div>{format(day, "dd-MM-yyyy")}</div>
                    <div>{format(day, "EEEE")}</div>
                  </th>
                ))}
                <th className="timesheet-header whitespace-nowrap">Weekly Totals</th>
              </tr>
            </thead>
            <tbody>
                <tr>
    <td colSpan={3} className="p-2 border border-gray-300 font-bold text-right">
      Day Status
    </td>
    {days.map((day, i) => (
      <td key={i} className={`p-1 border border-gray-300`}>
        <select
          className={`w-full rounded px-1 py-0.5 text-xs ${getStatusColor(dayStatus[i])}`}
          value={dayStatus[i] || ''}
          onChange={e => {
            const newStatus = [...dayStatus];
            newStatus[i] = e.target.value;
            setDayStatus(newStatus);

            // Autofill 4 hours for half day
            if (e.target.value === 'halfday' && timesheet) {
              const updatedTimesheet = { ...timesheet };
              updatedTimesheet.projects = updatedTimesheet.projects.map(project => ({
                ...project,
                tasks: project.tasks.map(task => {
                  const updatedHours = [...task.hours];
                  updatedHours[i] = '4';
                  return { ...task, hours: updatedHours };
                }),
              }));
              // Update total hours for the day
              const newTotalHours = [...updatedTimesheet.totalHours];
              newTotalHours[i] = updatedTimesheet.projects.reduce((sum, project) =>
                sum + project.tasks.reduce((tSum, task) =>
                  tSum + (task.hours[i] === '' ? 0 : parseFloat(task.hours[i])), 0
                ), 0
              );
              updatedTimesheet.totalHours = newTotalHours;
              setTimesheet(updatedTimesheet);
            }
          }}
        >
          {dayStatusOptions.map(opt => (
            <option key={opt.value} value={opt.value}>{opt.label}</option>
          ))}
        </select>
      </td>
    ))}
    <td className="border border-gray-300"></td>
  </tr>


              {timesheet.projects.map((project) => (
                <React.Fragment key={project.id}>
                  {project.tasks.map((task, taskIndex) => (
                    <tr key={task.id} className="timesheet-row task-row">
                      {taskIndex === 0 && (
                        <>
                          <td
                            className="p-2 border border-gray-300 align-top whitespace-nowrap"
                            rowSpan={project.tasks.length}
                          >
                            {project.clientName}
                          </td>
                          <td
                            className="p-2 border border-gray-300 align-top whitespace-nowrap"
                            rowSpan={project.tasks.length}
                          >
                            {project.name}
                          </td>
                        </>
                      )}
                      <td className="p-2 border border-gray-300">
                        {editingTask === task.id ? (
                          <div className="flex items-center gap-2">
                            <Textarea
                              value={editedTaskDescription}
                              onChange={(e) => setEditedTaskDescription(e.target.value)}
                              className="min-h-[40px] text-sm resize-none p-1"
                              rows={2}
                            />
                            <Button 
                              size="sm" 
                              variant="ghost" 
                              onClick={() => handleSaveDescription(task.id)}
                              className="h-8 w-8 p-0"
                            >
                              <Check className="h-4 w-4" />
                            </Button>
                          </div>
                        ) : (
                          <div className="flex justify-between items-center group">
                            <span>{task.description}</span>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleEditDescription(task.id, task.description)}
                              className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                              disabled={timesheet.status !== 'draft'}
                            >
                              <Edit className="h-3 w-3" />
                            </Button>
                          </div>
                        )}
                      </td>
                      {task.hours.map((hour, dayIndex) => (
                        <td key={dayIndex} className="time-cell">
                          <TimeEntry
                            value={hour}
                            day={dayIndex}
                            taskId={task.id}
                            onChange={handleHoursChange}
                            disabled={timesheet.status !== 'draft'}
                          />
                        </td>
                      ))}
                      <td className="time-cell font-semibold">
                        {calculateWeeklyTotal(task.hours)}
                      </td>
                    </tr>
                  ))}
                </React.Fragment>
              ))}

              <tr className="bg-gray-100">
                <td colSpan={3} className="p-2 border border-gray-300 text-right font-bold">
                  Total Daily Hours
                </td>
                {timesheet.totalHours.map((total, i) => (
                  <td key={i} className="time-cell font-bold border border-gray-300">
                    {total}
                  </td>
                ))}
                <td className="time-cell font-bold border border-gray-300">
                  {calculateTotalHours()}
                </td>
              </tr>
            </tbody>
          </table>
        </CardContent>

        
        <CardFooter className="flex flex-col md:flex-row gap-4 p-4 items-start">
          <div className="flex flex-1 flex-col sm:flex-row gap-2 w-full">
            <Select value={selectedProject} onValueChange={setSelectedProject}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="Select Project" />
              </SelectTrigger>
              <SelectContent>
                {dummyProjects.map(project => (
                  <SelectItem key={project.id} value={project.id}>
                    {project.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <div className="flex flex-1 gap-2">
              <Input
                placeholder="Task description"
                value={newTaskDescription}
                onChange={(e) => setNewTaskDescription(e.target.value)}
                className="flex-1"
              />
              <Button onClick={handleAddTask} disabled={!selectedProject || !newTaskDescription}>
                <Plus className="h-4 w-4 mr-1" /> Add Task
              </Button>
            </div>
          </div>
          
          <Button 
            variant="default" 
            onClick={handleSubmitTimesheet}
            disabled={timesheet.status !== 'draft' || calculateTotalHours() === 0}
          >
            <Save className="h-4 w-4 mr-1" /> Submit Timesheet
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default Timesheet;
