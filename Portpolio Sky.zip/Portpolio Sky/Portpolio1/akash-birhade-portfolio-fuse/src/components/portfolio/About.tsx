
import React, { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { MapPin, Calendar, Award, Coffee, Download } from 'lucide-react';

interface AboutProps {
  isDark: boolean;
}

const About: React.FC<AboutProps> = ({ isDark }) => {
  const sectionRef = useRef<HTMLElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const networkRef = useRef<HTMLCanvasElement>(null);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);

    const tl = gsap.timeline({
      scrollTrigger: {
        trigger: sectionRef.current,
        start: 'top 80%',
        end: 'bottom 20%',
        toggleActions: 'play none none reverse'
      }
    });

    tl.fromTo(contentRef.current,
      { opacity: 0, x: -100 },
      { opacity: 1, x: 0, duration: 1, ease: "power3.out" }
    )
    .fromTo(imageRef.current,
      { opacity: 0, x: 100, scale: 0.8 },
      { opacity: 1, x: 0, scale: 1, duration: 1, ease: "power3.out" },
      "-=0.5"
    );

    // Network animation
    const canvas = networkRef.current;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      const particles: any[] = [];
      
      const resizeCanvas = () => {
        canvas.width = canvas.offsetWidth;
        canvas.height = canvas.offsetHeight;
      };
      
      resizeCanvas();
      window.addEventListener('resize', resizeCanvas);

      // Create particles
      for (let i = 0; i < 50; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          vx: (Math.random() - 0.5) * 0.5,
          vy: (Math.random() - 0.5) * 0.5,
          size: Math.random() * 2 + 1
        });
      }

      const animate = () => {
        if (!ctx) return;
        
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Update particles
        particles.forEach(particle => {
          particle.x += particle.vx;
          particle.y += particle.vy;
          
          if (particle.x < 0 || particle.x > canvas.width) particle.vx *= -1;
          if (particle.y < 0 || particle.y > canvas.height) particle.vy *= -1;
        });

        // Draw connections
        ctx.strokeStyle = isDark ? 'rgba(59, 130, 246, 0.1)' : 'rgba(59, 130, 246, 0.1)';
        ctx.lineWidth = 1;
        
        for (let i = 0; i < particles.length; i++) {
          for (let j = i + 1; j < particles.length; j++) {
            const dx = particles[i].x - particles[j].x;
            const dy = particles[i].y - particles[j].y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            
            if (distance < 100) {
              ctx.beginPath();
              ctx.moveTo(particles[i].x, particles[i].y);
              ctx.lineTo(particles[j].x, particles[j].y);
              ctx.stroke();
            }
          }
        }

        // Draw particles
        ctx.fillStyle = isDark ? 'rgba(59, 130, 246, 0.6)' : 'rgba(59, 130, 246, 0.6)';
        particles.forEach(particle => {
          ctx.beginPath();
          ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
          ctx.fill();
        });

        requestAnimationFrame(animate);
      };

      animate();

      return () => {
        window.removeEventListener('resize', resizeCanvas);
      };
    }
  }, [isDark]);

  const handleMouseMove = (e: React.MouseEvent) => {
    const rect = sectionRef.current?.getBoundingClientRect();
    if (rect) {
      setMousePosition({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      });
    }
  };

  const socialLinks = [
    { icon: 'linkedin', href: '#', color: 'bg-blue-600' },
    { icon: 'github', href: '#', color: 'bg-gray-800' },
    { icon: 'twitter', href: '#', color: 'bg-blue-400' },
    { icon: 'instagram', href: '#', color: 'bg-pink-500' }
  ];

  return (
    <section 
      id="about" 
      ref={sectionRef}
      className="relative min-h-screen flex items-center py-20 px-4 max-w-7xl mx-auto overflow-hidden"
      onMouseMove={handleMouseMove}
    >
      {/* Animated Network Background */}
      <canvas
        ref={networkRef}
        className="absolute inset-0 z-0 opacity-30"
        style={{ width: '100%', height: '100%' }}
      />

      {/* Mouse Cursor Effect */}
      <div
        className="absolute w-32 h-32 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-full blur-xl pointer-events-none transition-all duration-300 ease-out z-10"
        style={{
          left: mousePosition.x - 64,
          top: mousePosition.y - 64,
        }}
      />

      <div className="relative z-20 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Content - Left Side */}
          <div ref={contentRef} className="space-y-8">
            {/* Greeting */}
            <div className="space-y-4">
              <h1 className="text-5xl md:text-6xl font-bold text-gray-900 dark:text-white">
                Hi There,
              </h1>
              <h2 className="text-5xl md:text-6xl font-bold">
                I'm{' '}
                <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-orange-500 bg-clip-text text-transparent">
                  Akash.
                </span>
                <span className="bg-gradient-to-r from-orange-500 to-red-500 bg-clip-text text-transparent">
                  Birhade
                </span>
              </h2>
              <p className="text-2xl md:text-3xl text-gray-700 dark:text-gray-300 font-medium">
                I Am Into{' '}
                <span className="text-red-600 dark:text-red-400 font-bold">
                  Web Development
                </span>
              </p>
            </div>

            {/* About Me Button */}
            <div className="pt-4">
              <button className="group relative px-8 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-full font-medium overflow-hidden transition-all duration-300 hover:shadow-2xl hover:scale-105">
                <span className="relative z-10 flex items-center gap-2">
                  About Me
                  <div className="w-2 h-2 bg-white rounded-full group-hover:scale-150 transition-transform duration-300" />
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-blue-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </button>
            </div>

            {/* Social Links */}
            <div className="flex gap-4 pt-4">
              {socialLinks.map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  className={`w-12 h-12 ${social.color} rounded-full flex items-center justify-center text-white hover:scale-110 transition-all duration-300 hover:shadow-lg group`}
                >
                  <div className="w-6 h-6 bg-white rounded group-hover:rotate-12 transition-transform duration-300" />
                </a>
              ))}
            </div>
          </div>

          {/* Image - Right Side */}
          <div ref={imageRef} className="flex justify-center lg:justify-end">
            <div className="relative group">
              {/* Background Circle */}
              <div className="absolute inset-0 w-80 h-80 lg:w-96 lg:h-96 bg-gradient-to-br from-yellow-400 via-orange-500 to-red-500 rounded-full flex items-center justify-center group-hover:scale-105 transition-transform duration-500">
                {/* Character Image */}
                <div className="w-64 h-64 lg:w-80 lg:h-80 rounded-full overflow-hidden bg-gradient-to-b from-blue-100 to-blue-200 flex items-end justify-center relative">
                  <img 
                    src="/lovable-uploads/49230fc5-8f59-4d4d-91bf-19f37572cf16.png"
                    alt="Akash Birhade"
                    className="w-full h-full object-cover object-top group-hover:scale-110 transition-transform duration-700"
                  />
                  
                  {/* Waving Hand Animation */}
                  <div className="absolute top-16 right-8 text-4xl animate-bounce">
                    👋
                  </div>
                </div>
              </div>
              
              {/* Floating Elements */}
              <div className="absolute -top-4 -left-4 w-8 h-8 bg-blue-500 rounded-full animate-pulse opacity-60" />
              <div className="absolute -bottom-6 -right-6 w-6 h-6 bg-purple-500 rounded-full animate-pulse opacity-60" />
              <div className="absolute top-1/4 -left-8 w-4 h-4 bg-teal-500 rounded-full animate-pulse opacity-60" />
              <div className="absolute bottom-1/4 -right-8 w-5 h-5 bg-pink-500 rounded-full animate-pulse opacity-60" />
            </div>
          </div>
        </div>

        {/* Skills Preview */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { icon: MapPin, label: "Location", value: "Mumbai, India" },
            { icon: Calendar, label: "Experience", value: "3+ Years" },
            { icon: Award, label: "Projects", value: "50+ Completed" },
            { icon: Coffee, label: "Coffee Cups", value: "1000+ Consumed" }
          ].map((item, index) => (
            <div key={index} className="group relative">
              <div className="p-4 bg-white/10 dark:bg-gray-800/10 backdrop-blur-md rounded-xl border border-white/20 dark:border-gray-700/20 hover:bg-white/20 dark:hover:bg-gray-800/20 transition-all duration-300 hover:scale-105">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-500 rounded-lg flex items-center justify-center group-hover:rotate-12 transition-transform duration-300">
                    <item.icon className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-600 dark:text-gray-400">{item.label}</p>
                    <p className="font-semibold text-gray-900 dark:text-white text-sm">{item.value}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;
