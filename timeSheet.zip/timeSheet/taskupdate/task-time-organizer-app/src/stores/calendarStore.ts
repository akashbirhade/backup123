
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { addDays, format, isSameDay, isWeekend } from 'date-fns';

export interface CalendarEntry {
  date: Date;
  status: 'complete' | 'partial' | 'missing';
  hours: number;
  tasks: { 
    project: string; 
    description: string; 
    hours: number;
  }[];
}

export interface CompanyHoliday {
  id: string;
  date: Date;
  name: string;
  description?: string;
  isRecurringYearly?: boolean;
}

interface CalendarStore {
  calendarEntries: CalendarEntry[];
  companyHolidays: CompanyHoliday[];
  addEntry: (entry: CalendarEntry) => void;
  updateEntry: (date: Date, updates: Partial<CalendarEntry>) => void;
  removeEntry: (date: Date) => void;
  addCompanyHoliday: (holiday: CompanyHoliday) => void;
  updateCompanyHoliday: (id: string, updates: Partial<CompanyHoliday>) => void;
  removeCompanyHoliday: (id: string) => void;
  isDayOff: (date: Date) => boolean;
}

// Initial company holidays
const initialHolidays: CompanyHoliday[] = [
  {
    id: '1',
    date: new Date(2025, 0, 1), // January 1st, 2025
    name: 'New Year\'s Day',
    isRecurringYearly: true
  },
  {
    id: '2',
    date: new Date(2025, 0, 26), // January 26th, 2025
    name: 'Republic Day',
    isRecurringYearly: true
  },
  {
    id: '3',
    date: new Date(2025, 7, 15), // August 15th, 2025
    name: 'Independence Day',
    isRecurringYearly: true
  },
  {
    id: '4', 
    date: new Date(2025, 9, 2), // October 2nd, 2025
    name: 'Gandhi Jayanti',
    isRecurringYearly: true
  },
  {
    id: '5',
    date: new Date(2025, 10, 4), // November 4th, 2025
    name: 'Diwali',
    description: 'Festival of Lights'
  }
];

// Generate dummy entries for the calendar
const getDummyEntries = (): CalendarEntry[] => {
  const today = new Date();
  const entries: CalendarEntry[] = [];
  
  // Generate entries for the past 60 days
  for (let i = 0; i < 60; i++) {
    const date = new Date();
    date.setDate(today.getDate() - i);
    
    // Skip weekends and holidays
    if (isWeekend(date)) {
      continue;
    }
    
    const isHoliday = initialHolidays.some(holiday => 
      isSameDay(holiday.date, date) || 
      (holiday.isRecurringYearly && 
       holiday.date.getDate() === date.getDate() && 
       holiday.date.getMonth() === date.getMonth())
    );
    
    if (isHoliday) {
      continue;
    }
    
    // Random status
    const statusOptions = ['complete', 'partial', 'missing'] as const;
    const status = statusOptions[Math.floor(Math.random() * 3)];
    
    // Generate hours based on status
    const hours = status === 'complete' ? 8 : status === 'partial' ? Math.floor(Math.random() * 7) + 1 : 0;
    
    // Generate tasks
    const numTasks = status === 'missing' ? 0 : Math.floor(Math.random() * 3) + 1;
    const tasks = [];
    const projects = ['Project Alpha', 'Project Beta', 'Project Gamma', 'Project Delta'];
    
    for (let j = 0; j < numTasks; j++) {
      tasks.push({
        project: projects[Math.floor(Math.random() * projects.length)],
        description: `Task ${j + 1} for ${format(date, 'MMM dd')}`,
        hours: Math.floor(Math.random() * 4) + 1
      });
    }
    
    entries.push({
      date,
      status,
      hours,
      tasks
    });
  }
  
  return entries;
};

export const useCalendarStore = create<CalendarStore>()(
  persist(
    (set, get) => ({
      calendarEntries: getDummyEntries(),
      companyHolidays: initialHolidays,
      
      addEntry: (entry) => set((state) => ({
        calendarEntries: [...state.calendarEntries, entry]
      })),
      
      updateEntry: (date, updates) => set((state) => ({
        calendarEntries: state.calendarEntries.map((entry) => 
          isSameDay(entry.date, date) ? { ...entry, ...updates } : entry
        )
      })),
      
      removeEntry: (date) => set((state) => ({
        calendarEntries: state.calendarEntries.filter((entry) => 
          !isSameDay(entry.date, date)
        )
      })),
      
      addCompanyHoliday: (holiday) => set((state) => ({
        companyHolidays: [...state.companyHolidays, holiday]
      })),
      
      updateCompanyHoliday: (id, updates) => set((state) => ({
        companyHolidays: state.companyHolidays.map((holiday) => 
          holiday.id === id ? { ...holiday, ...updates } : holiday
        )
      })),
      
      removeCompanyHoliday: (id) => set((state) => ({
        companyHolidays: state.companyHolidays.filter((holiday) => 
          holiday.id !== id
        )
      })),
      
      isDayOff: (date) => {
        // Check if it's a weekend
        if (isWeekend(date)) return true;
        
        // Check if it's a company holiday
        const { companyHolidays } = get();
        return companyHolidays.some(holiday => 
          isSameDay(holiday.date, date) || 
          (holiday.isRecurringYearly && 
           holiday.date.getDate() === date.getDate() && 
           holiday.date.getMonth() === date.getMonth())
        );
      }
    }),
    {
      name: 'calendar-store'
    }
  )
);
