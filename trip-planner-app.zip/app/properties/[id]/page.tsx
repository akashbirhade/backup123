"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useParams, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { DatePickerWithRange } from "@/components/date-range-picker"
import { AvailabilityCalendar } from "@/components/availability-calendar"
import {
  ArrowLeft,
  MapPin,
  Star,
  Wifi,
  Tv,
  CookingPotIcon as Kitchen,
  Car,
  Snowflake,
  Coffee,
  Bath,
  Users,
  Check,
  CreditCard,
  Smartphone,
  Landmark,
  Calendar,
  Share2,
  Heart,
} from "lucide-react"
import PropertyMap from "@/components/property-map"
import { generateMockProperties } from "@/lib/mock-properties"

export default function PropertyDetailPage() {
  const params = useParams()
  const router = useRouter()
  const [property, setProperty] = useState(null)
  const [currency, setCurrency] = useState("USD")
  const [bookingDates, setBookingDates] = useState({
    from: undefined,
    to: undefined,
  })
  const [paymentMethod, setPaymentMethod] = useState("card")
  const [isFavorite, setIsFavorite] = useState(false)
  const [bookedDates, setBookedDates] = useState([])

  useEffect(() => {
    // In a real app, we would fetch the property from an API
    // First check if there are any hosted properties in localStorage
    const hostedProperties = JSON.parse(localStorage.getItem("hostedProperties") || "[]")

    // Combine hosted properties with mock properties
    const allProperties = [
      ...hostedProperties,
      ...generateMockProperties("paris"),
      ...generateMockProperties("bali"),
      ...generateMockProperties("tokyo"),
      ...generateMockProperties("newyork"),
      ...generateMockProperties("rome"),
    ]

    const foundProperty = allProperties.find((p) => p.id === params.id)

    if (foundProperty) {
      setProperty(foundProperty)

      // Generate some random booked dates for the next 3 months
      const randomBookedDates = []
      const today = new Date()

      for (let i = 0; i < 15; i++) {
        const futureDate = new Date(today)
        // Ensure we're creating valid dates by adding a random number of days
        futureDate.setDate(today.getDate() + Math.floor(Math.random() * 90) + 1)
        // Make sure the date is valid before adding it
        if (!isNaN(futureDate.getTime())) {
          randomBookedDates.push(futureDate.toISOString())
        }
      }

      setBookedDates(randomBookedDates)
    } else {
      router.push("/properties")
    }
  }, [params.id, router])

  const currencySymbols = {
    USD: "$",
    EUR: "€",
    GBP: "£",
    JPY: "¥",
    INR: "₹",
  }

  const convertPrice = (price) => {
    // Simple mock conversion rates
    const rates = {
      USD: 1,
      EUR: 0.92,
      GBP: 0.79,
      JPY: 150.2,
      INR: 83.5,
    }

    const convertedPrice = Math.round(price * rates[currency])
    return `${currencySymbols[currency]}${convertedPrice}`
  }

  const calculateTotalPrice = () => {
    if (!property || !bookingDates.from || !bookingDates.to) return 0

    const from = new Date(bookingDates.from)
    const to = new Date(bookingDates.to)
    const nights = Math.ceil((to - from) / (1000 * 60 * 60 * 24))

    return property.price * nights
  }

  const handleBooking = () => {
    // In a real app, we would send the booking to an API
    alert("Booking successful! You will receive a confirmation email shortly.")

    // Add to trip planner
    const tripData = {
      destination: property.location,
      dateRange: bookingDates,
      budget: calculateTotalPrice() + 80, // Add some budget for other expenses
      tripType: "solo",
      preferences: `Staying at ${property.title}`,
      accommodation: property,
    }

    localStorage.setItem("tripPlan", JSON.stringify(tripData))

    // Redirect to trip plan
    router.push("/trip-plan")
  }

  if (!property) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <p>Loading property details...</p>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Link href="/properties" className="flex items-center text-emerald-600 hover:text-emerald-700">
          <ArrowLeft className="h-4 w-4 mr-1" />
          Back to Properties
        </Link>
      </div>

      <div className="flex flex-wrap items-center justify-between mb-4">
        <h1 className="text-3xl font-bold mb-2">{property.title}</h1>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Share2 className="h-4 w-4 mr-2" />
            Share
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setIsFavorite(!isFavorite)}
            className={isFavorite ? "text-red-500" : ""}
          >
            <Heart className={`h-4 w-4 mr-2 ${isFavorite ? "fill-red-500 text-red-500" : ""}`} />
            {isFavorite ? "Saved" : "Save"}
          </Button>
        </div>
      </div>

      <div className="flex items-center mb-6">
        <div className="flex items-center mr-4">
          <Star className="h-4 w-4 fill-amber-500 text-amber-500 mr-1" />
          <span>{property.rating}</span>
          <span className="text-gray-500 ml-1">({property.reviews} reviews)</span>
        </div>
        <div className="flex items-center text-gray-600">
          <MapPin className="h-4 w-4 mr-1" />
          {property.location}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="grid grid-cols-2 gap-2 mb-6">
            <div className="col-span-2 h-64 bg-gray-200 rounded-lg overflow-hidden">
              <img
                src={property.image || "/placeholder.svg"}
                alt={property.title}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="h-32 bg-gray-200 rounded-lg overflow-hidden">
              <img src="/placeholder.svg?height=128&width=256" alt="Property" className="w-full h-full object-cover" />
            </div>
            <div className="h-32 bg-gray-200 rounded-lg overflow-hidden">
              <img src="/placeholder.svg?height=128&width=256" alt="Property" className="w-full h-full object-cover" />
            </div>
          </div>

          <Tabs defaultValue="details">
            <TabsList className="mb-4">
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="amenities">Amenities</TabsTrigger>
              <TabsTrigger value="location">Location</TabsTrigger>
              <TabsTrigger value="reviews">Reviews</TabsTrigger>
              <TabsTrigger value="availability">Availability</TabsTrigger>
            </TabsList>

            <TabsContent value="details" className="space-y-4">
              <div>
                <h2 className="text-xl font-semibold mb-2">About this property</h2>
                <p className="text-gray-600">{property.description}</p>
              </div>

              <div>
                <h3 className="text-lg font-medium mb-2">Property Details</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div className="flex items-center">
                    <Users className="h-5 w-5 mr-2 text-emerald-600" />
                    <span>{property.guests} guests</span>
                  </div>
                  <div className="flex items-center">
                    <Bath className="h-5 w-5 mr-2 text-emerald-600" />
                    <span>{property.bathrooms} bathrooms</span>
                  </div>
                  <div className="flex items-center">
                    <Coffee className="h-5 w-5 mr-2 text-emerald-600" />
                    <span>{property.bedrooms} bedrooms</span>
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <h3 className="text-lg font-medium mb-2">House Rules</h3>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 mr-2 text-emerald-600 shrink-0" />
                    <span>Check-in: After 3:00 PM</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 mr-2 text-emerald-600 shrink-0" />
                    <span>Checkout: 11:00 AM</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 mr-2 text-emerald-600 shrink-0" />
                    <span>Self check-in with keypad</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 mr-2 text-emerald-600 shrink-0" />
                    <span>No smoking</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 mr-2 text-emerald-600 shrink-0" />
                    <span>No pets</span>
                  </li>
                </ul>
              </div>
            </TabsContent>

            <TabsContent value="amenities">
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center">
                  <Wifi className="h-5 w-5 mr-2 text-emerald-600" />
                  <span>Free WiFi</span>
                </div>
                <div className="flex items-center">
                  <Tv className="h-5 w-5 mr-2 text-emerald-600" />
                  <span>TV</span>
                </div>
                <div className="flex items-center">
                  <Kitchen className="h-5 w-5 mr-2 text-emerald-600" />
                  <span>Kitchen</span>
                </div>
                <div className="flex items-center">
                  <Car className="h-5 w-5 mr-2 text-emerald-600" />
                  <span>Free parking</span>
                </div>
                <div className="flex items-center">
                  <Snowflake className="h-5 w-5 mr-2 text-emerald-600" />
                  <span>Air conditioning</span>
                </div>
                <div className="flex items-center">
                  <Coffee className="h-5 w-5 mr-2 text-emerald-600" />
                  <span>Coffee maker</span>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="location">
              <div className="h-[400px] rounded-lg overflow-hidden mb-4">
                <PropertyMap properties={[property]} convertPrice={convertPrice} />
              </div>
              <h3 className="text-lg font-medium mb-2">About the area</h3>
              <p className="text-gray-600">
                This property is located in a prime area with easy access to local attractions, restaurants, and public
                transportation. The neighborhood is safe and quiet, perfect for both tourists and business travelers.
              </p>
            </TabsContent>

            <TabsContent value="reviews">
              <div className="space-y-4">
                <div className="flex items-center mb-4">
                  <div className="text-3xl font-bold mr-4">{property.rating}</div>
                  <div>
                    <div className="flex text-amber-500 mb-1">
                      <Star className="h-5 w-5 fill-current" />
                      <Star className="h-5 w-5 fill-current" />
                      <Star className="h-5 w-5 fill-current" />
                      <Star className="h-5 w-5 fill-current" />
                      <Star className="h-5 w-5 fill-current opacity-40" />
                    </div>
                    <div className="text-gray-600">{property.reviews} reviews</div>
                  </div>
                </div>

                {/* Sample reviews */}
                <div className="border-b pb-4">
                  <div className="flex items-center mb-2">
                    <div className="w-10 h-10 rounded-full bg-gray-200 mr-3"></div>
                    <div>
                      <div className="font-medium">Sarah J.</div>
                      <div className="text-gray-500 text-sm">April 2023</div>
                    </div>
                  </div>
                  <p className="text-gray-600">
                    Amazing place! The location was perfect and the amenities were exactly as described. Would
                    definitely stay here again.
                  </p>
                </div>

                <div className="border-b pb-4">
                  <div className="flex items-center mb-2">
                    <div className="w-10 h-10 rounded-full bg-gray-200 mr-3"></div>
                    <div>
                      <div className="font-medium">Michael T.</div>
                      <div className="text-gray-500 text-sm">March 2023</div>
                    </div>
                  </div>
                  <p className="text-gray-600">
                    Great value for the price. The host was very responsive and helpful. The place was clean and
                    comfortable.
                  </p>
                </div>

                <div>
                  <div className="flex items-center mb-2">
                    <div className="w-10 h-10 rounded-full bg-gray-200 mr-3"></div>
                    <div>
                      <div className="font-medium">Emma L.</div>
                      <div className="text-gray-500 text-sm">February 2023</div>
                    </div>
                  </div>
                  <p className="text-gray-600">
                    Lovely property in a fantastic location. Everything was as pictured and the check-in process was
                    seamless. Highly recommend!
                  </p>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="availability">
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-medium mb-2">Check Availability</h3>
                  <p className="text-gray-600 mb-4">
                    Select your dates to see if this property is available for your trip. Booked dates are shown in red.
                  </p>

                  <AvailabilityCalendar bookedDates={bookedDates} className="mb-4" />

                  <div className="bg-emerald-50 p-4 rounded-md">
                    <div className="flex items-center">
                      <Calendar className="h-5 w-5 text-emerald-600 mr-2" />
                      <span className="font-medium">Trip Planning Tip</span>
                    </div>
                    <p className="text-sm text-gray-700 mt-1">
                      After booking this property, use our AI Trip Planner to create a personalized itinerary around
                      your stay. The planner will automatically include this accommodation in your trip.
                    </p>
                    <Link href="/create-trip">
                      <Button variant="link" className="text-emerald-600 p-0 h-auto mt-2">
                        Learn more about AI Trip Planning
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        <div className="lg:col-span-1">
          <Card className="sticky top-4">
            <CardContent className="p-6">
              <div className="flex justify-between items-center mb-4">
                <div className="text-2xl font-bold">{convertPrice(property.price)}</div>
                <div className="text-gray-500">per night</div>
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium mb-2">Select Currency</label>
                <select
                  className="w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500"
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value)}
                >
                  <option value="USD">USD ($)</option>
                  <option value="EUR">EUR (€)</option>
                  <option value="GBP">GBP (£)</option>
                  <option value="JPY">JPY (¥)</option>
                  <option value="INR">INR (₹)</option>
                </select>
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium mb-2">Dates</label>
                <DatePickerWithRange date={bookingDates} setDate={setBookingDates} />
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium mb-2">Guests</label>
                <select className="w-full rounded-md border-gray-300 shadow-sm focus:border-emerald-500 focus:ring-emerald-500">
                  <option>1 guest</option>
                  <option>2 guests</option>
                  <option>3 guests</option>
                  <option>4 guests</option>
                  <option>5 guests</option>
                </select>
              </div>

              {bookingDates.from && bookingDates.to && (
                <div className="mb-4 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">
                      {convertPrice(property.price)} x{" "}
                      {Math.ceil((new Date(bookingDates.to) - new Date(bookingDates.from)) / (1000 * 60 * 60 * 24))}{" "}
                      nights
                    </span>
                    <span>{convertPrice(calculateTotalPrice())}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Cleaning fee</span>
                    <span>{convertPrice(50)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Service fee</span>
                    <span>{convertPrice(30)}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between font-bold">
                    <span>Total</span>
                    <span>{convertPrice(calculateTotalPrice() + 50 + 30)}</span>
                  </div>
                </div>
              )}

              {bookingDates.from && bookingDates.to && (
                <div className="mb-4">
                  <h3 className="text-lg font-medium mb-2">Payment Method</h3>
                  <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
                    <div className="flex items-center space-x-2 mb-2">
                      <RadioGroupItem value="card" id="card" />
                      <Label htmlFor="card" className="flex items-center">
                        <CreditCard className="h-4 w-4 mr-2" />
                        Credit/Debit Card
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2 mb-2">
                      <RadioGroupItem value="upi" id="upi" />
                      <Label htmlFor="upi" className="flex items-center">
                        <Smartphone className="h-4 w-4 mr-2" />
                        UPI Payment
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="bank" id="bank" />
                      <Label htmlFor="bank" className="flex items-center">
                        <Landmark className="h-4 w-4 mr-2" />
                        Bank Transfer
                      </Label>
                    </div>
                  </RadioGroup>
                </div>
              )}

              <Button
                className="w-full bg-emerald-600 hover:bg-emerald-700"
                onClick={bookingDates.from && bookingDates.to ? handleBooking : undefined}
              >
                {bookingDates.from && bookingDates.to ? "Reserve Now" : "Check Availability"}
              </Button>

              {bookingDates.from && bookingDates.to && (
                <p className="text-xs text-center text-gray-500 mt-2">
                  You won't be charged yet. Your booking will be confirmed after payment.
                </p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
