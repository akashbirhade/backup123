
import { 
  LoginCredentials, 
  RegisterData, 
  ApiResponse,
  User,
  Project,
  Timesheet,
  TimeEntry,
  Report
} from './types';

// Base API URL from environment or default to localhost
const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

// Get the stored token from localStorage
const getToken = () => localStorage.getItem('token');

// Utility to check if user is logged in
const getCurrentUser = () => {
  const token = getToken();
  const userJson = localStorage.getItem('user');
  
  if (!token || !userJson) {
    return { user: null, isAuthenticated: false };
  }
  
  try {
    const user = JSON.parse(userJson);
    return { user, isAuthenticated: true };
  } catch (error) {
    // If there's an error parsing the user, clear storage
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    return { user: null, isAuthenticated: false };
  }
};

// Helper method for API calls
const apiCall = async <T>(
  endpoint: string, 
  method: string = 'GET', 
  data: any = null,
  requiresAuth: boolean = true
): Promise<ApiResponse<T>> => {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  
  if (requiresAuth) {
    const token = getToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    } else {
      return {
        success: false,
        error: 'Authentication required',
        data: null
      };
    }
  }
  
  try {
    const response = await fetch(`${API_URL}${endpoint}`, {
      method,
      headers,
      body: data ? JSON.stringify(data) : null,
    });
    
    const result = await response.json();
    
    if (!response.ok) {
      return {
        success: false,
        error: result.error || `Error: ${response.status}`,
        data: null
      };
    }
    
    return {
      success: true,
      data: result.data,
      error: null
    };
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error occurred',
      data: null
    };
  }
};

// Auth API methods
export const authApi = {
  login: async (credentials: LoginCredentials): Promise<ApiResponse<{ user: User; token: string }>> => {
    // Special case for static login
    if (credentials.email === "admin@example.com" && credentials.password === "admin123") {
      const adminUser = {
        id: 1,
        firstName: "Admin",
        lastName: "User",
        email: "admin@example.com",
        role: "admin"
      };
      
      const token = "admin-static-token";
      localStorage.setItem('token', token);
      localStorage.setItem('user', JSON.stringify(adminUser));
      
      return {
        success: true,
        data: { user: adminUser, token },
        error: null
      };
    }
    
    if (credentials.email === "user@example.com" && credentials.password === "user123") {
      const regularUser = {
        id: 2,
        firstName: "Regular",
        lastName: "User",
        email: "user@example.com",
        role: "user"
      };
      
      const token = "user-static-token";
      localStorage.setItem('token', token);
      localStorage.setItem('user', JSON.stringify(regularUser));
      
      return {
        success: true,
        data: { user: regularUser, token },
        error: null
      };
    }
    
    // Fall back to API if static credentials don't match
    return apiCall<{ user: User; token: string }>('/auth/login', 'POST', credentials, false);
  },
  
  register: async (data: RegisterData): Promise<ApiResponse<{ user: User; token: string }>> => {
    return apiCall<{ user: User; token: string }>('/auth/register', 'POST', data, false);
  },
  
  getCurrentUser,
  
  logout: () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
  }
};

// Projects API methods
export const projectsApi = {
  getProjects: async (): Promise<ApiResponse<Project[]>> => {
    const user = getCurrentUser().user;
    
    // Return static projects data if using static login
    if (user?.email === "admin@example.com" || user?.email === "user@example.com") {
      const projects = [
        { 
          id: 1,
          name: 'Project Alpha', 
          clientId: 1,
          clientName: 'Client A',
          description: 'First major project with client A',
          startDate: '2025-01-15',
          endDate: '2025-06-30',
          status: 'active',
          userCount: 5,
          totalHours: 180
        },
        { 
          id: 2,
          name: 'Project Beta', 
          clientId: 2,
          clientName: 'Client B',
          description: 'Website redesign for Client B',
          startDate: '2025-03-01',
          endDate: '2025-08-15',
          status: 'active',
          userCount: 3,
          totalHours: 64
        },
        { 
          id: 3,
          name: 'Project Gamma', 
          clientId: 1,
          clientName: 'Client A',
          description: 'Mobile app development',
          startDate: '2025-02-15',
          endDate: '2025-05-30',
          status: 'active',
          userCount: 4,
          totalHours: 98
        },
        { 
          id: 4,
          name: 'Project Delta', 
          clientId: 3,
          clientName: 'Client C',
          description: 'ERP system integration',
          startDate: '2025-05-15',
          endDate: '2025-09-30',
          status: 'upcoming',
          userCount: 6,
          totalHours: 0
        },
        { 
          id: 5,
          name: 'Project Epsilon', 
          clientId: 2,
          clientName: 'Client B',
          description: 'Social media campaign',
          startDate: '2024-10-01',
          endDate: '2025-03-31',
          status: 'completed',
          userCount: 2,
          totalHours: 175
        },
      ];
      
      return {
        success: true,
        data: projects,
        error: null
      };
    }
    
    return apiCall<Project[]>('/projects');
  },
  
  getProject: async (id: number): Promise<ApiResponse<Project>> => {
    return apiCall<Project>(`/projects/${id}`);
  },
  
  createProject: async (data: Partial<Project>): Promise<ApiResponse<Project>> => {
    return apiCall<Project>('/projects', 'POST', data);
  },
  
  updateProject: async (id: number, data: Partial<Project>): Promise<ApiResponse<Project>> => {
    return apiCall<Project>(`/projects/${id}`, 'PUT', data);
  }
};

// Users API
export const usersApi = {
  getUsers: async (): Promise<ApiResponse<User[]>> => {
    const user = getCurrentUser().user;
    
    // Return static users data if using admin login
    if (user?.email === "admin@example.com") {
      const users = [
        {
          id: 1,
          firstName: "Admin",
          lastName: "User",
          email: "admin@example.com",
          role: "admin",
          createdAt: "2024-10-01T10:00:00Z"
        },
        {
          id: 2,
          firstName: "Regular",
          lastName: "User",
          email: "user@example.com",
          role: "user",
          createdAt: "2024-10-01T11:00:00Z"
        },
        {
          id: 3,
          firstName: "Project",
          lastName: "Manager",
          email: "manager@example.com",
          role: "user",
          createdAt: "2024-10-02T09:00:00Z"
        },
        {
          id: 4,
          firstName: "Team",
          lastName: "Lead",
          email: "lead@example.com",
          role: "user",
          createdAt: "2024-10-02T10:30:00Z"
        },
        {
          id: 5,
          firstName: "John",
          lastName: "Developer",
          email: "john@example.com",
          role: "user",
          createdAt: "2024-10-03T14:00:00Z"
        }
      ];
      
      return {
        success: true,
        data: users,
        error: null
      };
    }
    
    return apiCall<User[]>('/users');
  }
};

// Timesheets API
export const timesheetsApi = {
  getTimesheets: async (): Promise<ApiResponse<Timesheet[]>> => {
    return apiCall<Timesheet[]>('/timesheets');
  },
  
  getTimesheet: async (id: number): Promise<ApiResponse<Timesheet>> => {
    return apiCall<Timesheet>(`/timesheets/${id}`);
  },
  
  createTimesheet: async (data: Partial<Timesheet>): Promise<ApiResponse<Timesheet>> => {
    return apiCall<Timesheet>('/timesheets', 'POST', data);
  },
  
  updateTimesheet: async (id: number, data: Partial<Timesheet>): Promise<ApiResponse<Timesheet>> => {
    return apiCall<Timesheet>(`/timesheets/${id}`, 'PUT', data);
  },
  
  deleteTimesheet: async (id: number): Promise<ApiResponse<null>> => {
    return apiCall<null>(`/timesheets/${id}`, 'DELETE');
  },
  
  // Time Entries
  createTimeEntry: async (timesheetId: number, data: Partial<TimeEntry>): Promise<ApiResponse<TimeEntry>> => {
    return apiCall<TimeEntry>(`/timesheets/${timesheetId}/entries`, 'POST', data);
  },
  
  updateTimeEntry: async (timesheetId: number, entryId: number, data: Partial<TimeEntry>): Promise<ApiResponse<TimeEntry>> => {
    return apiCall<TimeEntry>(`/timesheets/${timesheetId}/entries/${entryId}`, 'PUT', data);
  },
  
  deleteTimeEntry: async (timesheetId: number, entryId: number): Promise<ApiResponse<null>> => {
    return apiCall<null>(`/timesheets/${timesheetId}/entries/${entryId}`, 'DELETE');
  }
};

// Reports API
export const reportsApi = {
  generateReport: async (type: string, params: Record<string, any>): Promise<ApiResponse<Report>> => {
    return apiCall<Report>(`/reports/${type}`, 'POST', params);
  },
  
  exportReport: async (type: string, format: 'excel' | 'csv' | 'pdf', params: Record<string, any>): Promise<string> => {
    const token = getToken();
    const queryParams = new URLSearchParams({ format, ...params }).toString();
    const url = `${API_URL}/reports/${type}/export?${queryParams}`;
    
    if (format === 'excel') {
      window.open(`${url}&token=${token}`, '_blank');
    }
    
    return url;
  }
};
