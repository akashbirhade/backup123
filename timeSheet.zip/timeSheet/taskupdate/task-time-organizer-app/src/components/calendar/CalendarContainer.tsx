
import React, { useState } from 'react';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChevronDown, ChevronUp, CalendarDays } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";
import { CalendarGrid } from "./CalendarGrid";
import { CalendarLegend } from "./CalendarLegend";
import { DayDetailsDialog } from "./DayDetailsDialog";

interface CalendarContainerProps {
  initialExpanded?: boolean;
}

export const CalendarContainer = ({ initialExpanded = false }: CalendarContainerProps) => {
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isExpanded, setIsExpanded] = useState(initialExpanded);
  const isMobile = useIsMobile();

  const handleDayClick = (date: Date | undefined) => {
    if (date) {
      setSelectedDate(date);
      setIsDialogOpen(true);
    }
  };

  return (
    <>
      <Collapsible 
        open={isExpanded} 
        onOpenChange={setIsExpanded}
        className="w-full"
      >
        <Card className="mt-6">
          <CardHeader className="pb-3 flex flex-row justify-between items-center">
            <CardTitle className="text-xl flex items-center gap-2">
              <CalendarDays className="h-5 w-5" />
              Timesheet Calendar
            </CardTitle>
            <CollapsibleTrigger className="hover:bg-gray-100 rounded-full p-2">
              {isExpanded ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
            </CollapsibleTrigger>
          </CardHeader>
          
          <CollapsibleContent>
            <CardContent>
              <CalendarLegend />
              
              <CalendarGrid 
                monthsOffset={[0, 1, 2]} 
                onDayClick={handleDayClick} 
                isMobile={isMobile} 
              />
              
              {isMobile ? null : (
                <CalendarGrid 
                  monthsOffset={[3, 4, 5]}
                  onDayClick={handleDayClick}
                  isMobile={isMobile}
                />
              )}
            </CardContent>
          </CollapsibleContent>
        </Card>
      </Collapsible>

      <DayDetailsDialog 
        isOpen={isDialogOpen} 
        onOpenChange={setIsDialogOpen} 
        selectedDate={selectedDate} 
      />
    </>
  );
};
