
import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ExternalLink, Github } from 'lucide-react';

interface ProjectsProps {
  isDark: boolean;
}

const Projects: React.FC<ProjectsProps> = ({ isDark }) => {
  const sectionRef = useRef<HTMLElement>(null);
  const projectsRef = useRef<HTMLDivElement[]>([]);

  const projects = [
    {
      title: 'Movie Website',
      description: 'A comprehensive movie database application built with React, featuring search functionality, movie details, ratings, and user reviews.',
      image: 'https://images.unsplash.com/photo-1489599833537-04b8ba9b7bb0?w=600&h=400&fit=crop',
      technologies: ['React', 'TypeScript', 'TMDB API', 'Tailwind CSS'],
      github: '#',
      live: '#',
      gradient: 'from-red-500 to-pink-500'
    },
    {
      title: 'eCommerce App with Redux',
      description: 'Full-featured e-commerce platform with cart management, payment integration, user authentication, and admin dashboard.',
      image: 'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=600&h=400&fit=crop',
      technologies: ['React', 'Redux Toolkit', 'Node.js', 'MongoDB', 'Stripe'],
      github: '#',
      live: '#',
      gradient: 'from-blue-500 to-cyan-500'
    },
    {
      title: 'GSAP/Three.js Animated App',
      description: 'Interactive 3D web experience showcasing advanced animations, particle systems, and immersive user interactions.',
      image: 'https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=600&h=400&fit=crop',
      technologies: ['React', 'Three.js', 'GSAP', 'WebGL', 'Framer Motion'],
      github: '#',
      live: '#',
      gradient: 'from-purple-500 to-indigo-500'
    },
    {
      title: 'Form & Table App',
      description: 'Dynamic data management application with advanced forms, data validation, sorting, filtering, and export functionality.',
      image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=600&h=400&fit=crop',
      technologies: ['React', 'TypeScript', 'React Hook Form', 'Material UI'],
      github: '#',
      live: '#',
      gradient: 'from-green-500 to-teal-500'
    }
  ];

  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);

    projectsRef.current.forEach((project, index) => {
      if (project) {
        gsap.fromTo(project,
          { opacity: 0, y: 100, scale: 0.8 },
          {
            opacity: 1,
            y: 0,
            scale: 1,
            duration: 0.8,
            ease: "power3.out",
            scrollTrigger: {
              trigger: project,
              start: 'top 80%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      }
    });
  }, []);

  return (
    <section 
      id="projects" 
      ref={sectionRef}
      className="py-20 px-4 max-w-7xl mx-auto"
    >
      <div className="text-center mb-16">
        <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4">
          Featured Projects
        </h2>
        <div className="w-20 h-1 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full mx-auto mb-6" />
        <p className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
          Here are some of my recent projects that showcase my skills and passion for development
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {projects.map((project, index) => (
          <div
            key={project.title}
            ref={el => { if (el) projectsRef.current[index] = el; }}
            className="group relative overflow-hidden rounded-2xl bg-white dark:bg-gray-800 shadow-lg hover:shadow-2xl transition-all duration-500"
          >
            {/* Project Image */}
            <div className="relative overflow-hidden">
              <img 
                src={project.image}
                alt={project.title}
                className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
              />
              <div className={`absolute inset-0 bg-gradient-to-br ${project.gradient} opacity-60 group-hover:opacity-40 transition-opacity duration-300`} />
            </div>

            {/* Project Content */}
            <div className="p-6">
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors duration-300">
                {project.title}
              </h3>
              
              <p className="text-gray-600 dark:text-gray-400 mb-4 line-clamp-3">
                {project.description}
              </p>

              {/* Technologies */}
              <div className="flex flex-wrap gap-2 mb-4">
                {project.technologies.map((tech) => (
                  <span
                    key={tech}
                    className="px-3 py-1 text-xs font-medium bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-full"
                  >
                    {tech}
                  </span>
                ))}
              </div>

              {/* Project Links */}
              <div className="flex gap-4">
                <a
                  href={project.github}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-4 py-2 bg-gray-900 dark:bg-gray-700 text-white rounded-lg hover:bg-gray-800 dark:hover:bg-gray-600 transition-colors duration-300"
                >
                  <Github size={16} />
                  Code
                </a>
                <a
                  href={project.live}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`flex items-center gap-2 px-4 py-2 bg-gradient-to-r ${project.gradient} text-white rounded-lg hover:shadow-lg hover:scale-105 transition-all duration-300`}
                >
                  <ExternalLink size={16} />
                  Live Demo
                </a>
              </div>
            </div>

            {/* Hover Effect */}
            <div className="absolute inset-0 border-2 border-transparent group-hover:border-blue-500/50 rounded-2xl transition-all duration-300 pointer-events-none" />
          </div>
        ))}
      </div>
    </section>
  );
};

export default Projects;
