"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { MapPin, Calendar, Star, Filter } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Link from "next/link"
import PropertyMap from "@/components/property-map"

type Property = {
  id: string
  title: string
  location: string
  price: number
  rating: number
  image: string
  type: "hotel" | "airbnb"
  lat: number
  lng: number
}

export default function PropertiesPage() {
  const searchParams = useSearchParams()
  const locationParam = searchParams.get("location") || ""
  const dateParam = searchParams.get("date") || ""

  const [properties, setProperties] = useState<Property[]>([])
  const [loading, setLoading] = useState(true)
  const [priceRange, setPriceRange] = useState([0, 500])
  const [propertyType, setPropertyType] = useState<string>("all")
  const [showMap, setShowMap] = useState(false)

  useEffect(() => {
    // In a real app, this would be an API call with the search params
    // For now, we'll simulate loading with mock data
    const timeout = setTimeout(() => {
      setProperties(getMockProperties(locationParam))
      setLoading(false)
    }, 800)

    return () => clearTimeout(timeout)
  }, [locationParam])

  const filteredProperties = properties.filter((property) => {
    const matchesPrice = property.price >= priceRange[0] && property.price <= priceRange[1]
    const matchesType = propertyType === "all" || property.type === propertyType
    return matchesPrice && matchesType
  })

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start mb-8">
        <div>
          <h1 className="text-3xl font-bold mb-2">
            {locationParam ? `Properties in ${locationParam}` : "All Properties"}
          </h1>
          {dateParam && (
            <div className="flex items-center text-gray-600">
              <Calendar className="h-4 w-4 mr-1" />
              <span>For {dateParam}</span>
            </div>
          )}
          <p className="text-gray-600 mt-2">{filteredProperties.length} properties found</p>
        </div>

        <Button variant="outline" className="mt-4 md:mt-0" onClick={() => setShowMap(!showMap)}>
          {showMap ? "Hide Map" : "Show Map"}
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-1">
          <Card>
            <CardContent className="p-6">
              <h3 className="font-semibold text-lg mb-4 flex items-center">
                <Filter className="h-5 w-5 mr-2" />
                Filters
              </h3>

              <div className="mb-6">
                <h4 className="font-medium mb-2">Price Range</h4>
                <Slider
                  defaultValue={[0, 500]}
                  max={500}
                  step={10}
                  value={priceRange}
                  onValueChange={setPriceRange}
                  className="mb-2"
                />
                <div className="flex justify-between text-sm text-gray-600">
                  <span>${priceRange[0]}</span>
                  <span>${priceRange[1]}</span>
                </div>
              </div>

              <div className="mb-6">
                <h4 className="font-medium mb-2">Property Type</h4>
                <Select value={propertyType} onValueChange={setPropertyType}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Types" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="hotel">Hotels</SelectItem>
                    <SelectItem value="airbnb">Airbnbs</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button
                className="w-full"
                onClick={() => {
                  setPriceRange([0, 500])
                  setPropertyType("all")
                }}
              >
                Reset Filters
              </Button>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-3">
          {showMap && (
            <div className="mb-6 h-[400px] rounded-lg overflow-hidden border">
              <PropertyMap properties={filteredProperties} />
            </div>
          )}

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[1, 2, 3, 4].map((i) => (
                <Card key={i} className="overflow-hidden">
                  <div className="h-48 bg-gray-200 animate-pulse" />
                  <CardContent className="p-4">
                    <div className="h-6 bg-gray-200 animate-pulse rounded mb-2" />
                    <div className="h-4 bg-gray-200 animate-pulse rounded w-3/4 mb-4" />
                    <div className="h-4 bg-gray-200 animate-pulse rounded w-1/2" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <>
              {filteredProperties.length === 0 ? (
                <div className="text-center py-12">
                  <h3 className="text-xl font-medium mb-2">No properties found</h3>
                  <p className="text-gray-600">Try adjusting your filters</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {filteredProperties.map((property) => (
                    <Link href={`/properties/${property.id}`} key={property.id}>
                      <Card className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer h-full flex flex-col">
                        <div className="relative h-48 overflow-hidden">
                          <img
                            src={property.image || "/placeholder.svg"}
                            alt={property.title}
                            className="w-full h-full object-cover transition-transform hover:scale-105"
                          />
                          <Badge
                            className={`absolute top-2 right-2 ${
                              property.type === "hotel" ? "bg-blue-500" : "bg-rose-500"
                            }`}
                          >
                            {property.type === "hotel" ? "Hotel" : "Airbnb"}
                          </Badge>
                        </div>
                        <CardContent className="p-4 flex-grow">
                          <h3 className="font-semibold text-lg mb-1">{property.title}</h3>
                          <div className="flex items-center text-gray-500 mb-2">
                            <MapPin className="h-4 w-4 mr-1" />
                            <span className="text-sm">{property.location}</span>
                          </div>
                          <div className="flex items-center">
                            <Star className="h-4 w-4 text-yellow-500 mr-1" />
                            <span className="text-sm font-medium">{property.rating.toFixed(1)}</span>
                          </div>
                        </CardContent>
                        <CardFooter className="p-4 pt-0 border-t">
                          <div className="flex justify-between items-center w-full">
                            <span className="font-bold text-lg">${property.price}</span>
                            <span className="text-gray-500 text-sm">per night</span>
                          </div>
                        </CardFooter>
                      </Card>
                    </Link>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  )
}

function getMockProperties(location: string): Property[] {
  const count = 8
  const types = ["hotel", "airbnb"]

  // Generate random coordinates near the searched location
  // In a real app, these would come from a geocoding service
  const baseCoordinates = {
    lat: 40.7128 + (Math.random() * 0.1 - 0.05),
    lng: -74.006 + (Math.random() * 0.1 - 0.05),
  }

  return Array(count)
    .fill(null)
    .map((_, i) => {
      const type = types[Math.floor(Math.random() * types.length)] as "hotel" | "airbnb"
      const price = 50 + Math.floor(Math.random() * 450)

      return {
        id: `property-${i}`,
        title: `${type === "hotel" ? "Hotel" : "Apartment"} ${
          ["Seaside", "Mountain View", "Downtown", "Riverside", "Garden"][i % 5]
        }`,
        location: location || "New York, USA",
        price,
        rating: 3.5 + Math.random() * 1.5,
        image: `/placeholder.svg?height=300&width=400&text=${type}+${i}`,
        type,
        lat: baseCoordinates.lat + (Math.random() * 0.02 - 0.01),
        lng: baseCoordinates.lng + (Math.random() * 0.02 - 0.01),
      }
    })
}
