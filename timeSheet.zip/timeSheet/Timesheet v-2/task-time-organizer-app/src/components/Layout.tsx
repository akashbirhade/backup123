import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { BarChart, Calendar, Clock, User, FileText, Settings, Shield } from 'lucide-react';
import Logo from './Logo';
import UserMenu from './UserMenu';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { SidebarProvider, Sidebar, SidebarTrigger } from '@/components/ui/sidebar';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const location = useLocation();
  const { isAuthenticated, isAdmin } = useAuth();
  
  const navItems = [
    { name: 'Dashboard', path: '/', icon: BarChart },
    { name: 'Calendar', path: '/calendar', icon: Calendar },
    { name: 'Timesheet', path: '/timesheet', icon: Clock },
    { name: 'Projects', path: '/projects', icon: FileText },
    { name: 'Reports', path: '/reports', icon: FileText },
    { name: 'Profile', path: '/profile', icon: User },
    { name: 'Sample Component', path: '/sample', icon: User },
  ];

  const adminItems = [
    { name: 'Events Management', path: '/admin/events', icon: Shield },
    { name: 'Employee Detail', path: '/admin/employeedetail', icon: Shield },
  ];
  const currentDate = new Date();
  const currentWeek = Math.ceil((currentDate.getDate()) / 7);
  const monthName = currentDate.toLocaleString('default', { month: 'long' });

  return (
    <SidebarProvider>
      <div className="flex h-screen">
        {/* Sidebar for desktop and sheet for mobile */}
        <Sidebar collapsible="offcanvas" className="bg-sidebar min-h-screen p-4">
          <div className="mb-4 flex items-center justify-between">
            <Logo />
            <div className="md:hidden">
              <SidebarTrigger />
            </div>
          </div>
          <nav className="flex-1">
            <ul className="space-y-0.5">
              {navItems.map((item) => (
                <li key={item.path}>
                  <Link
                    to={item.path}
                    className={cn(
                      "flex items-center px-3 py-2 rounded-md hover:bg-sidebar-accent transition-colors",
                      location.pathname === item.path ? "bg-primary text-white" : "text-gray-200"
                    )}
                  >
                    <item.icon className="h-5 w-5 mr-3" />
                    {item.name}
                  </Link>
                </li>
              ))}
            </ul>
            {isAdmin && (
              <div className="mt-6">
                <div className="px-4 py-2">
                  <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Admin</h3>
                </div>
                <ul className="space-y-1">
                  {adminItems.map((item) => (
                    <li key={item.path}>
                      <Link
                        to={item.path}
                        className={cn(
                          "flex items-center px-2 py-1 rounded-md hover:bg-sidebar-accent transition-colors",
                          location.pathname === item.path ? "bg-primary text-white" : "text-gray-200"
                        )}
                      >
                        <item.icon className="h-5 w-5 mr-3" />
                        {item.name}
                      </Link>
                    </li>
                  ))}

                </ul>
              </div>
            )}
          </nav>
          <div className="mt-auto">
            <Link
              to="/settings"
              className="flex items-center px-4 py-3 text-gray-200 rounded-md hover:bg-sidebar-accent transition-colors"
            >
              <Settings className="h-5 w-5 mr-3" />
              Settings
            </Link>
          </div>
        </Sidebar>
        {/* Mobile header */}
        <div className="md:hidden fixed top-0 left-0 right-0 bg-sidebar z-10">
          <div className="flex items-center justify-between p-4">
            <SidebarTrigger />
            <Logo />
            {isAuthenticated && <UserMenu />}
          </div>
        </div>
        {/* Main content */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Header with user menu */}
          <header className="hidden md:flex justify-between items-center p-1 bg-white border-b">
            <h1 className="text-2xl font-semibold text-gray-800 ">
              {[...navItems, ...adminItems].find(item => item.path === location.pathname)?.name || 'Dashboard'}
            </h1>
            <div className="flex items-center gap-4">
              <div className="flex justify-end bg-white p-1 rounded-lg shadow-sm border">
                <p className="text-sm text-muted-foreground">{new Date().toLocaleDateString('en-US', { day: 'numeric' })} {monthName} - </p>
                <p className="text-sm ">{new Date().toLocaleDateString('en-US', { weekday: 'long' })}</p>
              </div>
              {isAuthenticated ? (
                <UserMenu />
              ) : (
                <div className="flex gap-2">
                  <Button asChild variant="outline">
                    <Link to="/login">Login</Link>
                  </Button>
                  <Button asChild>
                    <Link to="/register">Register</Link>
                  </Button>
                </div>
              )}
            </div>
          </header>
          {/* Content */}
          <main className="flex-1 overflow-y-auto p-2 md:p-4 bg-gray-50">
            <div className="md:hidden h-16"></div> {/* Spacer for mobile header */}
            {children}
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
};

export default Layout;



// import React from 'react';
// import { Link, useLocation } from 'react-router-dom';
// import { BarChart, Calendar, Clock, User, FileText, Settings, Shield } from 'lucide-react';
// import Logo from './Logo';
// import UserMenu from './UserMenu';
// import { useAuth } from '@/hooks/useAuth';
// import { Button } from '@/components/ui/button';
// import { cn } from '@/lib/utils';
// import { SidebarProvider, Sidebar, SidebarTrigger } from '@/components/ui/sidebar';


// interface LayoutProps {
//   children: React.ReactNode;
// }

// const Layout: React.FC<LayoutProps> = ({ children }) => {
//   const location = useLocation();
//     // const location = useLocation();
//   const { isAuthenticated, isAdmin } = useAuth();
//   const navItems = [
//     { name: 'Dashboard', path: '/', icon: BarChart },
//     { name: 'Calendar', path: '/calendar', icon: Calendar },
//     { name: 'Timesheet', path: '/timesheet', icon: Clock },
//     { name: 'Projects', path: '/projects', icon: FileText },
//     { name: 'Reports', path: '/reports', icon: FileText },
//     { name: 'Profile', path: '/profile', icon: User },
//   ];
//   const adminItems = [
//     { name: 'Events Management', path: '/admin/events', icon: Shield },
//   ];
//   return (
//     <SidebarProvider>
//     <div className="flex h-screen">
//       {/* Sidebar */}
//       <div className="hidden md:flex flex-col w-64 bg-sidebar min-h-screen p-4">
//         <div className="mb-8">
//           <Logo />
//         </div>
//         <nav className="flex-1">
//           <ul className="space-y-2">
//             {navItems.map((item) => (
//               <li key={item.path}>
//                 <Link
//                   to={item.path}
//                   className={cn(
//                     "flex items-center px-4 py-3 rounded-md hover:bg-sidebar-accent transition-colors",
//                     location.pathname === item.path ? "bg-primary text-white" : "text-gray-200"
//                   )}
//                 >
//                   <item.icon className="h-5 w-5 mr-3" />
//                   {item.name}
//                 </Link>
//               </li>
//             ))}
//           </ul>
//             {isAdmin && (
//               <div className="mt-6">
//                 <div className="px-4 py-2">
//                   <h3 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Admin</h3>
//                 </div>
//                 <ul className="space-y-2">
//                   {adminItems.map((item) => (
//                     <li key={item.path}>
//                       <Link
//                         to={item.path}
//                         className={cn(
//                           "flex items-center px-4 py-3 rounded-md hover:bg-sidebar-accent transition-colors",
//                           location.pathname === item.path ? "bg-primary text-white" : "text-gray-200"
//                         )}
//                       >
//                         <item.icon className="h-5 w-5 mr-3" />
//                         {item.name}
//                       </Link>
//                     </li>
//                   ))}
//                 </ul>
//               </div>
//             )}
//         </nav>
        
//         <div className="mt-auto">
//           <Link
//             to="/settings"
//             className="flex items-center px-4 py-3 text-gray-200 rounded-md hover:bg-sidebar-accent transition-colors"
//           >
//             <Settings className="h-5 w-5 mr-3" />
//             Settings
//           </Link>
//         </div>
//       </div>

//       {/* Mobile header */}
//      <div className="md:hidden fixed top-0 left-0 right-0 bg-sidebar z-10">
//           <div className="flex items-center justify-between p-4">
//             {/* <SidebarTrigger /> */}
//             <Logo />
//             {isAuthenticated && <UserMenu />}
//           </div>
//         </div>
              
//       {/* Main content */}
//       <div className="flex-1 flex flex-col overflow-hidden">
//         {/* Content */}
//  <header className="hidden md:flex justify-between items-center p-2 bg-white border-b">
//              <h1 className="text-2xl font-semibold text-gray-800">
//                {[...navItems, ...adminItems].find(item => item.path === location.pathname)?.name || 'Dashboard'}
//              </h1>
//              {isAuthenticated ? (
//               <UserMenu />
//             ) : (
//               <div className="flex gap-2">
//                 <Button asChild variant="outline">
//                   <Link to="/login">Login</Link>
//                 </Button>
//                 <Button asChild>
//                   <Link to="/register">Register</Link>
//                 </Button>
//               </div>
//             )}
//           </header>
//         <main className="flex-1 overflow-y-auto p-0 md:p-3 bg-gray-50">
         
//           <div className="md:hidden h-16"></div> {/* Spacer for mobile header */}
//           {children}
//         </main>
//       </div>
//     </div>
//     </SidebarProvider>
//   );
// };

// export default Layout;
