"use client"

import { useEffect, useRef } from "react"
import { MapPin } from "lucide-react"

export default function TripMap({ locations = [] }) {
  const mapRef = useRef(null)

  useEffect(() => {
    // In a real app, this would use Google Maps, Mapbox, or another mapping API
    // For this demo, we'll create a simple canvas-based map visualization
    if (!mapRef.current) return

    const canvas = mapRef.current
    const ctx = canvas.getContext("2d")
    const dpr = window.devicePixelRatio || 1

    // Set canvas dimensions accounting for device pixel ratio
    const rect = canvas.getBoundingClientRect()
    canvas.width = rect.width * dpr
    canvas.height = rect.height * dpr
    ctx.scale(dpr, dpr)

    // Draw map background
    ctx.fillStyle = "#f0f9f6"
    ctx.fillRect(0, 0, rect.width, rect.height)

    // Draw some map features
    ctx.strokeStyle = "#d1e7dd"
    ctx.lineWidth = 2

    // Draw some "roads"
    for (let i = 0; i < 10; i++) {
      const x = Math.random() * rect.width
      const y = Math.random() * rect.height
      const length = 50 + Math.random() * 100
      const angle = Math.random() * Math.PI * 2

      ctx.beginPath()
      ctx.moveTo(x, y)
      ctx.lineTo(x + Math.cos(angle) * length, y + Math.sin(angle) * length)
      ctx.stroke()
    }

    // Draw location markers
    if (locations.length > 0) {
      // Normalize coordinates to fit canvas
      const points = locations.map((loc) => ({
        x: (loc.x / 100) * (rect.width - 40) + 20,
        y: (loc.y / 100) * (rect.height - 40) + 20,
        name: loc.name,
        type: loc.type,
      }))

      // Draw route lines connecting points
      ctx.strokeStyle = "#10b981"
      ctx.lineWidth = 2
      ctx.beginPath()
      ctx.moveTo(points[0].x, points[0].y)

      for (let i = 1; i < points.length; i++) {
        ctx.lineTo(points[i].x, points[i].y)
      }
      ctx.stroke()

      // Draw location markers
      points.forEach((point, index) => {
        // Draw circle for each point
        ctx.fillStyle =
          point.type === "attraction"
            ? "#10b981"
            : point.type === "restaurant"
              ? "#f59e0b"
              : point.type === "accommodation"
                ? "#3b82f6"
                : "#10b981"
        ctx.beginPath()
        ctx.arc(point.x, point.y, 6, 0, Math.PI * 2)
        ctx.fill()

        // Draw label
        ctx.fillStyle = "#000"
        ctx.font = "10px sans-serif"
        ctx.fillText(point.name, point.x + 10, point.y + 4)

        // Draw day number for sequential points
        if (index > 0) {
          ctx.fillStyle = "#fff"
          ctx.font = "8px sans-serif"
          ctx.textAlign = "center"
          ctx.fillText(index.toString(), point.x, point.y + 3)
        }
      })
    } else {
      // Draw placeholder text if no locations
      ctx.fillStyle = "#10b981"
      ctx.font = "14px sans-serif"
      ctx.textAlign = "center"
      ctx.fillText("Your trip map will appear here", rect.width / 2, rect.height / 2)
    }
  }, [locations])

  return (
    <div className="relative w-full h-full">
      <canvas ref={mapRef} className="w-full h-full rounded-md" style={{ width: "100%", height: "100%" }} />
      <div className="absolute bottom-2 right-2 bg-white p-1 rounded-md shadow-sm text-xs flex items-center">
        <MapPin className="h-3 w-3 mr-1 text-emerald-600" />
        <span>Map View</span>
      </div>
    </div>
  )
}
