
const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');
const bcrypt = require('bcrypt');

dotenv.config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

const createSchema = async () => {
  try {
    const schemaSQL = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
    await pool.query(schemaSQL);
    
    console.log('Database schema created successfully');
    
    // Create admin user
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash('admin123', salt);
    
    await pool.query(
      'INSERT INTO users (first_name, last_name, email, password, role) VALUES ($1, $2, $3, $4, $5)',
      ['Admin', 'User', 'admin@example.com', hashedPassword, 'admin']
    );
    
    console.log('Admin user created (email: admin@example.com, password: admin123)');
    
    // Add sample client and project
    const clientResult = await pool.query(
      'INSERT INTO clients (name, contact_person, email) VALUES ($1, $2, $3) RETURNING id',
      ['Sample Client', 'John Doe', 'contact@sampleclient.com']
    );
    
    const clientId = clientResult.rows[0].id;
    
    await pool.query(
      'INSERT INTO projects (name, client_id, description, start_date, end_date, status) VALUES ($1, $2, $3, $4, $5, $6)',
      ['Sample Project', clientId, 'This is a sample project', new Date(), new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), 'active']
    );
    
    console.log('Sample client and project created');
    
    pool.end();
  } catch (error) {
    console.error('Error creating database schema:', error);
    pool.end();
  }
};

createSchema();
