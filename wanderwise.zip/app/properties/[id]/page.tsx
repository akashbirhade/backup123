"use client"

import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import Link from "next/link"
import { MapPin, Star, Calendar, Wifi, Coffee, Tv, Utensils, Car, ArrowLeft, Share2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"
import PropertyMap from "@/components/property-map"

type Property = {
  id: string
  title: string
  location: string
  price: number
  rating: number
  image: string
  type: "hotel" | "airbnb"
  description: string
  amenities: string[]
  host?: {
    name: string
    image: string
    rating: number
  }
  availableDates: string[]
  lat: number
  lng: number
}

export default function PropertyDetailPage() {
  const params = useParams()
  const id = params.id as string

  const [property, setProperty] = useState<Property | null>(null)
  const [loading, setLoading] = useState(true)
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined)

  useEffect(() => {
    // In a real app, this would be an API call
    // For now, we'll simulate loading with mock data
    const timeout = setTimeout(() => {
      setProperty(getMockProperty(id))
      setLoading(false)
    }, 800)

    return () => clearTimeout(timeout)
  }, [id])

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="h-8 w-40 bg-gray-200 animate-pulse rounded mb-4" />
        <div className="h-64 bg-gray-200 animate-pulse rounded-lg mb-6" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            <div className="h-10 bg-gray-200 animate-pulse rounded mb-4" />
            <div className="h-4 bg-gray-200 animate-pulse rounded mb-2" />
            <div className="h-4 bg-gray-200 animate-pulse rounded mb-2" />
            <div className="h-4 bg-gray-200 animate-pulse rounded mb-2" />
          </div>
          <div>
            <div className="h-64 bg-gray-200 animate-pulse rounded" />
          </div>
        </div>
      </div>
    )
  }

  if (!property) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <h1 className="text-2xl font-bold mb-4">Property not found</h1>
        <p className="mb-6">The property you're looking for doesn't exist or has been removed.</p>
        <Button asChild>
          <Link href="/properties">Back to Properties</Link>
        </Button>
      </div>
    )
  }

  const isDateAvailable = (date: Date) => {
    const dateString = date.toISOString().split("T")[0]
    return property.availableDates.includes(dateString)
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <Link href="/properties" className="flex items-center text-gray-600 hover:text-gray-900 mb-6">
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back to properties
      </Link>

      <div className="relative mb-6">
        <img
          src={property.image || "/placeholder.svg"}
          alt={property.title}
          className="w-full h-[400px] object-cover rounded-lg"
        />
        <div className="absolute top-4 right-4 flex gap-2">
          <Button size="sm" variant="secondary" className="bg-white/80 backdrop-blur-sm">
            <Share2 className="h-4 w-4 mr-2" />
            Share
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2">
          <div className="flex flex-wrap items-start justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold mb-2">{property.title}</h1>
              <div className="flex items-center text-gray-600 mb-2">
                <MapPin className="h-4 w-4 mr-1" />
                <span>{property.location}</span>
              </div>
              <div className="flex items-center">
                <Star className="h-4 w-4 text-yellow-500 mr-1" />
                <span className="font-medium mr-1">{property.rating.toFixed(1)}</span>
                <span className="text-gray-600">(120 reviews)</span>
              </div>
            </div>
            <Badge className={`${property.type === "hotel" ? "bg-blue-500" : "bg-rose-500"}`}>
              {property.type === "hotel" ? "Hotel" : "Airbnb"}
            </Badge>
          </div>

          <Tabs defaultValue="details">
            <TabsList className="mb-6">
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="amenities">Amenities</TabsTrigger>
              <TabsTrigger value="location">Location</TabsTrigger>
            </TabsList>

            <TabsContent value="details" className="space-y-4">
              <div>
                <h3 className="text-xl font-semibold mb-2">About this place</h3>
                <p className="text-gray-700">{property.description}</p>
              </div>

              {property.host && (
                <div className="mt-6">
                  <h3 className="text-xl font-semibold mb-4">Host</h3>
                  <div className="flex items-center">
                    <img
                      src={property.host.image || "/placeholder.svg"}
                      alt={property.host.name}
                      className="w-12 h-12 rounded-full mr-4"
                    />
                    <div>
                      <h4 className="font-medium">{property.host.name}</h4>
                      <div className="flex items-center">
                        <Star className="h-3 w-3 text-yellow-500 mr-1" />
                        <span className="text-sm">{property.host.rating.toFixed(1)} · Superhost</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </TabsContent>

            <TabsContent value="amenities">
              <h3 className="text-xl font-semibold mb-4">What this place offers</h3>
              <div className="grid grid-cols-2 gap-4">
                {property.amenities.map((amenity) => (
                  <div key={amenity} className="flex items-center">
                    {getAmenityIcon(amenity)}
                    <span className="ml-2">{amenity}</span>
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="location">
              <h3 className="text-xl font-semibold mb-4">Location</h3>
              <div className="h-[300px] rounded-lg overflow-hidden border mb-4">
                <PropertyMap properties={[property]} center={{ lat: property.lat, lng: property.lng }} zoom={15} />
              </div>
              <p className="text-gray-700">
                Located in {property.location}. The exact location will be provided after booking.
              </p>
            </TabsContent>
          </Tabs>
        </div>

        <div>
          <Card>
            <CardContent className="p-6">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <span className="text-2xl font-bold">${property.price}</span>
                  <span className="text-gray-600"> / night</span>
                </div>
                <div className="flex items-center">
                  <Star className="h-4 w-4 text-yellow-500 mr-1" />
                  <span className="font-medium">{property.rating.toFixed(1)}</span>
                </div>
              </div>

              <div className="mb-6">
                <h3 className="font-medium mb-2">Select check-in date</h3>
                <div className="border rounded-md p-3">
                  <CalendarComponent
                    mode="single"
                    selected={selectedDate}
                    onSelect={setSelectedDate}
                    disabled={(date) => !isDateAvailable(date)}
                    className="mx-auto"
                  />
                </div>
                <p className="text-sm text-gray-500 mt-2">
                  <Calendar className="h-3 w-3 inline mr-1" />
                  {property.availableDates.length} dates available
                </p>
              </div>

              <Button className="w-full mb-4" disabled={!selectedDate}>
                {selectedDate ? "Reserve" : "Select a date"}
              </Button>

              {selectedDate && (
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>${property.price} x 1 night</span>
                    <span>${property.price}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Cleaning fee</span>
                    <span>$25</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Service fee</span>
                    <span>$15</span>
                  </div>
                  <div className="flex justify-between font-bold pt-2 border-t mt-2">
                    <span>Total</span>
                    <span>${property.price + 40}</span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

function getMockProperty(id: string): Property {
  const type = Math.random() > 0.5 ? "hotel" : "airbnb"
  const price = 50 + Math.floor(Math.random() * 450)

  const descriptions = [
    "This beautiful property offers stunning views and a peaceful atmosphere. Perfect for a relaxing getaway or a productive work trip. The space is thoughtfully designed with modern amenities and comfortable furnishings.",
    "Experience luxury and comfort in this prime location. This property features spacious rooms, elegant decor, and all the amenities you need for a memorable stay. Close to local attractions and dining options.",
    "A charming retreat in the heart of the city. This property combines convenience with comfort, offering a cozy space to relax after a day of exploration. Enjoy the local culture and cuisine just steps away.",
  ]

  const amenities = [
    "WiFi",
    "Kitchen",
    "TV",
    "Air conditioning",
    "Heating",
    "Washer",
    "Dryer",
    "Parking",
    "Pool",
    "Gym",
  ]

  // Generate 10 random dates in the next 30 days
  const availableDates = Array(10)
    .fill(null)
    .map(() => {
      const date = new Date()
      date.setDate(date.getDate() + Math.floor(Math.random() * 30))
      return date.toISOString().split("T")[0]
    })
    .sort()

  return {
    id,
    title: `${type === "hotel" ? "Hotel" : "Apartment"} ${
      ["Seaside", "Mountain View", "Downtown", "Riverside", "Garden"][Math.floor(Math.random() * 5)]
    }`,
    location: "New York, USA",
    price,
    rating: 3.5 + Math.random() * 1.5,
    image: `/placeholder.svg?height=600&width=1200&text=${type}+${id}`,
    type: type as "hotel" | "airbnb",
    description: descriptions[Math.floor(Math.random() * descriptions.length)],
    amenities: amenities.sort(() => 0.5 - Math.random()).slice(0, 6),
    host:
      type === "airbnb"
        ? {
            name: "Alex Johnson",
            image: "/placeholder.svg?height=100&width=100&text=Host",
            rating: 4.8,
          }
        : undefined,
    availableDates,
    lat: 40.7128 + (Math.random() * 0.1 - 0.05),
    lng: -74.006 + (Math.random() * 0.1 - 0.05),
  }
}

function getAmenityIcon(amenity: string) {
  switch (amenity.toLowerCase()) {
    case "wifi":
      return <Wifi className="h-5 w-5 text-gray-600" />
    case "kitchen":
      return <Utensils className="h-5 w-5 text-gray-600" />
    case "tv":
      return <Tv className="h-5 w-5 text-gray-600" />
    case "parking":
      return <Car className="h-5 w-5 text-gray-600" />
    case "coffee":
    case "breakfast":
      return <Coffee className="h-5 w-5 text-gray-600" />
    default:
      return <div className="h-5 w-5 rounded-full bg-gray-200" />
  }
}
