"use client"

import { useEffect, useRef } from "react"

type Property = {
  id: string
  title: string
  location: string
  price: number
  rating: number
  image: string
  type: "hotel" | "airbnb"
  lat: number
  lng: number
}

type PropertyMapProps = {
  properties: Property[]
  center?: { lat: number; lng: number }
  zoom?: number
}

export default function PropertyMap({ properties, center, zoom = 13 }: PropertyMapProps) {
  const mapRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // This is a placeholder for Google Maps integration
    // In a real app, you would use the Google Maps JavaScript API
    if (mapRef.current) {
      const mapElement = mapRef.current

      // Create a simple placeholder map
      mapElement.innerHTML = ""
      const mapContainer = document.createElement("div")
      mapContainer.className = "w-full h-full bg-gray-100 relative"

      // Calculate center if not provided
      const mapCenter = center || {
        lat: properties.reduce((sum, p) => sum + p.lat, 0) / Math.max(properties.length, 1),
        lng: properties.reduce((sum, p) => sum + p.lng, 0) / Math.max(properties.length, 1),
      }

      // Add a simple representation of the center
      const centerMarker = document.createElement("div")
      centerMarker.className = "absolute w-4 h-4 bg-blue-500 rounded-full transform -translate-x-1/2 -translate-y-1/2"
      centerMarker.style.left = "50%"
      centerMarker.style.top = "50%"
      mapContainer.appendChild(centerMarker)

      // Add property markers
      properties.forEach((property, index) => {
        const marker = document.createElement("div")

        // Calculate position relative to center (this is a simplified version)
        const latOffset = (property.lat - mapCenter.lat) * 1000
        const lngOffset = (property.lng - mapCenter.lng) * 1000

        marker.className = `absolute w-6 h-6 rounded-full transform -translate-x-1/2 -translate-y-1/2 flex items-center justify-center text-white text-xs font-bold ${
          property.type === "hotel" ? "bg-blue-500" : "bg-rose-500"
        }`
        marker.style.left = `calc(50% + ${lngOffset}px)`
        marker.style.top = `calc(50% + ${-latOffset}px)`
        marker.textContent = `${index + 1}`

        // Add tooltip on hover
        marker.title = `${property.title} - $${property.price}`

        mapContainer.appendChild(marker)
      })

      // Add map info
      const mapInfo = document.createElement("div")
      mapInfo.className = "absolute bottom-2 left-2 bg-white p-2 rounded shadow text-sm"
      mapInfo.textContent = `${properties.length} properties shown • Zoom: ${zoom}`
      mapContainer.appendChild(mapInfo)

      // Add a note about the placeholder
      const placeholderNote = document.createElement("div")
      placeholderNote.className = "absolute top-2 left-2 right-2 bg-white p-2 rounded shadow text-sm text-center"
      placeholderNote.textContent = "Map placeholder - would use Google Maps API in production"
      mapContainer.appendChild(placeholderNote)

      mapElement.appendChild(mapContainer)
    }
  }, [properties, center, zoom])

  return <div ref={mapRef} className="w-full h-full" />
}
