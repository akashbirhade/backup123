
import React from 'react';
import { format } from 'date-fns';
import { Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import TaskRow from './TaskRow';
import { Timesheet, Project, AbsenceDay } from '@/types/timesheet';

interface TimesheetTableProps {
  timesheet: Timesheet;
  days: Date[];
  readOnly: boolean;
  onHoursChange: (value: string, dayIndex: number, taskId: string) => void;
  onDescriptionChange: (taskId: string, description: string) => void;
  onAbsenceClick: (day: Date) => void;
}

const TimesheetTable: React.FC<TimesheetTableProps> = ({
  timesheet,
  days,
  readOnly,
  onHoursChange,
  onDescriptionChange,
  onAbsenceClick
}) => {
  const getAbsenceForDay = (day: Date) => {
    return timesheet.absenceDays.find(absence => 
      new Date(absence.date).getDate() === day.getDate() &&
      new Date(absence.date).getMonth() === day.getMonth() &&
      new Date(absence.date).getFullYear() === day.getFullYear()
    );
  };

  const calculateTotalHours = () => {
    return timesheet.totalHours.reduce((sum, hours) => sum + hours, 0);
  };

  const renderAbsenceIndicator = (day: Date) => {
    const absence = getAbsenceForDay(day);
    if (!absence) return null;

    return (
      <div className="text-xs">
        {absence.type === 'leave' ? 'Leave' : 
        absence.type === 'half-day' ? 'Half-day' : 'Holiday'}
      </div>
    );
  };

  return (
    <table className="w-full">
      <thead>
        <tr>
          <th className="timesheet-header w-48">Client Name</th>
          <th className="timesheet-header w-48">Project Name</th>
          <th className="timesheet-header flex-1">JIRA Issue/Work Description</th>
          {days.map((day, i) => (
            <th key={i} className="timesheet-header relative">
              <div className="flex justify-between items-center">
                <div>
                  <div>{format(day, "dd-MM-yyyy")}</div>
                  <div>{format(day, "EEEE")}</div>
                </div>
                {!readOnly && (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-7 w-7 p-0">
                        <Clock className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => onAbsenceClick(day)}>
                        <Clock className="mr-2 h-4 w-4" />
                        <span>Record Absence</span>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                )}
              </div>
            </th>
          ))}
          <th className="timesheet-header">Weekly Totals</th>
        </tr>
      </thead>
      <tbody>
        {timesheet.projects.length > 0 ? (
          timesheet.projects.map((project: Project) => (
            project.tasks.map((task, taskIndex) => (
              <TaskRow
                key={task.id}
                task={task}
                isFirstTaskInProject={taskIndex === 0}
                clientName={project.clientName}
                projectName={project.name}
                days={days}
                absenceDays={timesheet.absenceDays}
                readOnly={readOnly}
                onHoursChange={onHoursChange}
                onDescriptionChange={onDescriptionChange}
              />
            ))
          ))
        ) : (
          <tr>
            <td colSpan={days.length + 4} className="p-4 text-center text-muted-foreground">
              No tasks added yet. {!readOnly && "Use the form below to add tasks."}
            </td>
          </tr>
        )}

        <tr className="bg-gray-100">
          <td colSpan={3} className="p-2 border border-gray-300 text-right font-bold">
            Total Daily Hours
          </td>
          {timesheet.totalHours.map((total, i) => {
            const dayAbsence = getAbsenceForDay(days[i]);
            let bgClass = '';
            
            if (dayAbsence) {
              if (dayAbsence.type === 'leave' || dayAbsence.type === 'holiday') {
                bgClass = 'bg-red-100';
              } else if (dayAbsence.type === 'half-day') {
                bgClass = 'bg-amber-100';
              }
            }
            
            return (
              <td key={i} className={`time-cell font-bold border border-gray-300 ${bgClass}`}>
                {total}
                {renderAbsenceIndicator(days[i])}
              </td>
            );
          })}
          <td className="time-cell font-bold border border-gray-300">
            {calculateTotalHours()}
          </td>
        </tr>
      </tbody>
    </table>
  );
};

export default TimesheetTable;
