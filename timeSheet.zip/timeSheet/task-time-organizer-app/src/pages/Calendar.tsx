
import React from 'react';
import CalendarView from '@/components/CalendarView';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const Calendar = () => {
  return (
    <div className="containe mx-aut">
      <h1 className="text-3xl font-bold mb-6">Calendar View</h1>
      <Card>
        <CardHeader>
          <CardTitle>Timesheet Calendar</CardTitle>
        </CardHeader>
        <CardContent>
          <CalendarView initialExpanded={true} />
        </CardContent>
      </Card>
    </div>
  );
};

export default Calendar;
