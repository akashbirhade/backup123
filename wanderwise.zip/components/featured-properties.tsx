"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Star, MapPin } from "lucide-react"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

type Property = {
  id: string
  title: string
  location: string
  price: number
  rating: number
  image: string
  type: "hotel" | "airbnb"
}

type FeaturedPropertiesProps = {
  category: "budget" | "mid-range" | "luxury"
}

export default function FeaturedProperties({ category }: FeaturedPropertiesProps) {
  const [properties, setProperties] = useState<Property[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // In a real app, this would be an API call
    // For now, we'll simulate loading with mock data
    const timeout = setTimeout(() => {
      setProperties(getMockProperties(category))
      setLoading(false)
    }, 500)

    return () => clearTimeout(timeout)
  }, [category])

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="overflow-hidden">
            <div className="h-48 bg-gray-200 animate-pulse" />
            <CardContent className="p-4">
              <div className="h-6 bg-gray-200 animate-pulse rounded mb-2" />
              <div className="h-4 bg-gray-200 animate-pulse rounded w-3/4 mb-4" />
              <div className="h-4 bg-gray-200 animate-pulse rounded w-1/2" />
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {properties.map((property) => (
        <Link href={`/properties/${property.id}`} key={property.id}>
          <Card className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer h-full flex flex-col">
            <div className="relative h-48 overflow-hidden">
              <img
                src={property.image || "/placeholder.svg"}
                alt={property.title}
                className="w-full h-full object-cover transition-transform hover:scale-105"
              />
              <Badge className={`absolute top-2 right-2 ${property.type === "hotel" ? "bg-blue-500" : "bg-rose-500"}`}>
                {property.type === "hotel" ? "Hotel" : "Airbnb"}
              </Badge>
            </div>
            <CardContent className="p-4 flex-grow">
              <h3 className="font-semibold text-lg mb-1">{property.title}</h3>
              <div className="flex items-center text-gray-500 mb-2">
                <MapPin className="h-4 w-4 mr-1" />
                <span className="text-sm">{property.location}</span>
              </div>
              <div className="flex items-center">
                <Star className="h-4 w-4 text-yellow-500 mr-1" />
                <span className="text-sm font-medium">{property.rating.toFixed(1)}</span>
              </div>
            </CardContent>
            <CardFooter className="p-4 pt-0 border-t">
              <div className="flex justify-between items-center w-full">
                <span className="font-bold text-lg">${property.price}</span>
                <span className="text-gray-500 text-sm">per night</span>
              </div>
            </CardFooter>
          </Card>
        </Link>
      ))}
    </div>
  )
}

function getMockProperties(category: string): Property[] {
  const priceRanges = {
    budget: { min: 30, max: 80 },
    "mid-range": { min: 80, max: 200 },
    luxury: { min: 200, max: 500 },
  }

  const range = priceRanges[category as keyof typeof priceRanges]

  const locations = [
    "Paris, France",
    "Bali, Indonesia",
    "New York, USA",
    "Tokyo, Japan",
    "Barcelona, Spain",
    "London, UK",
  ]

  return Array(6)
    .fill(null)
    .map((_, i) => {
      const price = Math.floor(Math.random() * (range.max - range.min + 1)) + range.min
      const type = Math.random() > 0.5 ? "hotel" : "airbnb"
      const location = locations[Math.floor(Math.random() * locations.length)]

      return {
        id: `property-${category}-${i}`,
        title: `${type === "hotel" ? "Hotel" : "Apartment"} ${
          category === "luxury" ? "Luxury " : ""
        }${["Seaside", "Mountain View", "Downtown", "Riverside", "Garden"][i % 5]}`,
        location,
        price,
        rating: 3.5 + Math.random() * 1.5,
        image: `/placeholder.svg?height=300&width=400&text=${type}+${i}`,
        type,
      }
    })
}
