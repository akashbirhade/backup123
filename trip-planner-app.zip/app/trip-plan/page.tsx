"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Calendar, MapPin, Utensils, Home, Clock, DollarSign, Save, Share2, Edit } from "lucide-react"
import TripMap from "@/components/trip-map"
import { generateMockItinerary } from "@/lib/mock-data"

export default function TripPlanPage() {
  const router = useRouter()
  const [tripData, setTripData] = useState(null)
  const [itinerary, setItinerary] = useState(null)

  useEffect(() => {
    // In a real app, we would fetch this from an API
    const savedTrip = localStorage.getItem("tripPlan")

    if (!savedTrip) {
      router.push("/create-trip")
      return
    }

    const parsedTrip = JSON.parse(savedTrip)
    setTripData(parsedTrip)

    // Generate mock itinerary based on trip data
    const mockItinerary = generateMockItinerary(parsedTrip)

    // If there's an accommodation in the trip data, add it to the itinerary
    if (parsedTrip.accommodation) {
      mockItinerary.accommodations = [
        {
          name: parsedTrip.accommodation.title,
          location: parsedTrip.accommodation.location,
          description: parsedTrip.accommodation.description || "Your booked accommodation",
          price: parsedTrip.accommodation.price,
          nights: calculateNights(parsedTrip.dateRange),
          amenities: parsedTrip.accommodation.amenities || ["WiFi", "Kitchen", "Air Conditioning"],
          checkIn: "3:00 PM",
          checkOut: "11:00 AM",
          image: parsedTrip.accommodation.image || "/placeholder.svg?height=200&width=300",
        },
        ...mockItinerary.accommodations.slice(0, 1),
      ]

      // Update budget
      mockItinerary.budget.accommodations = parsedTrip.accommodation.price * calculateNights(parsedTrip.dateRange)
      mockItinerary.budget.total =
        mockItinerary.budget.accommodations +
        mockItinerary.budget.food +
        mockItinerary.budget.attractions +
        mockItinerary.budget.transportation
    }

    setItinerary(mockItinerary)
  }, [router])

  const calculateNights = (dateRange) => {
    if (!dateRange?.from || !dateRange?.to) return 3

    const from = new Date(dateRange.from)
    const to = new Date(dateRange.to)
    return Math.ceil((to - from) / (1000 * 60 * 60 * 24))
  }

  if (!tripData || !itinerary) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <p>Loading your trip plan...</p>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
        <div>
          <h1 className="text-3xl font-bold">{tripData.destination} Trip</h1>
          <p className="text-gray-600">
            {tripData.dateRange.from && new Date(tripData.dateRange.from).toLocaleDateString()} -
            {tripData.dateRange.to && new Date(tripData.dateRange.to).toLocaleDateString()}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Edit className="h-4 w-4 mr-2" />
            Edit Plan
          </Button>
          <Button variant="outline" size="sm">
            <Save className="h-4 w-4 mr-2" />
            Save
          </Button>
          <Button variant="outline" size="sm">
            <Share2 className="h-4 w-4 mr-2" />
            Share
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card className="mb-6">
            <CardHeader className="pb-2">
              <CardTitle>Trip Overview</CardTitle>
              <CardDescription>
                A {tripData.tripType} trip with a budget of ${tripData.budget}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px] w-full rounded-md overflow-hidden mb-4">
                <TripMap locations={itinerary.mapLocations} />
              </div>
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline" className="bg-emerald-50">
                  <Calendar className="h-3 w-3 mr-1" />
                  {itinerary.days.length} Days
                </Badge>
                <Badge variant="outline" className="bg-emerald-50">
                  <MapPin className="h-3 w-3 mr-1" />
                  {itinerary.attractions.length} Attractions
                </Badge>
                <Badge variant="outline" className="bg-emerald-50">
                  <Utensils className="h-3 w-3 mr-1" />
                  {itinerary.restaurants.length} Restaurants
                </Badge>
                <Badge variant="outline" className="bg-emerald-50">
                  <Home className="h-3 w-3 mr-1" />
                  {itinerary.accommodations.length} Accommodations
                </Badge>
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="itinerary">
            <TabsList className="mb-4">
              <TabsTrigger value="itinerary">Daily Itinerary</TabsTrigger>
              <TabsTrigger value="attractions">Attractions</TabsTrigger>
              <TabsTrigger value="restaurants">Restaurants</TabsTrigger>
              <TabsTrigger value="accommodations">Accommodations</TabsTrigger>
            </TabsList>

            <TabsContent value="itinerary" className="space-y-4">
              {itinerary.days.map((day, index) => (
                <Card key={index}>
                  <CardHeader className="pb-2">
                    <CardTitle>Day {index + 1}</CardTitle>
                    <CardDescription>{day.date}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {day.activities.map((activity, actIndex) => (
                      <div key={actIndex} className="mb-4 last:mb-0">
                        <div className="flex items-start">
                          <div className="bg-emerald-100 text-emerald-800 rounded-full h-7 w-7 flex items-center justify-center text-xs font-medium mr-3 mt-0.5">
                            {activity.time}
                          </div>
                          <div>
                            <h4 className="font-medium">{activity.title}</h4>
                            <p className="text-sm text-gray-600">{activity.description}</p>
                            <div className="flex items-center mt-1 text-xs text-gray-500">
                              <MapPin className="h-3 w-3 mr-1" />
                              {activity.location}
                              {activity.duration && (
                                <>
                                  <Clock className="h-3 w-3 ml-3 mr-1" />
                                  {activity.duration}
                                </>
                              )}
                              {activity.cost && (
                                <>
                                  <DollarSign className="h-3 w-3 ml-3 mr-1" />
                                  {activity.cost}
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                        {actIndex < day.activities.length - 1 && (
                          <div className="ml-3.5 pl-3.5 mt-2 mb-2 border-l-2 border-dashed border-gray-200 h-4"></div>
                        )}
                      </div>
                    ))}
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="attractions" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {itinerary.attractions.map((attraction, index) => (
                  <AttractionCard key={index} attraction={attraction} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="restaurants" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {itinerary.restaurants.map((restaurant, index) => (
                  <RestaurantCard key={index} restaurant={restaurant} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="accommodations" className="space-y-4">
              {itinerary.accommodations.map((accommodation, index) => (
                <AccommodationCard key={index} accommodation={accommodation} />
              ))}
            </TabsContent>
          </Tabs>
        </div>

        <div>
          <Card className="sticky top-4">
            <CardHeader>
              <CardTitle>Trip Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="font-medium mb-2">Budget Breakdown</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Accommodations</span>
                      <span>${itinerary.budget.accommodations}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Food & Dining</span>
                      <span>${itinerary.budget.food}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Attractions</span>
                      <span>${itinerary.budget.attractions}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Transportation</span>
                      <span>${itinerary.budget.transportation}</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between font-medium">
                      <span>Total</span>
                      <span>${itinerary.budget.total}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="font-medium mb-2">Weather Forecast</h3>
                  <div className="space-y-2">
                    {itinerary.weather.map((day, index) => (
                      <div key={index} className="flex justify-between items-center">
                        <span className="text-gray-600">{day.date}</span>
                        <div className="flex items-center">
                          <span className="mr-2">{day.condition}</span>
                          <span>{day.temperature}°C</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="font-medium mb-2">Local Tips</h3>
                  <ul className="list-disc pl-5 space-y-1 text-gray-600">
                    {itinerary.localTips.map((tip, index) => (
                      <li key={index}>{tip}</li>
                    ))}
                  </ul>
                </div>

                <Button className="w-full bg-emerald-600 hover:bg-emerald-700">Download Itinerary</Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

function AttractionCard({ attraction }) {
  return (
    <Card>
      <div className="h-40 w-full bg-gray-200 rounded-t-lg overflow-hidden">
        <img
          src={attraction.image || `/placeholder.svg?height=160&width=320`}
          alt={attraction.name}
          className="w-full h-full object-cover"
        />
      </div>
      <CardContent className="pt-4">
        <h3 className="font-semibold text-lg">{attraction.name}</h3>
        <div className="flex items-center text-xs text-gray-500 mt-1 mb-2">
          <MapPin className="h-3 w-3 mr-1" />
          {attraction.location}
          {attraction.duration && (
            <>
              <Clock className="h-3 w-3 ml-3 mr-1" />
              {attraction.duration}
            </>
          )}
        </div>
        <p className="text-sm text-gray-600 line-clamp-3">{attraction.description}</p>
        <div className="mt-3 flex items-center justify-between">
          <Badge variant="outline">{attraction.category}</Badge>
          <span className="text-sm font-medium">{attraction.cost}</span>
        </div>
      </CardContent>
    </Card>
  )
}

function RestaurantCard({ restaurant }) {
  return (
    <Card>
      <div className="h-40 w-full bg-gray-200 rounded-t-lg overflow-hidden">
        <img
          src={restaurant.image || `/placeholder.svg?height=160&width=320`}
          alt={restaurant.name}
          className="w-full h-full object-cover"
        />
      </div>
      <CardContent className="pt-4">
        <h3 className="font-semibold text-lg">{restaurant.name}</h3>
        <div className="flex items-center text-xs text-gray-500 mt-1 mb-2">
          <MapPin className="h-3 w-3 mr-1" />
          {restaurant.location}
        </div>
        <p className="text-sm text-gray-600 mb-2">{restaurant.description}</p>
        <div className="flex items-center justify-between">
          <Badge variant="outline">{restaurant.cuisine}</Badge>
          <span className="text-sm font-medium">{restaurant.priceRange}</span>
        </div>
      </CardContent>
    </Card>
  )
}

function AccommodationCard({ accommodation }) {
  return (
    <Card className="mb-4">
      <div className="md:flex">
        <div className="md:w-1/3 h-48 md:h-auto bg-gray-200 rounded-t-lg md:rounded-l-lg md:rounded-tr-none overflow-hidden">
          <img
            src={accommodation.image || `/placeholder.svg?height=200&width=300`}
            alt={accommodation.name}
            className="w-full h-full object-cover"
          />
        </div>
        <div className="md:w-2/3">
          <CardContent className="pt-4">
            <h3 className="font-semibold text-lg">{accommodation.name}</h3>
            <div className="flex items-center text-xs text-gray-500 mt-1 mb-2">
              <MapPin className="h-3 w-3 mr-1" />
              {accommodation.location}
            </div>
            <p className="text-sm text-gray-600 mb-3">{accommodation.description}</p>
            <div className="flex flex-wrap gap-2 mb-3">
              {accommodation.amenities.map((amenity, index) => (
                <Badge key={index} variant="outline" className="bg-gray-50">
                  {amenity}
                </Badge>
              ))}
            </div>
            <div className="flex items-center justify-between">
              <div>
                <span className="text-sm text-gray-600">
                  {accommodation.checkIn} - {accommodation.checkOut}
                </span>
              </div>
              <div className="text-right">
                <div className="text-sm text-gray-600">{accommodation.nights} nights</div>
                <div className="font-semibold">${accommodation.price}</div>
              </div>
            </div>
          </CardContent>
        </div>
      </div>
    </Card>
  )
}
