import React, { useState, useEffect } from 'react';
import { addDays, format, isSameDay } from 'date-fns';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Timesheet as TimesheetType, Project } from '@/types/timesheet';
import { toast } from 'sonner';
import { useAuth } from '@/context/AuthContext';
import { useSearchParams } from 'react-router-dom';

// Import our new components
import TimesheetHeader from '@/components/timesheet/TimesheetHeader';
import TimesheetTable from '@/components/timesheet/TimesheetTable';
import TimeEntryForm from '@/components/timesheet/TimeEntryForm';
import AbsenceDialog from '@/components/timesheet/AbsenceDialog';
import TimesheetActions from '@/components/timesheet/TimesheetActions';

// Dummy data for projects
const dummyProjects = [
  { id: 'p1', name: 'Project Alpha', clientId: 'c1', clientName: 'Client A' },
  { id: 'p2', name: 'Project Beta', clientId: 'c2', clientName: 'Client B' },
  { id: 'p3', name: 'Project Gamma', clientId: 'c1', clientName: 'Client A' },
  { id: 'p4', name: 'Project Delta', clientId: 'c3', clientName: 'Client C' },
];

// Mock timesheet data for different employees
const employeeTimesheets: Record<string, TimesheetType> = {
  'e1': {
    id: 'ts1',
    employeeId: 'e1',
    employeeName: 'Akash Birhade',
    weekStarting: new Date(),
    weekEnding: addDays(new Date(), 6),
    projects: [
      {
        id: 'p1',
        name: 'Project Alpha',
        clientId: 'c1',
        clientName: 'Client A',
        tasks: [
          {
            id: 't1',
            projectId: 'p1',
            description: 'Creating UI for SMB Lead and review code structure',
            hours: ['8', '8', '8', '6', '4', '0', '0']
          },
          {
            id: 't2',
            projectId: 'p1',
            description: 'Meeting on Estimation',
            hours: ['0', '0', '0', '2', '0', '0', '0']
          }
        ]
      }
    ],
    status: 'draft',
    totalHours: [8, 8, 8, 8, 4, 0, 0],
    absenceDays: [
      {
        date: addDays(new Date(), 6),
        type: 'holiday',
        note: 'Weekend'
      }
    ]
  },
  'e2': {
    id: 'ts2',
    employeeId: 'e2',
    employeeName: 'John Doe',
    weekStarting: new Date(),
    weekEnding: addDays(new Date(), 6),
    projects: [
      {
        id: 'p2',
        name: 'Project Beta',
        clientId: 'c2',
        clientName: 'Client B',
        tasks: [
          {
            id: 't3',
            projectId: 'p2',
            description: 'UX Design for Mobile App',
            hours: ['7', '8', '7', '8', '8', '0', '0']
          }
        ]
      }
    ],
    status: 'draft',
    totalHours: [7, 8, 7, 8, 8, 0, 0],
    absenceDays: [
      {
        date: addDays(new Date(), 5),
        type: 'holiday',
        note: 'Weekend'
      },
      {
        date: addDays(new Date(), 6),
        type: 'holiday',
        note: 'Weekend'
      }
    ]
  },
  'e3': {
    id: 'ts3',
    employeeId: 'e3',
    employeeName: 'Jane Smith',
    weekStarting: new Date(),
    weekEnding: addDays(new Date(), 6),
    projects: [
      {
        id: 'p4',
        name: 'Project Delta',
        clientId: 'c3',
        clientName: 'Client C',
        tasks: [
          {
            id: 't4',
            projectId: 'p4',
            description: 'Product Requirements Documentation',
            hours: ['8', '8', '6', '8', '6', '0', '0']
          },
          {
            id: 't5',
            projectId: 'p4',
            description: 'Stakeholder Meetings',
            hours: ['0', '0', '2', '0', '2', '0', '0']
          }
        ]
      }
    ],
    status: 'draft',
    totalHours: [8, 8, 8, 8, 8, 0, 0],
    absenceDays: [
      {
        date: addDays(new Date(), 6),
        type: 'holiday',
        note: 'Weekend'
      }
    ]
  }
};

const Timesheet = () => {
  const [startDate, setStartDate] = useState<Date>(new Date());
  const [endDate, setEndDate] = useState<Date>(addDays(new Date(), 6));
  const [days, setDays] = useState<Date[]>([]);
  const [timesheet, setTimesheet] = useState<TimesheetType | null>(null);
  
  // Absence related states
  const [isAbsenceDialogOpen, setIsAbsenceDialogOpen] = useState<boolean>(false);
  const [selectedDay, setSelectedDay] = useState<Date | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Auth context
  const { user } = useAuth();
  const [searchParams] = useSearchParams();
  const viewingEmployeeId = searchParams.get('employeeId');
  
  // Determine which employee's timesheet to show
  const effectiveEmployeeId = viewingEmployeeId || (user?.employeeId || 'e1');

  // Generate day headers
  useEffect(() => {
    if (startDate && endDate) {
      const daysList = [];
      let currentDay = new Date(startDate);
      while (currentDay <= endDate) {
        daysList.push(new Date(currentDay));
        currentDay = addDays(currentDay, 1);
      }
      setDays(daysList);
    }
  }, [startDate, endDate]);

  // Initialize or update timesheet
  useEffect(() => {
    if (startDate && endDate) {
      // In a real app, you'd load from an API
      let initialTimesheet = employeeTimesheets[effectiveEmployeeId];
      
      if (!initialTimesheet) {
        // Fallback to a default timesheet if no data for this employee
        initialTimesheet = {
          id: `ts_new_${Date.now()}`,
          employeeId: effectiveEmployeeId,
          employeeName: user?.name || 'Employee',
          weekStarting: startDate,
          weekEnding: endDate,
          projects: [],
          status: 'draft',
          totalHours: Array(7).fill(0),
          absenceDays: []
        };
      }
      
      setTimesheet({
        ...initialTimesheet,
        weekStarting: startDate,
        weekEnding: endDate
      });
    }
  }, [startDate, endDate, effectiveEmployeeId, user]);

  const handleDateChange = (start: Date, end: Date) => {
    setStartDate(start);
    setEndDate(end);
  };

  const handleHoursChange = (value: string, dayIndex: number, taskId: string) => {
    if (!timesheet) return;

    const updatedTimesheet = { ...timesheet };
    const numValue = value === '' ? '0' : value;

    // Update the hours for the specific task
    updatedTimesheet.projects = updatedTimesheet.projects.map(project => {
      const updatedTasks = project.tasks.map(task => {
        if (task.id === taskId) {
          const updatedHours = [...task.hours];
          updatedHours[dayIndex] = value;
          return { ...task, hours: updatedHours };
        }
        return task;
      });
      return { ...project, tasks: updatedTasks };
    });

    // Recalculate total hours for each day
    const totalDays = updatedTimesheet.totalHours.length;
    const newTotalHours = Array(totalDays).fill(0);

    updatedTimesheet.projects.forEach(project => {
      project.tasks.forEach(task => {
        task.hours.forEach((hourStr, idx) => {
          const hours = hourStr === '' ? 0 : parseFloat(hourStr);
          if (!isNaN(hours)) {
            newTotalHours[idx] += hours;
          }
        });
      });
    });

    updatedTimesheet.totalHours = newTotalHours;
    setTimesheet(updatedTimesheet);
  };

  const handleAddTask = (projectId: string, taskDescription: string) => {
    if (!projectId || !taskDescription || !timesheet) return;

    const projectToUpdate = timesheet.projects.find(p => p.id === projectId);
    
    if (!projectToUpdate) {
      // Project doesn't exist in timesheet yet, add it
      const projectData = dummyProjects.find(p => p.id === projectId);
      if (!projectData) return;
      
      const newProject: Project = {
        ...projectData,
        tasks: [
          {
            id: `t${Date.now()}`,
            projectId: projectId,
            description: taskDescription,
            hours: Array(days.length).fill('0')
          }
        ]
      };
      
      const updatedTimesheet = {
        ...timesheet,
        projects: [...timesheet.projects, newProject]
      };
      
      setTimesheet(updatedTimesheet);
    } else {
      // Project exists, just add the task
      const newTask = {
        id: `t${Date.now()}`,
        projectId: projectId,
        description: taskDescription,
        hours: Array(days.length).fill('0')
      };
      
      const updatedTimesheet = {
        ...timesheet,
        projects: timesheet.projects.map(project => {
          if (project.id === projectId) {
            return {
              ...project,
              tasks: [...project.tasks, newTask]
            };
          }
          return project;
        })
      };
      
      setTimesheet(updatedTimesheet);
    }
  };

  const handleSubmitTimesheet = () => {
    // Prevent multiple submissions
    if (isSubmitting) return;
    setIsSubmitting(true);
    
    // In a real app, you'd send to an API
    setTimeout(() => {
      if (timesheet) {
        setTimesheet({
          ...timesheet,
          status: 'submitted'
        });
        
        // Update the global store (would be an API call in real app)
        employeeTimesheets[effectiveEmployeeId] = {
          ...timesheet,
          status: 'submitted'
        };
        
        toast.success("Timesheet submitted successfully!");
        setIsSubmitting(false);
      }
    }, 1000);
  };

  const handleEditDescription = (taskId: string, newDescription: string) => {
    if (!timesheet) return;

    const updatedTimesheet = {
      ...timesheet,
      projects: timesheet.projects.map(project => ({
        ...project,
        tasks: project.tasks.map(task =>
          task.id === taskId
            ? { ...task, description: newDescription }
            : task
        ),
      })),
    };

    setTimesheet(updatedTimesheet);
  };

  // Absence management
  const openAbsenceDialog = (day: Date) => {
    setSelectedDay(day);
    setIsAbsenceDialogOpen(true);
  };

  const getExistingAbsence = (day: Date | null) => {
    if (!day || !timesheet) return undefined;
    
    return timesheet.absenceDays.find(absence => 
      isSameDay(new Date(absence.date), day)
    );
  };
  
  const handleAbsenceSubmit = (absenceType: 'leave' | 'half-day' | 'holiday', absenceNote: string) => {
    if (!timesheet || !selectedDay) return;
    
    const updatedTimesheet = { ...timesheet };
    
    // Remove any existing absence for this day
    const filteredAbsences = updatedTimesheet.absenceDays.filter(absence => 
      !isSameDay(new Date(absence.date), selectedDay)
    );
    
    // Add the new absence
    const newAbsence = {
      date: selectedDay,
      type: absenceType,
      note: absenceNote.trim() || undefined
    };
    
    updatedTimesheet.absenceDays = [...filteredAbsences, newAbsence];
    
    // For half day, allow 4 hours of work, for leave/holiday set all hours to 0
    const dayIndex = days.findIndex(day => isSameDay(day, selectedDay));
    
    if (dayIndex !== -1) {
      // Set all task hours for this day based on absence type
      updatedTimesheet.projects = updatedTimesheet.projects.map(project => ({
        ...project,
        tasks: project.tasks.map(task => {
          const updatedHours = [...task.hours];
          // Only update if there are actual hours to modify
          if (absenceType === 'half-day') {
            // For half-day, only set to 0 if current value is more than 4
            const currentHours = parseFloat(updatedHours[dayIndex] || '0');
            if (currentHours > 4) {
              updatedHours[dayIndex] = '4';
            }
          } else {
            // For full leave or holiday, set to 0
            updatedHours[dayIndex] = '0';
          }
          return { ...task, hours: updatedHours };
        })
      }));
      
      // Update total hours for the day
      const newTotalHours = [...updatedTimesheet.totalHours];
      if (absenceType === 'half-day') {
        newTotalHours[dayIndex] = Math.min(newTotalHours[dayIndex], 4);
      } else {
        newTotalHours[dayIndex] = 0;
      }
      updatedTimesheet.totalHours = newTotalHours;
    }
    
    setTimesheet(updatedTimesheet);
    setIsAbsenceDialogOpen(false);
    toast.success(`${absenceType === 'holiday' ? 'Holiday' : absenceType === 'half-day' ? 'Half-day' : 'Leave'} recorded successfully!`);
  };

  // Check if viewing as admin
  const isAdmin = user?.role === 'admin';
  const readOnly = isAdmin || timesheet?.status !== 'draft';
  const calculateTotalHours = () => timesheet ? timesheet.totalHours.reduce((sum, hours) => sum + hours, 0) : 0;

  if (!timesheet) {
    return <div className="flex justify-center items-center h-64">Loading timesheet...</div>;
  }

  return (
    <div className="space-y-6">
      <TimesheetHeader
        employeeName={timesheet.employeeName}
        startDate={startDate}
        endDate={endDate}
        isAdmin={isAdmin}
        onDateChange={handleDateChange}
      />

      <Card>
        <CardHeader className="bg-primary text-white">
          <CardTitle>Weekly Time Sheet</CardTitle>
        </CardHeader>

        <CardContent className="p-0 overflow-x-auto">
          <TimesheetTable
            timesheet={timesheet}
            days={days}
            readOnly={readOnly}
            onHoursChange={handleHoursChange}
            onDescriptionChange={handleEditDescription}
            onAbsenceClick={openAbsenceDialog}
          />
        </CardContent>
        
        {!readOnly && (
          <CardFooter className="flex flex-col md:flex-row gap-4 p-4 items-start">
            <TimeEntryForm 
              projects={dummyProjects.map(p => ({ ...p, tasks: [] }))} 
              onAddTask={handleAddTask} 
              disabled={isSubmitting || timesheet.status !== 'draft'} 
            />
            
            <TimesheetActions 
              isAdmin={false}
              isSubmitting={isSubmitting}
              isDraft={timesheet.status === 'draft'}
              hasTasks={calculateTotalHours() > 0}
              onSubmit={handleSubmitTimesheet}
            />
          </CardFooter>
        )}

        {isAdmin && (
          <CardFooter className="flex justify-end p-4">
            <TimesheetActions 
              isAdmin={true}
              isSubmitting={false}
              isDraft={false}
              hasTasks={true}
              onSubmit={() => {}} // Provide a no-op function for onSubmit
              onApprove={() => toast.success("Timesheet approved!")}
              onReject={() => toast.error("Timesheet rejected!")}
            />
          </CardFooter>
        )}
      </Card>

      <AbsenceDialog
        isOpen={isAbsenceDialogOpen}
        onOpenChange={setIsAbsenceDialogOpen}
        selectedDay={selectedDay}
        existingAbsence={getExistingAbsence(selectedDay)}
        onSubmit={handleAbsenceSubmit}
      />
    </div>
  );
};

export default Timesheet;
