
import React, { useState } from 'react';
import CalendarView from '@/components/CalendarView';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/context/AuthContext';
import { Badge } from '@/components/ui/badge';
import { CalendarCheck, CalendarDays } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const Calendar = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const isAdmin = user?.role === 'admin';
  
  return (
    <div className="container mx-auto space-y-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold">Calendar View</h1>
          <p className="text-muted-foreground">Visualize timesheets, holidays, and company events</p>
        </div>
        
        {isAdmin && (
          <Button 
            className="flex items-center gap-2"
            variant="outline"
            onClick={() => navigate('/company-holidays')}
          >
            <CalendarCheck className="h-4 w-4" />
            Manage Company Holidays
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CalendarDays className="h-5 w-5" />
                Calendar Overview
              </CardTitle>
              <CardDescription>
                View and manage your time entries, days off, and company holidays
              </CardDescription>
            </CardHeader>
            <CardContent>
              <CalendarView initialExpanded={true} />
            </CardContent>
          </Card>
        </div>
        
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Calendar Legend</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium mb-2">Timesheet Status</h3>
                  <div className="flex flex-col gap-2">
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-green-100 rounded"></div>
                      <span>Complete (8 hours)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-amber-100 rounded"></div>
                      <span>Partial (1-7 hours)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-red-100 rounded"></div>
                      <span>Missing (0 hours)</span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium mb-2">Days Off</h3>
                  <div className="flex flex-col gap-2">
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-blue-100 rounded"></div>
                      <span>Weekend</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-purple-100 rounded"></div>
                      <span>Company Holiday</span>
                    </div>
                  </div>
                </div>
                
                <div className="pt-4 border-t">
                  <h3 className="text-sm font-medium mb-2">Tips</h3>
                  <ul className="text-sm space-y-1 text-muted-foreground">
                    <li>• Click on any day to view details</li>
                    <li>• Weekends are automatically marked as off</li>
                    <li>• Company holidays are shown in purple</li>
                    {isAdmin && <li>• Admins can manage company holidays</li>}
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Calendar;
