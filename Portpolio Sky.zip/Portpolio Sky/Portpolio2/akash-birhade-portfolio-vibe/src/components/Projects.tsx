
import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ExternalLink, Github } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const Projects = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const projectsRef = useRef<HTMLDivElement>(null);

  const projects = [
    {
      title: "Movie Website in React",
      description: "A comprehensive movie database application built with React, featuring movie search, detailed movie information, user reviews, and favorites functionality. Integrated with external movie APIs for real-time data.",
      technologies: ["React", "Redux", "API Integration", "CSS3", "JavaScript"],
      image: "🎬",
      liveUrl: "#",
      githubUrl: "#",
      gradient: "from-red-500 to-pink-600"
    },
    {
      title: "eCommerce App with Redux",
      description: "Full-featured eCommerce platform with shopping cart, user authentication, payment integration, and admin dashboard. Built with React and Redux for state management.",
      technologies: ["React", "Redux", "Node.js", "MongoDB", "Stripe API"],
      image: "🛒",
      liveUrl: "#",
      githubUrl: "#",
      gradient: "from-green-500 to-teal-600"
    },
    {
      title: "GSAP/Three.js Animated App",
      description: "Interactive web application showcasing advanced animations using GSAP and Three.js. Features 3D graphics, smooth transitions, and engaging user interactions.",
      technologies: ["React", "Three.js", "GSAP", "WebGL", "TypeScript"],
      image: "🎨",
      liveUrl: "#",
      githubUrl: "#",
      gradient: "from-purple-500 to-indigo-600"
    },
    {
      title: "Form & Table Management App",
      description: "Dynamic form builder and data table management system with CRUD operations, data validation, sorting, and filtering capabilities. Perfect for business applications.",
      technologies: ["React", "TypeScript", "Material-UI", "Node.js", "PostgreSQL"],
      image: "📊",
      liveUrl: "#",
      githubUrl: "#",
      gradient: "from-blue-500 to-cyan-600"
    }
  ];

  useEffect(() => {
    const section = sectionRef.current;
    const projects = projectsRef.current;

    if (section && projects) {
      const projectCards = projects.querySelectorAll('.project-card');
      
      gsap.fromTo(projectCards,
        { y: 80, opacity: 0, scale: 0.9 },
        {
          y: 0,
          opacity: 1,
          scale: 1,
          duration: 0.8,
          stagger: 0.2,
          ease: "power3.out",
          scrollTrigger: {
            trigger: section,
            start: "top 80%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        }
      );
    }
  }, []);

  return (
    <section id="projects" ref={sectionRef} className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50 dark:bg-gray-800">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Featured Projects
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300">
            Some of my recent work that I'm proud of
          </p>
        </div>

        <div ref={projectsRef} className="grid md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <Card key={index} className="project-card group overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 bg-white dark:bg-gray-900 border-0">
              <div className={`h-2 bg-gradient-to-r ${project.gradient}`} />
              
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between mb-4">
                  <div className="text-4xl">{project.image}</div>
                  <div className="flex gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={() => window.open(project.githubUrl, '_blank')}
                    >
                      <Github className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="opacity-0 group-hover:opacity-100 transition-opacity"
                      onClick={() => window.open(project.liveUrl, '_blank')}
                    >
                      <ExternalLink className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                <CardTitle className="text-xl font-bold text-gray-800 dark:text-gray-200 group-hover:text-blue-600 transition-colors">
                  {project.title}
                </CardTitle>
              </CardHeader>

              <CardContent>
                <p className="text-gray-600 dark:text-gray-300 mb-6 leading-relaxed">
                  {project.description}
                </p>

                <div className="flex flex-wrap gap-2 mb-6">
                  {project.technologies.map((tech, techIndex) => (
                    <span
                      key={techIndex}
                      className="px-3 py-1 text-xs font-medium bg-gradient-to-r from-blue-100 to-purple-100 dark:from-blue-900 dark:to-purple-900 text-blue-800 dark:text-blue-200 rounded-full"
                    >
                      {tech}
                    </span>
                  ))}
                </div>

                <div className="flex gap-4">
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="flex-1 border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white"
                    onClick={() => window.open(project.liveUrl, '_blank')}
                  >
                    <ExternalLink className="mr-2 h-3 w-3" />
                    Live Demo
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="flex-1 border-gray-400 text-gray-600 hover:bg-gray-600 hover:text-white dark:border-gray-600 dark:text-gray-400"
                    onClick={() => window.open(project.githubUrl, '_blank')}
                  >
                    <Github className="mr-2 h-3 w-3" />
                    Source Code
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;
