
import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Card, CardContent } from '@/components/ui/card';

gsap.registerPlugin(ScrollTrigger);

const Skills = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const skillsRef = useRef<HTMLDivElement>(null);

  const skillCategories = [
    {
      title: "Frontend",
      skills: [
        { name: "React", level: 95 },
        { name: "TypeScript", level: 90 },
        { name: "JavaScript", level: 95 },
        { name: "HTML5/CSS3", level: 98 },
        { name: "Redux", level: 85 },
        { name: "Material-UI", level: 88 },
        { name: "Tailwind CSS", level: 92 },
        { name: "GSAP", level: 85 }
      ]
    },
    {
      title: "Backend & Database",
      skills: [
        { name: "Node.js", level: 85 },
        { name: "Express.js", level: 80 },
        { name: "MongoDB", level: 82 },
        { name: "Python", level: 78 },
        { name: "REST APIs", level: 85 },
        { name: "GraphQL", level: 70 }
      ]
    },
    {
      title: "Tools & Others",
      skills: [
        { name: "Git/GitHub", level: 90 },
        { name: "Webpack", level: 75 },
        { name: "Vite", level: 88 },
        { name: "Three.js", level: 75 },
        { name: "Jest", level: 70 },
        { name: "Docker", level: 65 }
      ]
    }
  ];

  useEffect(() => {
    const section = sectionRef.current;
    const skills = skillsRef.current;

    if (section && skills) {
      const skillCards = skills.querySelectorAll('.skill-card');
      
      gsap.fromTo(skillCards,
        { y: 50, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          stagger: 0.2,
          scrollTrigger: {
            trigger: section,
            start: "top 80%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        }
      );

      // Animate skill bars
      const skillBars = skills.querySelectorAll('.skill-bar');
      skillBars.forEach((bar) => {
        const level = bar.getAttribute('data-level');
        gsap.fromTo(bar,
          { width: '0%' },
          {
            width: `${level}%`,
            duration: 1.5,
            ease: "power3.out",
            scrollTrigger: {
              trigger: bar,
              start: "top 90%",
              toggleActions: "play none none reverse"
            }
          }
        );
      });
    }
  }, []);

  return (
    <section id="skills" ref={sectionRef} className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Skills & Technologies
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300">
            Technologies I work with and love
          </p>
        </div>

        <div ref={skillsRef} className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skillCategories.map((category, categoryIndex) => (
            <Card key={categoryIndex} className="skill-card p-6 shadow-xl hover:shadow-2xl transition-shadow duration-300 bg-white/50 dark:bg-gray-900/50 backdrop-blur-sm border-0">
              <CardContent className="p-0">
                <h3 className="text-2xl font-bold mb-6 text-gray-800 dark:text-gray-200 text-center">
                  {category.title}
                </h3>
                
                <div className="space-y-4">
                  {category.skills.map((skill, skillIndex) => (
                    <div key={skillIndex} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                          {skill.name}
                        </span>
                        <span className="text-sm text-gray-500 dark:text-gray-400">
                          {skill.level}%
                        </span>
                      </div>
                      
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                        <div 
                          className="skill-bar h-2 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full transition-all duration-300"
                          data-level={skill.level}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;
