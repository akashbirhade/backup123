"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import {
  MapPin,
  Home,
  DollarSign,
  Upload,
  Bed,
  Bath,
  Users,
  Wifi,
  Tv,
  Car,
  Utensils,
  Check,
  X,
  Loader2,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"
import { format } from "date-fns"
import { toast } from "@/hooks/use-toast"

export default function HostPropertyPage() {
  const router = useRouter()
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [propertyType, setPropertyType] = useState("")
  const [price, setPrice] = useState("")
  const [location, setLocation] = useState("")
  const [bedrooms, setBedrooms] = useState("")
  const [bathrooms, setBathrooms] = useState("")
  const [guests, setGuests] = useState("")
  const [amenities, setAmenities] = useState<string[]>([])
  const [images, setImages] = useState<File[]>([])
  const [imageUrls, setImageUrls] = useState<string[]>([])
  const [availableDates, setAvailableDates] = useState<Date[]>([])
  const [loading, setLoading] = useState(false)
  const [currentTab, setCurrentTab] = useState("details")

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files)
      setImages([...images, ...newFiles])

      // Create preview URLs
      const newUrls = newFiles.map((file) => URL.createObjectURL(file))
      setImageUrls([...imageUrls, ...newUrls])
    }
  }

  const removeImage = (index: number) => {
    const newImages = [...images]
    const newUrls = [...imageUrls]

    // Revoke the object URL to avoid memory leaks
    URL.revokeObjectURL(newUrls[index])

    newImages.splice(index, 1)
    newUrls.splice(index, 1)

    setImages(newImages)
    setImageUrls(newUrls)
  }

  const toggleAmenity = (amenity: string) => {
    if (amenities.includes(amenity)) {
      setAmenities(amenities.filter((a) => a !== amenity))
    } else {
      setAmenities([...amenities, amenity])
    }
  }

  const handleDateSelect = (dates: Date[] | undefined) => {
    if (!dates) {
      setAvailableDates([])
      return
    }

    // Update with the new selection
    setAvailableDates(dates)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!title || !description || !propertyType || !price || !location || !bedrooms || !bathrooms || !guests) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    if (images.length === 0) {
      toast({
        title: "No images",
        description: "Please upload at least one image of your property",
        variant: "destructive",
      })
      return
    }

    if (availableDates.length === 0) {
      toast({
        title: "No available dates",
        description: "Please select at least one available date",
        variant: "destructive",
      })
      return
    }

    setLoading(true)

    // Simulate API call
    setTimeout(() => {
      toast({
        title: "Property listed successfully!",
        description: "Your property has been added to our listings",
      })
      setLoading(false)
      router.push("/properties")
    }, 2000)
  }

  const nextTab = () => {
    if (currentTab === "details") {
      if (!title || !description || !propertyType || !price || !location || !bedrooms || !bathrooms || !guests) {
        toast({
          title: "Missing information",
          description: "Please fill in all required fields",
          variant: "destructive",
        })
        return
      }
      setCurrentTab("photos")
    } else if (currentTab === "photos") {
      if (images.length === 0) {
        toast({
          title: "No images",
          description: "Please upload at least one image of your property",
          variant: "destructive",
        })
        return
      }
      setCurrentTab("amenities")
    } else if (currentTab === "amenities") {
      setCurrentTab("availability")
    }
  }

  const prevTab = () => {
    if (currentTab === "photos") {
      setCurrentTab("details")
    } else if (currentTab === "amenities") {
      setCurrentTab("photos")
    } else if (currentTab === "availability") {
      setCurrentTab("amenities")
    }
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-2">Host Your Property</h1>
      <p className="text-gray-600 mb-8">List your property on WanderWise and start earning</p>

      <Card className="max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle>Property Information</CardTitle>
          <CardDescription>Fill in the details about your property to create a listing</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={currentTab} onValueChange={setCurrentTab}>
            <TabsList className="grid w-full grid-cols-4 mb-8">
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="photos">Photos</TabsTrigger>
              <TabsTrigger value="amenities">Amenities</TabsTrigger>
              <TabsTrigger value="availability">Availability</TabsTrigger>
            </TabsList>

            <TabsContent value="details" className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="title">Property Title</Label>
                <div className="relative">
                  <Home className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <Input
                    id="title"
                    placeholder="e.g., Cozy Apartment in Downtown"
                    className="pl-10"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Describe your property, highlight special features, nearby attractions, etc."
                  className="min-h-[120px]"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="property-type">Property Type</Label>
                  <Select value={propertyType} onValueChange={setPropertyType}>
                    <SelectTrigger id="property-type">
                      <SelectValue placeholder="Select property type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="apartment">Apartment</SelectItem>
                      <SelectItem value="house">House</SelectItem>
                      <SelectItem value="villa">Villa</SelectItem>
                      <SelectItem value="hotel">Hotel Room</SelectItem>
                      <SelectItem value="cabin">Cabin</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="price">Price per Night</Label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <Input
                      id="price"
                      type="number"
                      placeholder="e.g., 100"
                      className="pl-10"
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="location">Location</Label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <Input
                    id="location"
                    placeholder="e.g., 123 Main St, New York, NY"
                    className="pl-10"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="bedrooms">Bedrooms</Label>
                  <div className="relative">
                    <Bed className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <Select value={bedrooms} onValueChange={setBedrooms}>
                      <SelectTrigger id="bedrooms" className="pl-10">
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                      <SelectContent>
                        {[1, 2, 3, 4, 5, 6].map((num) => (
                          <SelectItem key={num} value={num.toString()}>
                            {num}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bathrooms">Bathrooms</Label>
                  <div className="relative">
                    <Bath className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <Select value={bathrooms} onValueChange={setBathrooms}>
                      <SelectTrigger id="bathrooms" className="pl-10">
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                      <SelectContent>
                        {[1, 1.5, 2, 2.5, 3, 3.5, 4].map((num) => (
                          <SelectItem key={num} value={num.toString()}>
                            {num}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="guests">Max Guests</Label>
                  <div className="relative">
                    <Users className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                    <Select value={guests} onValueChange={setGuests}>
                      <SelectTrigger id="guests" className="pl-10">
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                      <SelectContent>
                        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => (
                          <SelectItem key={num} value={num.toString()}>
                            {num}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="photos" className="space-y-6">
              <div className="space-y-2">
                <Label>Property Photos</Label>
                <div className="border-2 border-dashed rounded-lg p-6 text-center">
                  <Upload className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                  <p className="text-sm text-gray-600 mb-2">Drag and drop your photos here, or click to browse</p>
                  <p className="text-xs text-gray-500 mb-4">Upload high-quality images (max 10 photos)</p>
                  <Input
                    type="file"
                    accept="image/*"
                    multiple
                    className="hidden"
                    id="photo-upload"
                    onChange={handleImageUpload}
                  />
                  <Button asChild variant="outline">
                    <Label htmlFor="photo-upload" className="cursor-pointer">
                      Upload Photos
                    </Label>
                  </Button>
                </div>
              </div>

              {imageUrls.length > 0 && (
                <div className="space-y-2">
                  <Label>Uploaded Photos</Label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {imageUrls.map((url, index) => (
                      <div key={index} className="relative group">
                        <img
                          src={url || "/placeholder.svg"}
                          alt={`Property photo ${index + 1}`}
                          className="w-full h-32 object-cover rounded-md"
                        />
                        <button
                          type="button"
                          onClick={() => removeImage(index)}
                          className="absolute top-2 right-2 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </TabsContent>

            <TabsContent value="amenities" className="space-y-6">
              <div className="space-y-2">
                <Label>Available Amenities</Label>
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { id: "wifi", label: "WiFi", icon: <Wifi className="h-4 w-4" /> },
                    { id: "tv", label: "TV", icon: <Tv className="h-4 w-4" /> },
                    { id: "kitchen", label: "Kitchen", icon: <Utensils className="h-4 w-4" /> },
                    { id: "parking", label: "Parking", icon: <Car className="h-4 w-4" /> },
                    { id: "ac", label: "Air Conditioning", icon: null },
                    { id: "heating", label: "Heating", icon: null },
                    { id: "washer", label: "Washer", icon: null },
                    { id: "dryer", label: "Dryer", icon: null },
                    { id: "pool", label: "Pool", icon: null },
                    { id: "gym", label: "Gym", icon: null },
                  ].map((amenity) => (
                    <div key={amenity.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={`amenity-${amenity.id}`}
                        checked={amenities.includes(amenity.id)}
                        onCheckedChange={() => toggleAmenity(amenity.id)}
                      />
                      <Label htmlFor={`amenity-${amenity.id}`} className="flex items-center cursor-pointer">
                        {amenity.icon && <span className="mr-2">{amenity.icon}</span>}
                        {amenity.label}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="availability" className="space-y-6">
              <div className="space-y-2">
                <Label>Available Dates</Label>
                <p className="text-sm text-gray-600 mb-4">
                  Select the dates when your property is available for booking
                </p>
                <div className="border rounded-md p-4">
                  <CalendarComponent
                    mode="multiple"
                    selected={availableDates}
                    onSelect={handleDateSelect}
                    className="mx-auto"
                    disabled={(date) => date < new Date()}
                  />
                </div>

                {availableDates.length > 0 && (
                  <div className="mt-4">
                    <h4 className="font-medium mb-2">Selected Dates ({availableDates.length})</h4>
                    <div className="flex flex-wrap gap-2">
                      {availableDates.slice(0, 5).map((date, index) => (
                        <div key={index} className="bg-teal-100 text-teal-800 text-sm px-2 py-1 rounded-md">
                          {format(date, "MMM d, yyyy")}
                        </div>
                      ))}
                      {availableDates.length > 5 && (
                        <div className="bg-gray-100 text-gray-800 text-sm px-2 py-1 rounded-md">
                          +{availableDates.length - 5} more
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
        <CardFooter className="flex justify-between">
          {currentTab !== "details" ? (
            <Button variant="outline" onClick={prevTab}>
              Back
            </Button>
          ) : (
            <div></div>
          )}

          {currentTab !== "availability" ? (
            <Button onClick={nextTab}>Continue</Button>
          ) : (
            <Button onClick={handleSubmit} disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Submitting...
                </>
              ) : (
                <>
                  <Check className="mr-2 h-4 w-4" />
                  List Property
                </>
              )}
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  )
}
