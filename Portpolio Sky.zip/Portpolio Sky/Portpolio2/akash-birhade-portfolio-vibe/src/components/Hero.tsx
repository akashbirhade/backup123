
import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { Button } from '@/components/ui/button';
import { ArrowDown, Github, Linkedin, Twitter, Mail, Instagram, Phone } from 'lucide-react';

const Hero = () => {
  const heroRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const buttonsRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!titleRef.current || !subtitleRef.current || !buttonsRef.current || !imageRef.current) return;

    const tl = gsap.timeline();
    
    tl.fromTo(titleRef.current, 
      { x: -100, opacity: 0 },
      { x: 0, opacity: 1, duration: 1, ease: "power3.out" }
    )
    .fromTo(subtitleRef.current,
      { x: -80, opacity: 0 },
      { x: 0, opacity: 1, duration: 0.8, ease: "power3.out" },
      "-=0.5"
    )
    .fromTo(buttonsRef.current,
      { x: -60, opacity: 0 },
      { x: 0, opacity: 1, duration: 0.6, ease: "power3.out" },
      "-=0.3"
    )
    .fromTo(imageRef.current,
      { x: 100, opacity: 0 },
      { x: 0, opacity: 1, duration: 1, ease: "power3.out" },
      "-=0.8"
    );
  }, []);

  const scrollToAbout = () => {
    const aboutSection = document.querySelector('#about');
    if (aboutSection) {
      aboutSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gray-50 dark:bg-gray-900">
      {/* Geometric Network Background */}
      <div className="absolute inset-0 overflow-hidden">
        <svg className="absolute inset-0 w-full h-full" viewBox="0 0 1200 800" preserveAspectRatio="xMidYMid slice">
          <defs>
            <pattern id="grid" width="60" height="60" patternUnits="userSpaceOnUse">
              <path d="M 60 0 L 0 0 0 60" fill="none" stroke="currentColor" strokeWidth="1" className="text-gray-300 dark:text-gray-700" opacity="0.3"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
          
          {/* Network nodes and connections */}
          <g className="text-gray-400 dark:text-gray-600" opacity="0.6">
            <circle cx="100" cy="150" r="3" fill="currentColor" />
            <circle cx="200" cy="100" r="3" fill="currentColor" />
            <circle cx="300" cy="200" r="3" fill="currentColor" />
            <circle cx="450" cy="120" r="3" fill="currentColor" />
            <circle cx="600" cy="180" r="3" fill="currentColor" />
            <circle cx="750" cy="100" r="3" fill="currentColor" />
            <circle cx="900" cy="160" r="3" fill="currentColor" />
            <circle cx="1000" cy="120" r="3" fill="currentColor" />
            
            <line x1="100" y1="150" x2="200" y2="100" stroke="currentColor" strokeWidth="1" />
            <line x1="200" y1="100" x2="300" y2="200" stroke="currentColor" strokeWidth="1" />
            <line x1="300" y1="200" x2="450" y2="120" stroke="currentColor" strokeWidth="1" />
            <line x1="450" y1="120" x2="600" y2="180" stroke="currentColor" strokeWidth="1" />
            <line x1="600" y1="180" x2="750" y2="100" stroke="currentColor" strokeWidth="1" />
            <line x1="750" y1="100" x2="900" y2="160" stroke="currentColor" strokeWidth="1" />
            <line x1="900" y1="160" x2="1000" y2="120" stroke="currentColor" strokeWidth="1" />
            
            <circle cx="150" cy="400" r="3" fill="currentColor" />
            <circle cx="280" cy="450" r="3" fill="currentColor" />
            <circle cx="420" cy="380" r="3" fill="currentColor" />
            <circle cx="580" cy="420" r="3" fill="currentColor" />
            <circle cx="720" cy="400" r="3" fill="currentColor" />
            <circle cx="850" cy="450" r="3" fill="currentColor" />
            
            <line x1="150" y1="400" x2="280" y2="450" stroke="currentColor" strokeWidth="1" />
            <line x1="280" y1="450" x2="420" y2="380" stroke="currentColor" strokeWidth="1" />
            <line x1="420" y1="380" x2="580" y2="420" stroke="currentColor" strokeWidth="1" />
            <line x1="580" y1="420" x2="720" y2="400" stroke="currentColor" strokeWidth="1" />
            <line x1="720" y1="400" x2="850" y2="450" stroke="currentColor" strokeWidth="1" />
          </g>
        </svg>
      </div>
      
      <div className="relative z-10 container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center min-h-screen py-20">
          {/* Left Content */}
          <div className="space-y-8">
            <div>
              <h1 ref={titleRef} className="text-5xl md:text-6xl lg:text-7xl font-bold mb-4">
                Hi There,
              </h1>
              <h2 className="text-5xl md:text-6xl lg:text-7xl font-bold mb-6">
                I'm <span className="text-orange-500">Akash</span>
              </h2>
              <p ref={subtitleRef} className="text-2xl md:text-3xl text-gray-700 dark:text-gray-300 mb-8">
                I Am Into <span className="text-purple-600 font-semibold">Web Development</span>
              </p>
            </div>
            
            <div ref={buttonsRef} className="flex flex-col sm:flex-row gap-4 mb-8">
              <Button 
                size="lg" 
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-full text-lg font-semibold"
                onClick={scrollToAbout}
              >
                About Me
                <ArrowDown className="ml-2 h-5 w-5" />
              </Button>
            </div>
            
            {/* Social Links */}
            <div className="flex space-x-4">
              <a href="https://linkedin.com/in/akash-birhade" target="_blank" rel="noopener noreferrer" 
                 className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white hover:bg-blue-700 transition-colors">
                <Linkedin className="h-6 w-6" />
              </a>
              <a href="https://github.com/akash-birhade" target="_blank" rel="noopener noreferrer"
                 className="w-12 h-12 bg-gray-800 rounded-full flex items-center justify-center text-white hover:bg-gray-900 transition-colors">
                <Github className="h-6 w-6" />
              </a>
              <a href="https://twitter.com/akash-birhade" target="_blank" rel="noopener noreferrer"
                 className="w-12 h-12 bg-blue-400 rounded-full flex items-center justify-center text-white hover:bg-blue-500 transition-colors">
                <Twitter className="h-6 w-6" />
              </a>
              <a href="mailto:akash.birhade@email.com"
                 className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center text-white hover:bg-red-600 transition-colors">
                <Mail className="h-6 w-6" />
              </a>
              <a href="https://instagram.com/akash-birhade" target="_blank" rel="noopener noreferrer"
                 className="w-12 h-12 bg-pink-500 rounded-full flex items-center justify-center text-white hover:bg-pink-600 transition-colors">
                <Instagram className="h-6 w-6" />
              </a>
              <a href="tel:+1234567890"
                 className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center text-white hover:bg-green-600 transition-colors">
                <Phone className="h-6 w-6" />
              </a>
            </div>
          </div>
          
          {/* Right Content - Character Illustration */}
          <div ref={imageRef} className="flex justify-center lg:justify-end">
            <div className="relative">
              {/* Yellow circle background */}
              <div className="w-80 h-80 md:w-96 md:h-96 bg-yellow-400 rounded-full flex items-center justify-center relative overflow-hidden">
                {/* Character placeholder - using the uploaded image */}
                <img 
                  src="/lovable-uploads/e317ca4a-761b-406b-ba48-4819dafe9c22.png" 
                  alt="Akash Birhade"
                  className="w-full h-full object-cover rounded-full"
                />
              </div>
              
              {/* Floating elements around the circle */}
              <div className="absolute -top-4 -left-4 w-8 h-8 bg-blue-500 rounded-full animate-bounce"></div>
              <div className="absolute -top-2 -right-6 w-6 h-6 bg-purple-500 rounded-full animate-bounce delay-300"></div>
              <div className="absolute -bottom-4 -left-6 w-10 h-10 bg-green-500 rounded-full animate-bounce delay-500"></div>
              <div className="absolute -bottom-2 -right-4 w-7 h-7 bg-red-500 rounded-full animate-bounce delay-700"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
