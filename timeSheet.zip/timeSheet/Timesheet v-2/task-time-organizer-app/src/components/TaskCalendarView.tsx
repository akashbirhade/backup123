import React, { useState } from 'react';
import { Calendar } from '@/components/ui/calendar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { format, isSameDay, startOfWeek, endOfWeek, addDays } from 'date-fns';
import { cn } from '@/lib/utils';

interface TaskCalendarEntry {
  date: Date;
  status: 'checkin_checkout_mismatch' | 'stretch_hours' | 'mismatch_and_stretch' | 'no_checkin_ts_filled' | 'working_hours_greater_checkin_checkout' | 'normal';
  tasks: { project: string; description: string; hours: number }[];
}

const getDummyTaskEntries = (): TaskCalendarEntry[] => {
  const today = new Date();
  const entries: TaskCalendarEntry[] = [];

  // Generate entries for the past 30 days for demonstration
  for (let i = 0; i < 30; i++) {
    const date = new Date();
    date.setDate(today.getDate() - i);

    const random = Math.random();
    let status: TaskCalendarEntry['status'] = 'normal';
    let tasks: { project: string; description: string; hours: number }[] = [];

    if (random < 0.2) {
      status = 'checkin_checkout_mismatch';
      tasks = [{ project: 'Project A', description: 'Checkin/Checkout mismatch', hours: 0 }];
    } else if (random < 0.4) {
      status = 'stretch_hours';
      tasks = [{ project: 'Project B', description: 'Stretch Hours (Hours > 9)', hours: 10 }];
    } else if (random < 0.6) {
      status = 'mismatch_and_stretch';
      tasks = [{ project: 'Project C', description: 'Checkin/Checkout mismatch and stretch hours', hours: 11 }];
    } else if (random < 0.8) {
      status = 'no_checkin_ts_filled';
      tasks = [{ project: 'Project D', description: 'No checkin/checkout but TS filled', hours: 8 }];
    } else if (random < 0.9) {
      status = 'working_hours_greater_checkin_checkout';
      tasks = [{ project: 'Project E', description: 'Working hours > Checkin/Checkout', hours: 7 }];
    } else {
      status = 'normal';
      tasks = [{ project: 'Project F', description: 'Normal working day', hours: 8 }];
    }

    entries.push({
      date,
      status,
      tasks,
    });
  }
  return entries;
};

const TaskCalendarView: React.FC = () => {
  const [selectedMonth, setSelectedMonth] = useState<Date>(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const taskCalendarEntries = getDummyTaskEntries();

  const getEntryForDate = (date: Date) => {
    return taskCalendarEntries.find(entry => isSameDay(entry.date, date));
  };

  const getDayIndicator = (date: Date) => {
    const entry = getEntryForDate(date);
    if (!entry || entry.status === 'normal') return null;

    let indicatorColorClass = '';
    switch (entry.status) {
      case 'checkin_checkout_mismatch':
        indicatorColorClass = 'text-purple-500'; // Example color
        break;
      case 'stretch_hours':
        indicatorColorClass = 'text-blue-500'; // Example color
        break;
      case 'mismatch_and_stretch':
        indicatorColorClass = 'text-red-500'; // Example color
        break;
      case 'no_checkin_ts_filled':
        indicatorColorClass = 'text-teal-500'; // Example color
        break;
      case 'working_hours_greater_checkin_checkout':
        indicatorColorClass = 'text-green-500'; // Example color
        break;
    }

    return (
      <span className={cn("absolute top-1 right-1 text-xs", indicatorColorClass)}>
        ★
      </span>
    );
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Task Entry Calendar</CardTitle>
      </CardHeader>
      <CardContent>
        <Calendar
          mode="single"
          month={selectedMonth}
          onMonthChange={setSelectedMonth}
          className="rounded-md border"
          components={{
            Day: ({ date, ...props }) => {
              const dayEntry = getEntryForDate(date);
              return (
                <div
                  className={cn("relative cursor-pointer", {
                    "bg-blue-100 rounded-md": selectedDate && isSameDay(date, selectedDate),
                  })}
                  onClick={() => {
                    setSelectedDate(date);
                    setIsDialogOpen(true);
                  }}
                >
                  <span {...props} className="block text-center">
                    {format(date, 'd')}
                  </span>
                  {getDayIndicator(date)}
                </div>
              );
            },
          }}
        />
        <div className="mt-4 space-y-2">
          <p className="flex items-center"><span className="text-purple-500 mr-2">★</span> Checkin/Checkout location mismatch</p>
          <p className="flex items-center"><span className="text-blue-500 mr-2">★</span> Stretch Hours (Hours {'>'} 9)</p>
          <p className="flex items-center"><span className="text-red-500 mr-2">★</span> Checkin/Checkout location mismatch and stretch hours</p>
          <p className="flex items-center"><span className="text-teal-500 mr-2">★</span> No checkin/checkout but TS filled</p>
          <p className="flex items-center"><span className="text-green-500 mr-2">★</span> Working hours {'>'} Checkin/Checkout</p>
        </div>
      </CardContent>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{selectedDate ? format(selectedDate, 'PPP') : 'Select a Date'}</DialogTitle>
            <DialogDescription>
              {selectedDate && getEntryForDate(selectedDate) ? (
                <div className="space-y-2">
                  <p>Status: {getEntryForDate(selectedDate)?.status.replace(/_/g, ' ')}</p>
                  <h4 className="font-semibold mt-2">Tasks:</h4>
                  {getEntryForDate(selectedDate)?.tasks.length > 0 ? (
                    <ul>
                      {getEntryForDate(selectedDate)?.tasks.map((task, index) => (
                        <li key={index}>- {task.project}: {task.description} ({task.hours} hours)</li>
                      ))}
                    </ul>
                  ) : (
                    <p>No tasks for this day.</p>
                  )}
                </div>
              ) : (
                <p>No entry for this date.</p>
              )}
            </DialogDescription>
          </DialogHeader>
        </DialogContent>
      </Dialog>
    </Card>
  );
};

export default TaskCalendarView;