import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import FeaturedProperties from "@/components/featured-properties"
import HeroSection from "@/components/hero-section"

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <HeroSection />

      <div className="container mx-auto px-4 py-12">
        <h2 className="text-3xl font-bold text-center mb-8">Discover Your Perfect Stay</h2>

        <Tabs defaultValue="budget" className="w-full max-w-4xl mx-auto">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="budget">Budget</TabsTrigger>
            <TabsTrigger value="mid-range">Mid-Range</TabsTrigger>
            <TabsTrigger value="luxury">Luxury</TabsTrigger>
          </TabsList>

          <TabsContent value="budget">
            <FeaturedProperties category="budget" />
          </TabsContent>

          <TabsContent value="mid-range">
            <FeaturedProperties category="mid-range" />
          </TabsContent>

          <TabsContent value="luxury">
            <FeaturedProperties category="luxury" />
          </TabsContent>
        </Tabs>

        <div className="mt-16 text-center">
          <h2 className="text-3xl font-bold mb-6">Plan Your Dream Trip with AI</h2>
          <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
            Let our AI assistant help you create the perfect itinerary based on your preferences, budget, and travel
            dates.
          </p>
          <Button
            asChild
            size="lg"
            className="bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600"
          >
            <Link href="/trip-planner">Create AI Trip Plan</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
