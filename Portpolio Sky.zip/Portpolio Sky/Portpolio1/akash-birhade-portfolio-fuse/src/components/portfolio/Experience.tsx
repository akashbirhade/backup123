
import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Calendar, MapPin } from 'lucide-react';

interface ExperienceProps {
  isDark: boolean;
}

const Experience: React.FC<ExperienceProps> = ({ isDark }) => {
  const sectionRef = useRef<HTMLElement>(null);
  const timelineRef = useRef<HTMLDivElement[]>([]);

  const experiences = [
    {
      company: 'Periscope',
      position: 'Senior Frontend Developer',
      duration: '2023 - Present',
      location: 'Remote',
      description: 'Leading frontend development initiatives, implementing modern React applications with TypeScript, and mentoring junior developers.',
      achievements: [
        'Improved application performance by 40%',
        'Led migration to TypeScript',
        'Implemented design system components'
      ],
      color: 'blue'
    },
    {
      company: 'Viser',
      position: 'Frontend Developer',
      duration: '2022 - 2023',
      location: 'Hybrid',
      description: 'Developed responsive web applications using React and modern frontend technologies, collaborated with design and backend teams.',
      achievements: [
        'Built 15+ production-ready components',
        'Reduced bundle size by 30%',
        'Implemented CI/CD pipelines'
      ],
      color: 'purple'
    },
    {
      company: 'Naresh IT',
      position: 'Junior Frontend Developer',
      duration: '2021 - 2022',
      location: 'On-site',
      description: 'Started my journey in web development, learning React fundamentals and contributing to various client projects.',
      achievements: [
        'Completed 10+ client projects',
        'Learned React and JavaScript fundamentals',
        'Collaborated with cross-functional teams'
      ],
      color: 'teal'
    }
  ];

  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);

    timelineRef.current.forEach((item, index) => {
      if (item) {
        gsap.fromTo(item,
          { opacity: 0, x: index % 2 === 0 ? -100 : 100 },
          {
            opacity: 1,
            x: 0,
            duration: 0.8,
            ease: "power3.out",
            scrollTrigger: {
              trigger: item,
              start: 'top 80%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      }
    });
  }, []);

  const getColorClasses = (color: string) => {
    const colors = {
      blue: {
        bg: 'from-blue-500 to-cyan-500',
        text: 'text-blue-600 dark:text-blue-400',
        border: 'border-blue-500'
      },
      purple: {
        bg: 'from-purple-500 to-pink-500',
        text: 'text-purple-600 dark:text-purple-400',
        border: 'border-purple-500'
      },
      teal: {
        bg: 'from-teal-500 to-green-500',
        text: 'text-teal-600 dark:text-teal-400',
        border: 'border-teal-500'
      }
    };
    return colors[color as keyof typeof colors];
  };

  return (
    <section 
      id="experience" 
      ref={sectionRef}
      className="py-20 px-4 max-w-7xl mx-auto"
    >
      <div className="text-center mb-16">
        <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4">
          Experience
        </h2>
        <div className="w-20 h-1 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full mx-auto mb-6" />
        <p className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
          My professional journey in frontend development and full-stack technologies
        </p>
      </div>

      <div className="relative">
        {/* Timeline Line */}
        <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gradient-to-b from-blue-500 to-purple-500 rounded-full" />

        {experiences.map((exp, index) => {
          const colorClasses = getColorClasses(exp.color);
          const isEven = index % 2 === 0;

          return (
            <div
              key={exp.company}
              ref={el => { if (el) timelineRef.current[index] = el; }}
              className={`relative flex items-center mb-12 ${isEven ? 'flex-row' : 'flex-row-reverse'}`}
            >
              {/* Content Card */}
              <div className={`w-full md:w-5/12 ${isEven ? 'pr-8' : 'pl-8'}`}>
                <div className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-sm rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-200/50 dark:border-gray-700/50">
                  {/* Company Header */}
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                        {exp.position}
                      </h3>
                      <h4 className={`text-lg font-semibold ${colorClasses.text}`}>
                        {exp.company}
                      </h4>
                    </div>
                    <div className={`w-3 h-3 rounded-full bg-gradient-to-r ${colorClasses.bg}`} />
                  </div>

                  {/* Duration and Location */}
                  <div className="flex flex-wrap gap-4 mb-4 text-sm text-gray-600 dark:text-gray-400">
                    <div className="flex items-center gap-1">
                      <Calendar size={14} />
                      {exp.duration}
                    </div>
                    <div className="flex items-center gap-1">
                      <MapPin size={14} />
                      {exp.location}
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-gray-700 dark:text-gray-300 mb-4">
                    {exp.description}
                  </p>

                  {/* Achievements */}
                  <div>
                    <h5 className="font-semibold text-gray-900 dark:text-white mb-2">
                      Key Achievements:
                    </h5>
                    <ul className="space-y-1">
                      {exp.achievements.map((achievement, i) => (
                        <li key={i} className="text-sm text-gray-600 dark:text-gray-400 flex items-start">
                          <span className={`w-2 h-2 rounded-full bg-gradient-to-r ${colorClasses.bg} mt-2 mr-3 flex-shrink-0`} />
                          {achievement}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              {/* Timeline Dot */}
              <div className="absolute left-1/2 transform -translate-x-1/2 w-6 h-6 rounded-full bg-white dark:bg-gray-800 border-4 border-current flex items-center justify-center z-10">
                <div className={`w-2 h-2 rounded-full bg-gradient-to-r ${colorClasses.bg}`} />
              </div>

              {/* Spacer for mobile */}
              <div className="w-full md:w-5/12" />
            </div>
          );
        })}
      </div>
    </section>
  );
};

export default Experience;
