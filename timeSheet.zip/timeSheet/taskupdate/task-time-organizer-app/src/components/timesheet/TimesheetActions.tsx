
import React from 'react';
import { Button } from '@/components/ui/button';
import { Save } from 'lucide-react';

interface TimesheetActionsProps {
  isAdmin: boolean;
  isSubmitting: boolean;
  isDraft: boolean;
  hasTasks: boolean;
  onSubmit: () => void;
  onApprove?: () => void;
  onReject?: () => void;
}

const TimesheetActions: React.FC<TimesheetActionsProps> = ({
  isAdmin,
  isSubmitting,
  isDraft,
  hasTasks,
  onSubmit,
  onApprove,
  onReject
}) => {
  return (
    <>
      {!isAdmin && isDraft && (
        <Button 
          variant="default" 
          onClick={onSubmit}
          disabled={isSubmitting || !hasTasks}
        >
          {isSubmitting ? (
            <>
              <span className="animate-spin mr-2">⏳</span> Submitting...
            </>
          ) : (
            <>
              <Save className="h-4 w-4 mr-1" /> Submit Timesheet
            </>
          )}
        </Button>
      )}

      {isAdmin && (
        <div className="flex gap-2">
          <Button variant="outline" onClick={onReject}>
            Reject
          </Button>
          <Button onClick={onApprove}>
            Approve
          </Button>
        </div>
      )}
    </>
  );
};

export default TimesheetActions;
