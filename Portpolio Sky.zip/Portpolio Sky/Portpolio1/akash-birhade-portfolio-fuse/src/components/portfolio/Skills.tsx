
import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

interface SkillsProps {
  isDark: boolean;
}

const Skills: React.FC<SkillsProps> = ({ isDark }) => {
  const sectionRef = useRef<HTMLElement>(null);
  const skillsRef = useRef<HTMLDivElement[]>([]);

  const skills = [
    { name: 'React', level: 95, color: 'from-blue-500 to-cyan-500' },
    { name: 'TypeScript', level: 90, color: 'from-blue-600 to-indigo-600' },
    { name: 'Node.js', level: 85, color: 'from-green-500 to-emerald-500' },
    { name: 'Redux', level: 88, color: 'from-purple-500 to-pink-500' },
    { name: 'MongoDB', level: 82, color: 'from-green-600 to-teal-600' },
    { name: 'Material UI', level: 92, color: 'from-blue-400 to-blue-600' },
    { name: 'Python', level: 80, color: 'from-yellow-500 to-orange-500' },
    { name: 'GSAP', level: 85, color: 'from-green-400 to-blue-500' },
    { name: 'Three.js', level: 75, color: 'from-purple-600 to-blue-600' },
    { name: 'Git', level: 90, color: 'from-orange-500 to-red-500' }
  ];

  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);

    const tl = gsap.timeline({
      scrollTrigger: {
        trigger: sectionRef.current,
        start: 'top 80%',
        end: 'bottom 20%',
        toggleActions: 'play none none reverse'
      }
    });

    // Animate skill bars
    skillsRef.current.forEach((skill, index) => {
      if (skill) {
        const progressBar = skill.querySelector('.progress-bar');
        const percentage = skill.querySelector('.percentage');
        
        tl.fromTo(skill,
          { opacity: 0, y: 50 },
          { opacity: 1, y: 0, duration: 0.6, ease: "power3.out" },
          index * 0.1
        )
        .fromTo(progressBar,
          { scaleX: 0 },
          { scaleX: 1, duration: 1, ease: "power3.out" },
          `-=${0.3}`
        )
        .fromTo(percentage,
          { opacity: 0 },
          { opacity: 1, duration: 0.3 },
          `-=${0.5}`
        );
      }
    });
  }, []);

  return (
    <section 
      id="skills" 
      ref={sectionRef}
      className="py-20 px-4 max-w-7xl mx-auto"
    >
      <div className="text-center mb-16">
        <h2 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4">
          Skills & Expertise
        </h2>
        <div className="w-20 h-1 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full mx-auto mb-6" />
        <p className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
          Passionate about modern web technologies and continuously learning to stay ahead of the curve
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {skills.map((skill, index) => (
          <div
            key={skill.name}
            ref={el => { if (el) skillsRef.current[index] = el; }}
            className="bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-200/50 dark:border-gray-700/50"
          >
            <div className="flex justify-between items-center mb-3">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                {skill.name}
              </h3>
              <span className="percentage text-sm font-bold text-gray-600 dark:text-gray-400">
                {skill.level}%
              </span>
            </div>
            
            <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3 overflow-hidden">
              <div 
                className={`progress-bar h-full bg-gradient-to-r ${skill.color} rounded-full origin-left transform transition-transform duration-1000`}
                style={{ width: `${skill.level}%` }}
              />
            </div>
          </div>
        ))}
      </div>

      {/* Technologies Cloud */}
      <div className="mt-16 text-center">
        <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-8">
          Technologies I Work With
        </h3>
        <div className="flex flex-wrap justify-center gap-4">
          {['HTML5', 'CSS3', 'JavaScript', 'React', 'Vue.js', 'Angular', 'Node.js', 'Express', 'MongoDB', 'PostgreSQL', 'AWS', 'Docker', 'Git', 'Figma', 'Webpack', 'Vite'].map((tech) => (
            <span
              key={tech}
              className="px-4 py-2 bg-gradient-to-r from-blue-100 to-purple-100 dark:from-blue-900/30 dark:to-purple-900/30 text-gray-800 dark:text-gray-200 rounded-full text-sm font-medium hover:scale-105 transition-transform duration-200 cursor-default"
            >
              {tech}
            </span>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;
