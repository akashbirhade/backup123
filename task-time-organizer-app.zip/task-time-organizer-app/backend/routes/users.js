
const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const { auth, checkRole } = require('../middleware/auth');

// Apply auth middleware to all routes
router.use(auth);

// Get all users (admin only)
router.get('/', checkRole('admin'), async (req, res) => {
  try {
    const result = await req.db.query(
      'SELECT id, first_name, last_name, email, role, created_at FROM users ORDER BY last_name, first_name'
    );
    
    res.status(200).json({
      success: true,
      data: result.rows.map(user => ({
        id: user.id,
        firstName: user.first_name,
        lastName: user.last_name,
        email: user.email,
        role: user.role,
        createdAt: user.created_at
      }))
    });
  } catch (error) {
    console.error('Error fetching users:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

// Get a single user
router.get('/:id', async (req, res) => {
  try {
    // Regular users can only get their own data
    if (req.user.role !== 'admin' && req.user.id !== parseInt(req.params.id)) {
      return res.status(403).json({
        success: false,
        error: 'Access denied'
      });
    }
    
    const result = await req.db.query(
      'SELECT id, first_name, last_name, email, role, created_at FROM users WHERE id = $1',
      [req.params.id]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }
    
    const user = result.rows[0];
    
    // Get projects assigned to user
    const projectsQuery = `
      SELECT 
        p.id, p.name, p.status,
        c.name as client_name,
        pu.role as user_role
      FROM projects p
      JOIN clients c ON p.client_id = c.id
      JOIN project_users pu ON p.id = pu.project_id
      WHERE pu.user_id = $1
      ORDER BY p.name
    `;
    
    const projectsResult = await req.db.query(projectsQuery, [req.params.id]);
    
    res.status(200).json({
      success: true,
      data: {
        id: user.id,
        firstName: user.first_name,
        lastName: user.last_name,
        email: user.email,
        role: user.role,
        createdAt: user.created_at,
        projects: projectsResult.rows.map(project => ({
          id: project.id,
          name: project.name,
          clientName: project.client_name,
          status: project.status,
          userRole: project.user_role
        }))
      }
    });
  } catch (error) {
    console.error('Error fetching user:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

// Create a new user (admin only)
router.post('/', checkRole('admin'), async (req, res) => {
  const { firstName, lastName, email, password, role } = req.body;
  
  try {
    // Check if user already exists
    const existingResult = await req.db.query(
      'SELECT id FROM users WHERE email = $1',
      [email]
    );
    
    if (existingResult.rows.length > 0) {
      return res.status(400).json({
        success: false,
        error: 'User with this email already exists'
      });
    }
    
    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    
    // Create user
    const result = await req.db.query(
      `INSERT INTO users (first_name, last_name, email, password, role)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING id, first_name, last_name, email, role`,
      [firstName, lastName, email, hashedPassword, role || 'user']
    );
    
    const user = result.rows[0];
    
    res.status(201).json({
      success: true,
      data: {
        id: user.id,
        firstName: user.first_name,
        lastName: user.last_name,
        email: user.email,
        role: user.role
      }
    });
  } catch (error) {
    console.error('Error creating user:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

// Update a user
router.put('/:id', async (req, res) => {
  const { firstName, lastName, email, role, currentPassword, newPassword } = req.body;
  
  try {
    // Regular users can only update their own data and can't change their role
    if (req.user.role !== 'admin' && (
      req.user.id !== parseInt(req.params.id) || 
      (role && role !== req.user.role)
    )) {
      return res.status(403).json({
        success: false,
        error: 'Access denied'
      });
    }
    
    // Check if user exists
    const userResult = await req.db.query(
      'SELECT * FROM users WHERE id = $1',
      [req.params.id]
    );
    
    if (userResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }
    
    const user = userResult.rows[0];
    
    // Handle password change if requested
    let hashedPassword = user.password;
    
    if (newPassword) {
      // If not admin, verify current password
      if (req.user.role !== 'admin') {
        if (!currentPassword) {
          return res.status(400).json({
            success: false,
            error: 'Current password is required'
          });
        }
        
        const isPasswordValid = await bcrypt.compare(currentPassword, user.password);
        
        if (!isPasswordValid) {
          return res.status(400).json({
            success: false,
            error: 'Current password is incorrect'
          });
        }
      }
      
      // Hash new password
      const salt = await bcrypt.genSalt(10);
      hashedPassword = await bcrypt.hash(newPassword, salt);
    }
    
    // Update user
    const updateQuery = `
      UPDATE users
      SET first_name = $1, last_name = $2, 
          email = $3, password = $4, 
          role = $5, updated_at = NOW()
      WHERE id = $6
      RETURNING id, first_name, last_name, email, role
    `;
    
    const updateResult = await req.db.query(updateQuery, [
      firstName || user.first_name,
      lastName || user.last_name,
      email || user.email,
      hashedPassword,
      (req.user.role === 'admin' && role) ? role : user.role,
      req.params.id
    ]);
    
    const updatedUser = updateResult.rows[0];
    
    res.status(200).json({
      success: true,
      data: {
        id: updatedUser.id,
        firstName: updatedUser.first_name,
        lastName: updatedUser.last_name,
        email: updatedUser.email,
        role: updatedUser.role
      }
    });
  } catch (error) {
    console.error('Error updating user:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

// Delete a user (admin only)
router.delete('/:id', checkRole('admin'), async (req, res) => {
  try {
    // Prevent deleting self
    if (req.user.id === parseInt(req.params.id)) {
      return res.status(400).json({
        success: false,
        error: 'Cannot delete your own account'
      });
    }
    
    // Check if user exists
    const userResult = await req.db.query(
      'SELECT id FROM users WHERE id = $1',
      [req.params.id]
    );
    
    if (userResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }
    
    // Delete user
    await req.db.query('DELETE FROM users WHERE id = $1', [req.params.id]);
    
    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (error) {
    console.error('Error deleting user:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

module.exports = router;
