"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { CheckCircle, ArrowRight } from "lucide-react"

export default function HostSuccessPage() {
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-2xl mx-auto text-center">
        <div className="flex justify-center mb-6">
          <CheckCircle className="h-16 w-16 text-emerald-600" />
        </div>
        <h1 className="text-3xl font-bold mb-4">Your Property Has Been Listed!</h1>
        <p className="text-lg text-gray-600 mb-8">
          Thank you for listing your property with us. Our team will review your listing and it will be live within 24
          hours.
        </p>

        <Card>
          <CardContent className="p-6">
            <h2 className="text-xl font-semibold mb-4">What's Next?</h2>
            <ul className="space-y-4 text-left">
              <li className="flex items-start">
                <div className="bg-emerald-100 rounded-full p-1 mr-3 mt-0.5">
                  <CheckCircle className="h-4 w-4 text-emerald-600" />
                </div>
                <div>
                  <span className="font-medium">Review Process</span>
                  <p className="text-sm text-gray-600">
                    Our team will review your listing to ensure it meets our quality standards.
                  </p>
                </div>
              </li>
              <li className="flex items-start">
                <div className="bg-emerald-100 rounded-full p-1 mr-3 mt-0.5">
                  <CheckCircle className="h-4 w-4 text-emerald-600" />
                </div>
                <div>
                  <span className="font-medium">Listing Goes Live</span>
                  <p className="text-sm text-gray-600">
                    Once approved, your property will be visible to millions of potential guests.
                  </p>
                </div>
              </li>
              <li className="flex items-start">
                <div className="bg-emerald-100 rounded-full p-1 mr-3 mt-0.5">
                  <CheckCircle className="h-4 w-4 text-emerald-600" />
                </div>
                <div>
                  <span className="font-medium">Start Receiving Bookings</span>
                  <p className="text-sm text-gray-600">
                    Get ready to welcome guests and earn income from your property.
                  </p>
                </div>
              </li>
            </ul>
          </CardContent>
        </Card>

        <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/properties">
            <Button variant="outline" className="w-full sm:w-auto">
              Browse Properties
            </Button>
          </Link>
          <Link href="/">
            <Button className="w-full sm:w-auto bg-emerald-600 hover:bg-emerald-700">
              Back to Home <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
