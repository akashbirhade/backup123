"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { DatePickerWithRange } from "@/components/date-range-picker"
import { MapPin, Calendar, Star, Filter, List, MapIcon, ArrowLeft } from "lucide-react"
import PropertyMap from "@/components/property-map"
import { generateMockProperties } from "@/lib/mock-properties"

export default function PropertiesPage() {
  const [viewMode, setViewMode] = useState("grid")
  const [currency, setCurrency] = useState("USD")
  const [properties, setProperties] = useState([])
  const [filters, setFilters] = useState({
    priceRange: [50, 500],
    propertyType: "all",
    dateRange: {
      from: undefined,
      to: undefined,
    },
    location: "paris",
  })

  useEffect(() => {
    // Get any hosted properties from localStorage
    const hostedProperties = JSON.parse(localStorage.getItem("hostedProperties") || "[]")

    // Filter hosted properties by location
    const filteredHostedProperties = hostedProperties.filter(
      (p) => p.location.toLowerCase() === filters.location.toLowerCase(),
    )

    // Get mock properties for the selected location
    const mockProperties = generateMockProperties(filters.location)

    // Combine hosted and mock properties
    setProperties([...filteredHostedProperties, ...mockProperties])
  }, [filters.location])

  const handleFilterChange = (key, value) => {
    setFilters((prev) => ({
      ...prev,
      [key]: value,
    }))
  }

  const currencySymbols = {
    USD: "$",
    EUR: "€",
    GBP: "£",
    JPY: "¥",
    INR: "₹",
  }

  const convertPrice = (price) => {
    // Simple mock conversion rates
    const rates = {
      USD: 1,
      EUR: 0.92,
      GBP: 0.79,
      JPY: 150.2,
      INR: 83.5,
    }

    const convertedPrice = Math.round(price * rates[currency])
    return `${currencySymbols[currency]}${convertedPrice}`
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Link href="/" className="flex items-center text-emerald-600 hover:text-emerald-700">
          <ArrowLeft className="h-4 w-4 mr-1" />
          Back to Home
        </Link>
      </div>

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
        <div>
          <h1 className="text-3xl font-bold">
            Properties in {filters.location.charAt(0).toUpperCase() + filters.location.slice(1)}
          </h1>
          <p className="text-gray-600">{properties.length} properties found</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center">
            <span className="mr-2 text-sm">Currency:</span>
            <Select value={currency} onValueChange={setCurrency}>
              <SelectTrigger className="w-[120px]">
                <SelectValue placeholder="Currency" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="USD">USD ($)</SelectItem>
                <SelectItem value="EUR">EUR (€)</SelectItem>
                <SelectItem value="GBP">GBP (£)</SelectItem>
                <SelectItem value="JPY">JPY (¥)</SelectItem>
                <SelectItem value="INR">INR (₹)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex border rounded-md overflow-hidden">
            <Button
              variant={viewMode === "grid" ? "default" : "ghost"}
              size="sm"
              className={viewMode === "grid" ? "bg-emerald-600 hover:bg-emerald-700" : ""}
              onClick={() => setViewMode("grid")}
            >
              <List className="h-4 w-4" />
            </Button>
            <Button
              variant={viewMode === "map" ? "default" : "ghost"}
              size="sm"
              className={viewMode === "map" ? "bg-emerald-600 hover:bg-emerald-700" : ""}
              onClick={() => setViewMode("map")}
            >
              <MapIcon className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Filters */}
        <div className="lg:col-span-1">
          <Card>
            <CardContent className="p-4">
              <h2 className="text-lg font-semibold mb-4 flex items-center">
                <Filter className="h-4 w-4 mr-2" />
                Filters
              </h2>

              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium mb-2">Location</label>
                  <Select value={filters.location} onValueChange={(value) => handleFilterChange("location", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select location" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="paris">Paris, France</SelectItem>
                      <SelectItem value="bali">Bali, Indonesia</SelectItem>
                      <SelectItem value="tokyo">Tokyo, Japan</SelectItem>
                      <SelectItem value="newyork">New York, USA</SelectItem>
                      <SelectItem value="rome">Rome, Italy</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Dates</label>
                  <DatePickerWithRange
                    date={filters.dateRange}
                    setDate={(date) => handleFilterChange("dateRange", date)}
                  />
                </div>

                <div>
                  <div className="flex justify-between mb-2">
                    <label className="block text-sm font-medium">Price Range</label>
                    <span className="text-sm">
                      {convertPrice(filters.priceRange[0])} - {convertPrice(filters.priceRange[1])}
                    </span>
                  </div>
                  <Slider
                    min={10}
                    max={1000}
                    step={10}
                    value={filters.priceRange}
                    onValueChange={(value) => handleFilterChange("priceRange", value)}
                    className="my-4"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">Property Type</label>
                  <Select
                    value={filters.propertyType}
                    onValueChange={(value) => handleFilterChange("propertyType", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select property type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Properties</SelectItem>
                      <SelectItem value="apartment">Apartments</SelectItem>
                      <SelectItem value="house">Houses</SelectItem>
                      <SelectItem value="villa">Villas</SelectItem>
                      <SelectItem value="hotel">Hotel Rooms</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button className="w-full bg-emerald-600 hover:bg-emerald-700">Apply Filters</Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Property Listings */}
        <div className="lg:col-span-3">
          <Tabs defaultValue="all" className="mb-6">
            <TabsList>
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="apartment">Apartments</TabsTrigger>
              <TabsTrigger value="house">Houses</TabsTrigger>
              <TabsTrigger value="villa">Villas</TabsTrigger>
              <TabsTrigger value="hotel">Hotels</TabsTrigger>
            </TabsList>
          </Tabs>

          {viewMode === "grid" ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {properties.map((property, index) => (
                <PropertyCard key={index} property={property} convertPrice={convertPrice} />
              ))}
            </div>
          ) : (
            <div className="h-[600px] rounded-lg overflow-hidden">
              <PropertyMap properties={properties} convertPrice={convertPrice} />
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

function PropertyCard({ property, convertPrice }) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <Link href={`/properties/${property.id}`}>
        <div className="relative h-48 w-full">
          <img src={property.image || "/placeholder.svg"} alt={property.title} className="w-full h-full object-cover" />
          {property.featured && (
            <div className="absolute top-3 right-3 bg-white rounded-full px-2 py-1 text-xs font-medium text-emerald-600">
              Featured
            </div>
          )}
        </div>
      </Link>
      <div className="p-4">
        <div className="flex justify-between items-start mb-1">
          <h3 className="font-semibold text-lg">{property.title}</h3>
          <div className="flex items-center text-sm">
            <Star className="h-3 w-3 fill-amber-500 text-amber-500 mr-1" />
            <span>{property.rating}</span>
          </div>
        </div>
        <p className="text-gray-600 text-sm mb-2 flex items-center">
          <MapPin className="h-3 w-3 mr-1" />
          {property.location}
        </p>
        <div className="flex items-center text-xs text-gray-500 mb-3">
          <Badge variant="outline" className="mr-2">
            {property.type}
          </Badge>
          <Calendar className="h-3 w-3 mr-1" />
          <span>Available now</span>
        </div>
        <div className="flex justify-between items-center">
          <div className="font-medium">
            {convertPrice(property.price)} <span className="text-gray-500 text-sm">/ night</span>
          </div>
          <Link href={`/properties/${property.id}`}>
            <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700">
              View Details
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
