
import React from 'react';
import { Badge } from "@/components/ui/badge";

export const CalendarLegend = () => {
  return (
    <div className="text-sm mb-3 flex flex-wrap gap-2">
      <Badge className="bg-green-500">Complete</Badge>
      <Badge className="bg-amber-400">Partial</Badge>
      <Badge className="bg-red-500">Missing</Badge>
      <Badge className="bg-blue-500">Weekend</Badge>
      <Badge className="bg-purple-500">Company Holiday</Badge>
    </div>
  );
};
