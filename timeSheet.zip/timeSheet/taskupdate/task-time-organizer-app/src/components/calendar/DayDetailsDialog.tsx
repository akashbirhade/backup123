
import React from 'react';
import { format, isWeekend } from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Pencil } from "lucide-react";
import { useCalendarStore } from "@/stores/calendarStore";

interface DayDetailsDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  selectedDate: Date | null;
}

export const DayDetailsDialog = ({ 
  isOpen, 
  onOpenChange, 
  selectedDate 
}: DayDetailsDialogProps) => {
  const { calendarEntries, companyHolidays } = useCalendarStore();

  const getEntryForDate = (date: Date) => {
    return calendarEntries.find(entry => 
      entry.date.getDate() === date.getDate() && 
      entry.date.getMonth() === date.getMonth() && 
      entry.date.getFullYear() === date.getFullYear()
    );
  };

  const getHolidayForDate = (date: Date) => {
    return companyHolidays.find(holiday => 
      holiday.date.getDate() === date.getDate() && 
      holiday.date.getMonth() === date.getMonth()
    );
  };

  if (!selectedDate) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold">
            {format(selectedDate, 'EEEE, MMMM d, yyyy')}
          </DialogTitle>
        </DialogHeader>
        
        <div className="py-4">
          {(() => {
            // Check if it's a weekend
            if (isWeekend(selectedDate)) {
              return (
                <div className="space-y-4">
                  <div>
                    <p className="font-semibold mb-2">Weekend</p>
                    <Badge className="bg-blue-500">Weekend Off</Badge>
                  </div>
                </div>
              );
            }
            
            // Check if it's a company holiday
            const holiday = getHolidayForDate(selectedDate);
            if (holiday) {
              return (
                <div className="space-y-4">
                  <div>
                    <p className="font-semibold mb-2">Company Holiday</p>
                    <Badge className="bg-purple-500">{holiday.name}</Badge>
                    {holiday.description && (
                      <p className="mt-2 text-sm text-gray-600">{holiday.description}</p>
                    )}
                  </div>
                </div>
              );
            }
            
            // Check for timesheet entry
            const entry = getEntryForDate(selectedDate);
            
            if (!entry) {
              return <p>No timesheet data available for this date.</p>;
            }
            
            return (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="font-semibold">Status</p>
                    <Badge 
                      className={
                        entry.status === 'complete' ? "bg-green-500" : 
                        entry.status === 'partial' ? "bg-amber-400" : 
                        "bg-red-500"
                      }
                    >
                      {entry.status.charAt(0).toUpperCase() + entry.status.slice(1)}
                    </Badge>
                  </div>
                  <div>
                    <p className="font-semibold">Total Hours</p>
                    <p className="text-xl font-bold">{entry.hours}</p>
                  </div>
                </div>
                
                {entry.tasks.length > 0 ? (
                  <div>
                    <p className="font-semibold mb-2">Tasks</p>
                    {entry.tasks.map((task, i) => (
                      <div key={i} className="border-b pb-2 mb-2 last:border-0">
                        <div className="flex justify-between">
                          <p className="font-medium">{task.description}</p>
                          <p>{task.hours} hrs</p>
                        </div>
                        <p className="text-sm text-gray-500">{task.project}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p>No tasks logged for this day.</p>
                )}
              </div>
            );
          })()}
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Close
          </Button>
          <Button className="flex items-center gap-1">
            <Pencil className="h-4 w-4" /> 
            Edit Day
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
