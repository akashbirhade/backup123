
import React, { useState } from 'react';
import { format } from 'date-fns';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { AbsenceDay } from '@/types/timesheet';
import { Umbrella, AlarmClock, Flag } from 'lucide-react';

interface AbsenceDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  selectedDay: Date | null;
  existingAbsence: AbsenceDay | undefined;
  onSubmit: (absenceType: 'leave' | 'half-day' | 'holiday', note: string) => void;
}

const AbsenceDialog: React.FC<AbsenceDialogProps> = ({
  isOpen,
  onOpenChange,
  selectedDay,
  existingAbsence,
  onSubmit
}) => {
  const [absenceType, setAbsenceType] = useState<'leave' | 'half-day' | 'holiday'>(
    existingAbsence?.type || 'leave'
  );
  const [absenceNote, setAbsenceNote] = useState<string>(
    existingAbsence?.note || ''
  );

  // Reset state when dialog opens with new data
  React.useEffect(() => {
    if (isOpen && existingAbsence) {
      setAbsenceType(existingAbsence.type);
      setAbsenceNote(existingAbsence.note || '');
    } else if (isOpen) {
      setAbsenceType('leave');
      setAbsenceNote('');
    }
  }, [isOpen, existingAbsence]);

  const handleSubmit = () => {
    onSubmit(absenceType, absenceNote);
  };

  if (!selectedDay) {
    return null;
  }

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Record Absence</DialogTitle>
          <DialogDescription>
            Record absence for {format(selectedDay, "EEEE, MMMM d, yyyy")}
          </DialogDescription>
        </DialogHeader>
        
        <div className="py-4">
          <RadioGroup value={absenceType} onValueChange={(value) => setAbsenceType(value as 'leave' | 'half-day' | 'holiday')}>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="leave" id="leave" />
              <Label htmlFor="leave" className="flex items-center">
                <Umbrella className="h-4 w-4 mr-2" /> Full Day Leave
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="half-day" id="half-day" />
              <Label htmlFor="half-day" className="flex items-center">
                <AlarmClock className="h-4 w-4 mr-2" /> Half Day
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="holiday" id="holiday" />
              <Label htmlFor="holiday" className="flex items-center">
                <Flag className="h-4 w-4 mr-2" /> Holiday
              </Label>
            </div>
          </RadioGroup>
          
          <div className="mt-4">
            <Label htmlFor="note">Note (Optional)</Label>
            <Textarea
              id="note"
              value={absenceNote}
              onChange={(e) => setAbsenceNote(e.target.value)}
              placeholder="Add a note about this absence"
              className="mt-1"
            />
          </div>
        </div>
        
        <DialogFooter>
          <Button 
            variant="outline" 
            onClick={() => onOpenChange(false)}
          >
            Cancel
          </Button>
          <Button onClick={handleSubmit}>Save</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AbsenceDialog;
