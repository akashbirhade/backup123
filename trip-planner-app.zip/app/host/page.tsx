"use client"

import { useState } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { ArrowLeft, Check, Info } from "lucide-react"
import { PhotoUpload } from "@/components/photo-upload"

export default function HostPropertyPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    type: "",
    location: "",
    price: 100,
    bedrooms: "",
    bathrooms: "",
    guests: "",
    amenities: [],
    images: [],
    address: "",
    coordinates: { lat: 0, lng: 0 },
    availableDates: [],
  })

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleAmenityToggle = (amenity) => {
    setFormData((prev) => {
      const amenities = [...prev.amenities]
      if (amenities.includes(amenity)) {
        return { ...prev, amenities: amenities.filter((a) => a !== amenity) }
      } else {
        return { ...prev, amenities: [...amenities, amenity] }
      }
    })
  }

  const handlePhotosChange = (photos) => {
    handleInputChange("images", photos)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)

    // Create a unique ID for the property
    const propertyId = `${formData.location}-${Date.now()}`

    // Prepare property data
    const propertyData = {
      id: propertyId,
      title: formData.title,
      location: formData.location.charAt(0).toUpperCase() + formData.location.slice(1),
      price: formData.price,
      rating: (4 + Math.random()).toFixed(1),
      reviews: Math.floor(Math.random() * 50) + 5,
      image: formData.images.length > 0 ? formData.images[0].preview : "/placeholder.svg?height=200&width=350",
      description: formData.description,
      type: formData.type,
      bedrooms: formData.bedrooms,
      bathrooms: formData.bathrooms,
      guests: formData.guests,
      featured: false,
      coordinates: {
        x: Math.random() * 100,
        y: Math.random() * 100,
      },
      amenities: formData.amenities,
      address: formData.address,
      availableDates: formData.availableDates,
    }

    // In a real app, we would send this to an API
    // For this demo, we'll store it in localStorage
    const existingProperties = JSON.parse(localStorage.getItem("hostedProperties") || "[]")
    localStorage.setItem("hostedProperties", JSON.stringify([...existingProperties, propertyData]))

    // Simulate API call delay
    setTimeout(() => {
      setLoading(false)
      router.push("/host/success")
    }, 1500)
  }

  const nextStep = () => setStep(step + 1)
  const prevStep = () => setStep(step - 1)

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Link href="/" className="flex items-center text-emerald-600 hover:text-emerald-700">
          <ArrowLeft className="h-4 w-4 mr-1" />
          Back to Home
        </Link>
      </div>

      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold text-center mb-2">List Your Property</h1>
        <p className="text-center text-gray-600 mb-8">Share your space and start earning</p>

        <div className="mb-8">
          <div className="flex justify-between items-center relative">
            <div className="absolute left-0 right-0 top-1/2 h-1 bg-gray-200 -z-10"></div>
            {[1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  step >= i ? "bg-emerald-600 text-white" : "bg-gray-200 text-gray-600"
                }`}
              >
                {step > i ? <Check className="h-5 w-5" /> : i}
              </div>
            ))}
          </div>
          <div className="flex justify-between mt-2 text-sm">
            <span>Basic Info</span>
            <span>Details</span>
            <span>Amenities</span>
            <span>Photos</span>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>
              {step === 1 && "Basic Information"}
              {step === 2 && "Property Details"}
              {step === 3 && "Amenities"}
              {step === 4 && "Photos & Availability"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit}>
              {step === 1 && (
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="title">Property Title</Label>
                    <Input
                      id="title"
                      placeholder="e.g. Cozy Apartment in Downtown"
                      value={formData.title}
                      onChange={(e) => handleInputChange("title", e.target.value)}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      placeholder="Describe your property..."
                      value={formData.description}
                      onChange={(e) => handleInputChange("description", e.target.value)}
                      rows={4}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="type">Property Type</Label>
                    <Select value={formData.type} onValueChange={(value) => handleInputChange("type", value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select property type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="apartment">Apartment</SelectItem>
                        <SelectItem value="house">House</SelectItem>
                        <SelectItem value="villa">Villa</SelectItem>
                        <SelectItem value="hotel">Hotel Room</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="location">Location</Label>
                    <Select value={formData.location} onValueChange={(value) => handleInputChange("location", value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select location" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="paris">Paris, France</SelectItem>
                        <SelectItem value="bali">Bali, Indonesia</SelectItem>
                        <SelectItem value="tokyo">Tokyo, Japan</SelectItem>
                        <SelectItem value="newyork">New York, USA</SelectItem>
                        <SelectItem value="rome">Rome, Italy</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="address">Address</Label>
                    <Input
                      id="address"
                      placeholder="Enter the full address"
                      value={formData.address}
                      onChange={(e) => handleInputChange("address", e.target.value)}
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      This will not be shared publicly, only the general location will be shown on the map
                    </p>
                  </div>

                  <div className="flex justify-end">
                    <Button type="button" onClick={nextStep} className="bg-emerald-600 hover:bg-emerald-700">
                      Next
                    </Button>
                  </div>
                </div>
              )}

              {step === 2 && (
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-2">
                      <Label htmlFor="price">Price per night (${formData.price})</Label>
                    </div>
                    <Slider
                      id="price"
                      min={10}
                      max={1000}
                      step={5}
                      value={[formData.price]}
                      onValueChange={(value) => handleInputChange("price", value[0])}
                    />
                    <div className="flex justify-between text-xs text-gray-500 mt-1">
                      <span>$10</span>
                      <span>$1000</span>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="bedrooms">Bedrooms</Label>
                    <Select value={formData.bedrooms} onValueChange={(value) => handleInputChange("bedrooms", value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select number of bedrooms" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="0">Studio</SelectItem>
                        <SelectItem value="1">1 Bedroom</SelectItem>
                        <SelectItem value="2">2 Bedrooms</SelectItem>
                        <SelectItem value="3">3 Bedrooms</SelectItem>
                        <SelectItem value="4">4 Bedrooms</SelectItem>
                        <SelectItem value="5+">5+ Bedrooms</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="bathrooms">Bathrooms</Label>
                    <Select value={formData.bathrooms} onValueChange={(value) => handleInputChange("bathrooms", value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select number of bathrooms" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 Bathroom</SelectItem>
                        <SelectItem value="1.5">1.5 Bathrooms</SelectItem>
                        <SelectItem value="2">2 Bathrooms</SelectItem>
                        <SelectItem value="2.5">2.5 Bathrooms</SelectItem>
                        <SelectItem value="3+">3+ Bathrooms</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="guests">Max Guests</Label>
                    <Select value={formData.guests} onValueChange={(value) => handleInputChange("guests", value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select maximum number of guests" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 Guest</SelectItem>
                        <SelectItem value="2">2 Guests</SelectItem>
                        <SelectItem value="3">3 Guests</SelectItem>
                        <SelectItem value="4">4 Guests</SelectItem>
                        <SelectItem value="5">5 Guests</SelectItem>
                        <SelectItem value="6+">6+ Guests</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex justify-between">
                    <Button type="button" variant="outline" onClick={prevStep}>
                      Back
                    </Button>
                    <Button type="button" onClick={nextStep} className="bg-emerald-600 hover:bg-emerald-700">
                      Next
                    </Button>
                  </div>
                </div>
              )}

              {step === 3 && (
                <div className="space-y-4">
                  <div>
                    <Label className="mb-2 block">Amenities</Label>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="wifi"
                          checked={formData.amenities.includes("wifi")}
                          onCheckedChange={() => handleAmenityToggle("wifi")}
                        />
                        <label
                          htmlFor="wifi"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          WiFi
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="kitchen"
                          checked={formData.amenities.includes("kitchen")}
                          onCheckedChange={() => handleAmenityToggle("kitchen")}
                        />
                        <label
                          htmlFor="kitchen"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Kitchen
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="ac"
                          checked={formData.amenities.includes("ac")}
                          onCheckedChange={() => handleAmenityToggle("ac")}
                        />
                        <label
                          htmlFor="ac"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Air Conditioning
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="tv"
                          checked={formData.amenities.includes("tv")}
                          onCheckedChange={() => handleAmenityToggle("tv")}
                        />
                        <label
                          htmlFor="tv"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          TV
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="parking"
                          checked={formData.amenities.includes("parking")}
                          onCheckedChange={() => handleAmenityToggle("parking")}
                        />
                        <label
                          htmlFor="parking"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Free Parking
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="pool"
                          checked={formData.amenities.includes("pool")}
                          onCheckedChange={() => handleAmenityToggle("pool")}
                        />
                        <label
                          htmlFor="pool"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Swimming Pool
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="washer"
                          checked={formData.amenities.includes("washer")}
                          onCheckedChange={() => handleAmenityToggle("washer")}
                        />
                        <label
                          htmlFor="washer"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Washer
                        </label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="dryer"
                          checked={formData.amenities.includes("dryer")}
                          onCheckedChange={() => handleAmenityToggle("dryer")}
                        />
                        <label
                          htmlFor="dryer"
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          Dryer
                        </label>
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-between">
                    <Button type="button" variant="outline" onClick={prevStep}>
                      Back
                    </Button>
                    <Button type="button" onClick={nextStep} className="bg-emerald-600 hover:bg-emerald-700">
                      Next
                    </Button>
                  </div>
                </div>
              )}

              {step === 4 && (
                <div className="space-y-4">
                  <div>
                    <Label className="mb-2 block">Property Photos</Label>
                    <PhotoUpload onPhotosChange={handlePhotosChange} />
                  </div>

                  <div className="bg-blue-50 border border-blue-200 rounded-md p-3 flex items-start">
                    <Info className="h-5 w-5 text-blue-500 mr-2 shrink-0 mt-0.5" />
                    <p className="text-sm text-blue-700">
                      High-quality photos significantly increase your chances of getting bookings. Make sure your photos
                      are well-lit and showcase the best features of your property.
                    </p>
                  </div>

                  <div className="flex justify-between">
                    <Button type="button" variant="outline" onClick={prevStep}>
                      Back
                    </Button>
                    <Button type="submit" className="bg-emerald-600 hover:bg-emerald-700" disabled={loading}>
                      {loading ? "Submitting..." : "List Your Property"}
                    </Button>
                  </div>
                </div>
              )}
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
