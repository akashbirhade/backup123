
import React from 'react';
import { cn } from '@/lib/utils';
import { Input } from '@/components/ui/input';

interface TimeEntryProps {
  value: string;
  day: number;
  taskId: string;
  onChange: (value: string, day: number, taskId: string) => void;
  disabled?: boolean;
}

const TimeEntry: React.FC<TimeEntryProps> = ({
  value,
  day,
  taskId,
  onChange,
  disabled = false
}) => {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    if (newValue === '' || (!isNaN(Number(newValue)) && Number(newValue) >= 0 && Number(newValue) <= 24)) {
      onChange(newValue, day, taskId);
    }
  };

  return (
    <Input
      type="text"
      value={value}
      onChange={handleChange}
      className={cn(
        "timesheet-input h-full",
        disabled && "bg-gray-100",
        Number(value) > 0 && "bg-blue-50"
      )}
      disabled={disabled}
      maxLength={4}
    />
  );
};

export default TimeEntry;
