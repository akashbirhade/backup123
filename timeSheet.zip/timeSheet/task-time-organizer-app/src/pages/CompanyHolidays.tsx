
import React, { useState } from 'react';
import { format } from 'date-fns';
import { Calendar } from '@/components/ui/calendar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { CalendarPlus, Pencil, Trash2, Calendar as CalendarIcon } from 'lucide-react';
import { useCalendarStore, CompanyHoliday } from '@/stores/calendarStore';
import { Badge } from '@/components/ui/badge';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { cn } from '@/lib/utils';

const CompanyHolidays = () => {
  const { companyHolidays, addCompanyHoliday, updateCompanyHoliday, removeCompanyHoliday } = useCalendarStore();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedHoliday, setSelectedHoliday] = useState<CompanyHoliday | null>(null);
  
  // Form state
  const [holidayDate, setHolidayDate] = useState<Date>(new Date());
  const [holidayName, setHolidayName] = useState('');
  const [holidayDescription, setHolidayDescription] = useState('');
  const [isRecurringYearly, setIsRecurringYearly] = useState(false);
  
  const resetForm = () => {
    setHolidayDate(new Date());
    setHolidayName('');
    setHolidayDescription('');
    setIsRecurringYearly(false);
  };
  
  const openAddDialog = () => {
    resetForm();
    setIsAddDialogOpen(true);
  };
  
  const openEditDialog = (holiday: CompanyHoliday) => {
    setSelectedHoliday(holiday);
    setHolidayDate(new Date(holiday.date));
    setHolidayName(holiday.name);
    setHolidayDescription(holiday.description || '');
    setIsRecurringYearly(holiday.isRecurringYearly || false);
    setIsEditDialogOpen(true);
  };
  
  const openDeleteDialog = (holiday: CompanyHoliday) => {
    setSelectedHoliday(holiday);
    setIsDeleteDialogOpen(true);
  };
  
  const handleAddHoliday = () => {
    if (!holidayName) {
      toast.error('Please enter a holiday name');
      return;
    }
    
    const newHoliday: CompanyHoliday = {
      id: Date.now().toString(),
      date: holidayDate,
      name: holidayName,
      description: holidayDescription || undefined,
      isRecurringYearly,
    };
    
    addCompanyHoliday(newHoliday);
    toast.success('Holiday added successfully');
    setIsAddDialogOpen(false);
    resetForm();
  };
  
  const handleUpdateHoliday = () => {
    if (!selectedHoliday || !holidayName) return;
    
    updateCompanyHoliday(selectedHoliday.id, {
      date: holidayDate,
      name: holidayName,
      description: holidayDescription || undefined,
      isRecurringYearly,
    });
    
    toast.success('Holiday updated successfully');
    setIsEditDialogOpen(false);
    resetForm();
  };
  
  const handleDeleteHoliday = () => {
    if (!selectedHoliday) return;
    
    removeCompanyHoliday(selectedHoliday.id);
    toast.success('Holiday deleted successfully');
    setIsDeleteDialogOpen(false);
  };
  
  return (
    <div className="container mx-auto">
      <h1 className="text-3xl font-bold mb-6">Company Holidays</h1>
      
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Company Holidays Calendar</CardTitle>
              <CardDescription>Manage company-wide holidays and celebrations</CardDescription>
            </div>
            <Button onClick={openAddDialog}>
              <CalendarPlus className="w-4 h-4 mr-2" />
              Add Holiday
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableCaption>A list of company holidays for the current year.</TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Holiday Name</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Type</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {companyHolidays.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center">
                    No holidays defined yet. Add your first holiday above.
                  </TableCell>
                </TableRow>
              ) : (
                companyHolidays
                  .sort((a, b) => a.date.getTime() - b.date.getTime())
                  .map((holiday) => (
                    <TableRow key={holiday.id}>
                      <TableCell>{format(new Date(holiday.date), 'MMMM dd, yyyy')}</TableCell>
                      <TableCell className="font-medium">{holiday.name}</TableCell>
                      <TableCell>{holiday.description || '-'}</TableCell>
                      <TableCell>
                        {holiday.isRecurringYearly ? (
                          <Badge variant="secondary">Yearly</Badge>
                        ) : (
                          <Badge variant="outline">One-time</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openEditDialog(holiday)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openDeleteDialog(holiday)}
                          >
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      {/* Add Holiday Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Add Company Holiday</DialogTitle>
            <DialogDescription>
              Add a new company-wide holiday to the calendar.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="holiday-date">Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    id="holiday-date"
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !holidayDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {holidayDate ? format(holidayDate, 'PPP') : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={holidayDate}
                    onSelect={(date) => date && setHolidayDate(date)}
                    initialFocus
                    className="p-3 pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="holiday-name">Holiday Name</Label>
              <Input
                id="holiday-name"
                value={holidayName}
                onChange={(e) => setHolidayName(e.target.value)}
                placeholder="E.g., New Year's Day"
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="holiday-description">Description (Optional)</Label>
              <Textarea
                id="holiday-description"
                value={holidayDescription}
                onChange={(e) => setHolidayDescription(e.target.value)}
                placeholder="Add additional details about this holiday"
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <Switch
                id="recurring"
                checked={isRecurringYearly}
                onCheckedChange={setIsRecurringYearly}
              />
              <Label htmlFor="recurring">Repeats yearly</Label>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAddHoliday}>
              Add Holiday
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Edit Holiday Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Edit Holiday</DialogTitle>
            <DialogDescription>
              Make changes to the holiday details.
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-holiday-date">Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    id="edit-holiday-date"
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !holidayDate && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {holidayDate ? format(holidayDate, 'PPP') : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={holidayDate}
                    onSelect={(date) => date && setHolidayDate(date)}
                    initialFocus
                    className="p-3 pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="edit-holiday-name">Holiday Name</Label>
              <Input
                id="edit-holiday-name"
                value={holidayName}
                onChange={(e) => setHolidayName(e.target.value)}
                placeholder="E.g., New Year's Day"
              />
            </div>
            
            <div className="grid gap-2">
              <Label htmlFor="edit-holiday-description">Description (Optional)</Label>
              <Textarea
                id="edit-holiday-description"
                value={holidayDescription}
                onChange={(e) => setHolidayDescription(e.target.value)}
                placeholder="Add additional details about this holiday"
              />
            </div>
            
            <div className="flex items-center space-x-2">
              <Switch
                id="edit-recurring"
                checked={isRecurringYearly}
                onCheckedChange={setIsRecurringYearly}
              />
              <Label htmlFor="edit-recurring">Repeats yearly</Label>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleUpdateHoliday}>
              Update Holiday
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Delete Holiday Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Delete Holiday</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this holiday?
            </DialogDescription>
          </DialogHeader>
          
          {selectedHoliday && (
            <div className="py-4">
              <p><strong>Date:</strong> {format(new Date(selectedHoliday.date), 'MMMM dd, yyyy')}</p>
              <p><strong>Name:</strong> {selectedHoliday.name}</p>
              {selectedHoliday.description && (
                <p><strong>Description:</strong> {selectedHoliday.description}</p>
              )}
              <p>
                <strong>Type:</strong> {selectedHoliday.isRecurringYearly ? 'Yearly recurring' : 'One-time holiday'}
              </p>
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteHoliday}>
              Delete Holiday
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CompanyHolidays;
