
import React from 'react';
import { cn } from '@/lib/utils';
import { Input } from '@/components/ui/input';

interface TimeEntryProps {
  value: string;
  day: number;
  taskId: string;
  onChange: (value: string, day: number, taskId: string) => void;
  disabled?: boolean;
  maxValue?: number;
}

const TimeEntry: React.FC<TimeEntryProps> = ({
  value,
  day,
  taskId,
  onChange,
  disabled = false,
  maxValue
}) => {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    
    // Check if the new value is valid
    if (newValue === '' || (!isNaN(Number(newValue)) && Number(newValue) >= 0)) {
      // Check if we need to limit the value
      if (maxValue !== undefined && Number(newValue) > maxValue) {
        onChange(String(maxValue), day, taskId);
      } else if (Number(newValue) <= 24) {
        onChange(newValue, day, taskId);
      }
    }
  };

  return (
    <Input
      type="text"
      value={value}
      onChange={handleChange}
      className={cn(
        "timesheet-input h-full",
        disabled && "bg-gray-100",
        Number(value) > 0 && "bg-blue-50"
      )}
      disabled={disabled}
      maxLength={4}
      title={maxValue !== undefined ? `Maximum allowed: ${maxValue} hours` : undefined}
    />
  );
};

export default TimeEntry;
