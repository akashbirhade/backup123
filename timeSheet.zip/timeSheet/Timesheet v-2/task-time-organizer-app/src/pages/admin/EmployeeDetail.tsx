import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { usersApi, reportsApi } from '@/integrations/api/client';
import { User, Report } from '@/integrations/api/types';
import { Button } from '@/components/ui/button';
import DateRangePicker from '@/components/DateRangePicker';
import { Line } from 'react-chartjs-2';

const EmployeeDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState<{ start: Date; end: Date }>(() => {
    const end = new Date();
    const start = new Date();
    start.setDate(end.getDate() - 30);
    return { start, end };
  });
  const [report, setReport] = useState<Report | null>(null);
  const [downloading, setDownloading] = useState(false);

  useEffect(() => {
    const fetchUser = async () => {
      setLoading(true);
      const res = await usersApi.getUsers();
      if (res.success && res.data) {
        const foundUser = res.data.find((u: User) => u.id === Number(id));
        setUser(foundUser || null);
      }
      setLoading(false);
    };
    fetchUser();
  }, [id]);

  useEffect(() => {
    const fetchReport = async () => {
      if (!id) return;
      const res = await reportsApi.generateReport('weekly', {
        startDate: dateRange.start.toISOString().slice(0, 10),
        endDate: dateRange.end.toISOString().slice(0, 10),
        userId: Number(id),
      });
      if (res.success && res.data) setReport(res.data);
    };
    fetchReport();
  }, [id, dateRange]);

  const handleDownload = async () => {
    setDownloading(true);
    // Use reportsApi.exportReport to download the report as PDF
    const res = await reportsApi.exportReport(
      'weekly',
      'pdf',
      {
        startDate: dateRange.start.toISOString().slice(0, 10),
        endDate: dateRange.end.toISOString().slice(0, 10),
        userId: Number(id),
      }
    );
    // Assume exportReport returns a Blob or file directly
    if (res && typeof res !== 'string') {
      const url = window.URL.createObjectURL(res as Blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `report_${user?.firstName}_${user?.lastName}.pdf`;
      a.click();
      window.URL.revokeObjectURL(url);
    } else {
      // Optionally handle error or string response
      alert('Failed to download report. Please try again.');
    }
    setDownloading(false);
  };

  if (loading) return <div>Loading...</div>;
  if (!user) return <div>User not found.</div>;

  // Prepare chart data (example: weekly hours)
  // Use ReportEntry from API types to avoid type conflicts
  // Remove local ReportEntry type definition

  const entries: Report['entries'] = (report && Array.isArray(report.entries))
    ? report.entries
    : [];

  const chartData = entries.length > 0
    ? {
        labels: entries.map((w) => w.date),
        datasets: [
          {
            label: 'Hours',
            data: entries.map((w) => w.hours),
            borderColor: '#2563eb',
            backgroundColor: 'rgba(37,99,235,0.1)',
            fill: true,
          },
        ],
      }
    : null;

  return (
    <div className="max-w-2xl mx-auto py-8 space-y-6">
      <h2 className="text-2xl font-bold">{user.firstName} {user.lastName}</h2>
      <div className="text-gray-500">{user.email}</div>
      <div className="text-xs text-gray-400">Role: {user.role}</div>
      <div className="pt-4">
        {/* <DateRangePicker range={dateRange} onChange={setDateRange} /> */}
        <Button onClick={handleDownload} disabled={downloading} className="ml-4">
          {downloading ? 'Downloading...' : 'Download Report'}
        </Button>
      </div>
      <div className="pt-6">
        {chartData ? (
          <Line data={chartData} options={{ responsive: true, plugins: { legend: { display: false } } }} />
        ) : (
          <div>No performance data available.</div>
        )}
      </div>
    </div>
  );
};

export default EmployeeDetail;
