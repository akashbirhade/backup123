
import React, { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { Download, MapPin, Calendar, Award, Coffee, Github, Linkedin, Twitter, Instagram } from 'lucide-react';

interface HeroProps {
  isDark: boolean;
}

const Hero: React.FC<HeroProps> = ({ isDark }) => {
  const sectionRef = useRef<HTMLElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const aboutRef = useRef<HTMLDivElement>(null);
  const networkRef = useRef<HTMLCanvasElement>(null);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [currentTitle, setCurrentTitle] = useState('');
  const [titleIndex, setTitleIndex] = useState(0);
  const [charIndex, setCharIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);

  const titles = [
    'Web Developer',
    'Frontend Developer', 
    'Full Stack Developer',
    'React Developer'
  ];

  // Auto-typing effect
  useEffect(() => {
    const typeSpeed = isDeleting ? 50 : 100;
    const pauseTime = isDeleting ? 500 : 2000;

    const timer = setTimeout(() => {
      const currentTitleText = titles[titleIndex];
      
      if (!isDeleting && charIndex < currentTitleText.length) {
        setCurrentTitle(currentTitleText.substring(0, charIndex + 1));
        setCharIndex(charIndex + 1);
      } else if (isDeleting && charIndex > 0) {
        setCurrentTitle(currentTitleText.substring(0, charIndex - 1));
        setCharIndex(charIndex - 1);
      } else if (!isDeleting && charIndex === currentTitleText.length) {
        setTimeout(() => setIsDeleting(true), pauseTime);
      } else if (isDeleting && charIndex === 0) {
        setIsDeleting(false);
        setTitleIndex((titleIndex + 1) % titles.length);
      }
    }, typeSpeed);

    return () => clearTimeout(timer);
  }, [charIndex, isDeleting, titleIndex, titles]);

  // Animation and network effects
  useEffect(() => {
    const tl = gsap.timeline();

    tl.fromTo(contentRef.current,
      { opacity: 0, x: -100 },
      { opacity: 1, x: 0, duration: 1, ease: "power3.out" }
    )
    .fromTo(imageRef.current,
      { opacity: 0, x: 100, scale: 0.8 },
      { opacity: 1, x: 0, scale: 1, duration: 1, ease: "power3.out" },
      "-=0.5"
    );

    // Network animation
    const canvas = networkRef.current;
    if (canvas) {
      const ctx = canvas.getContext('2d');
      const particles = [];
      
      const resizeCanvas = () => {
        canvas.width = canvas.offsetWidth;
        canvas.height = canvas.offsetHeight;
      };
      
      resizeCanvas();
      window.addEventListener('resize', resizeCanvas);

      // Create particles
      for (let i = 0; i < 500; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          vx: (Math.random() - 0.5) * 0.5,
          vy: (Math.random() - 0.5) * 0.5,
          size: Math.random() * 2 + 1
        });
      }

      const animate = () => {
        if (!ctx) return;
        
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Update particles
        particles.forEach(particle => {
          particle.x += particle.vx;
          particle.y += particle.vy;
          
          if (particle.x < 0 || particle.x > canvas.width) particle.vx *= -1;
          if (particle.y < 0 || particle.y > canvas.height) particle.vy *= -1;
        });

        // Draw connections
        ctx.strokeStyle = isDark ? 'rgba(59, 130, 246, 0.1)' : 'rgba(59, 130, 246, 0.1)';
        // ctx.strokeStyle = isDark ? 'red' : 'black';
        ctx.lineWidth = 1;
        
        for (let i = 0; i < particles.length; i++) {
          for (let j = i + 1; j < particles.length; j++) {
            const dx = particles[i].x - particles[j].x;
            const dy = particles[i].y - particles[j].y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            
            if (distance < 100) {
              ctx.beginPath();
              ctx.moveTo(particles[i].x, particles[i].y);
              ctx.lineTo(particles[j].x, particles[j].y);
              ctx.stroke();
            }
          }
        }

        // Draw particles
        // ctx.fillStyle = isDark ? 'rgba(59, 130, 246, 0.6)' : 'rgba(59, 130, 246, 0.6)';
        ctx.fillStyle = isDark ? 'red' : 'black';
        particles.forEach(particle => {
          ctx.beginPath();
          ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
          ctx.fill();
        });

        requestAnimationFrame(animate);
      };

      animate();

      return () => {
        window.removeEventListener('resize', resizeCanvas);
      };
    }
  }, [isDark]);

  const handleMouseMove = (e: React.MouseEvent) => {
    const rect = sectionRef.current?.getBoundingClientRect();
    if (rect) {
      setMousePosition({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      });
    }
  };

  const handleDownloadResume = () => {
    // Create a sample resume content
    const resumeContent = `
AKASH BIRHADE
Frontend Developer with Full-Stack Skills
Email: akash.birhade@gmail.com
Location: Mumbai, India

EXPERIENCE:
• 3+ Years in Web Development
• 50+ Projects Completed
• Specialized in React, TypeScript, Node.js

SKILLS:
• Frontend: React, TypeScript, JavaScript, HTML5, CSS3
• Backend: Node.js, Express, MongoDB
• Tools: Git, GSAP, Material UI, Redux

PROJECTS:
• Portfolio Website with Interactive Animations
• E-commerce Applications
• Full-Stack Web Applications
    `;

    const blob = new Blob([resumeContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'Akash_Birhade_Resume.txt';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const socialLinks = [
    { icon: Github, href: 'https://github.com/akash-birhade', color: 'bg-gray-800' },
    { icon: Linkedin, href: 'https://www.linkedin.com/in/akash-birhade-5a2579157/', color: 'bg-blue-600' },
    { icon: Twitter, href: '#', color: 'bg-blue-400' },
    { icon: Instagram, href: '#', color: 'bg-pink-500' }
  ];

  const scrollToSection = (sectionId: string) => {
    const element = document.querySelector(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      {/* Hero Section */}
      <section 
        id="home" 
        ref={sectionRef}
        className="relative min-h-screen flex items-center py-20 px-4 max-w-7xl mx-auto overflow-hidden"
        onMouseMove={handleMouseMove}
      >
        {/* Animated Network Background */}
        <canvas
          ref={networkRef}
          className="absolute inset-0 z-0 opacity-30"
          style={{ width: '100%', height: '100%' }}
        />

        {/* Mouse Cursor Effect */}
        <div
          className="absolute w-32 h-32 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-full blur-xl pointer-events-none transition-all duration-300 ease-out z-10"
          style={{
            left: mousePosition.x - 64,
            top: mousePosition.y - 64,
          }}
        />

        <div className="relative z-20 w-full">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-16 items-center">
            {/* Content - Left Side */}
            <div ref={contentRef} className="space-y-6 lg:space-y-8 order-2 lg:order-1">
              {/* Greeting */}
              <div className="space-y-4">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 dark:text-white">
                  Hi There,
                </h1>
                <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold">
                  I'm{' '}
                  <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-orange-500 bg-clip-text text-transparent">
                    Akash.
                  </span>
                  <span className="bg-gradient-to-r from-orange-500 to-red-500 bg-clip-text text-transparent">
                    Birhade
                  </span>
                </h2>
                <p className="text-xl md:text-2xl lg:text-3xl text-gray-700 dark:text-gray-300 font-medium">
                  I Am A{' '}
                  <span className="text-red-600 dark:text-red-400 font-bold min-h-[1.2em] inline-block">
                    {currentTitle}
                    <span className="animate-pulse">|</span>
                  </span>
                </p>
              </div>

              {/* About Description */}
              <div className="space-y-4">
                <p className="text-base lg:text-lg text-gray-600 dark:text-gray-400 leading-relaxed">
                  Frontend Developer with Full-Stack Skills. Passionate about creating beautiful, 
                  functional web applications using React, TypeScript, and modern technologies.
                </p>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-4">
                <button 
                  onClick={handleDownloadResume}
                  className="group relative px-6 lg:px-8 py-3 lg:py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-full font-medium overflow-hidden transition-all duration-300 hover:shadow-2xl hover:scale-105"
                >
                  <span className="relative z-10 flex items-center gap-2">
                    <Download size={20} />
                    Download Resume
                  </span>
                  <div className="absolute inset-0 bg-gradient-to-r from-purple-600 to-blue-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </button>
                
                <button 
                  onClick={() => scrollToSection('#about')}
                  className="px-6 lg:px-8 py-3 lg:py-4 border-2 border-blue-600 text-blue-600 dark:text-blue-400 rounded-full font-medium hover:bg-blue-600 hover:text-white transition-all duration-300"
                >
                  About Me
                </button>
              </div>

              {/* Social Links */}
              <div className="flex gap-4 pt-4">
                {socialLinks.map((social, index) => {
                  const IconComponent = social.icon;
                  return (
                    <a
                      key={index}
                      href={social.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`w-10 h-10 lg:w-12 lg:h-12 ${social.color} rounded-full flex items-center justify-center text-white hover:scale-110 transition-all duration-300 hover:shadow-lg group`}
                    >
                      <IconComponent className="w-5 h-5 lg:w-6 lg:h-6 group-hover:rotate-12 transition-transform duration-300" />
                    </a>
                  );
                })}
              </div>
            </div>

            {/* Image - Right Side */}
            <div ref={imageRef} className="flex justify-center order-1 lg:order-2">
              <div className="relative group">
                {/* Background Circle - Responsive sizes */}
                <div className="absolut inset-0 w-64 h-64 sm:w-72 sm:h-72 md:w-80 md:h-80 lg:w-96 lg:h-96 bg-gradient-to-br from-yellow-400 via-orange-500 to-red-500 rounded-full flex items-center justify-center group-hover:scale-105 transition-transform duration-500">
                  {/* Character Image */}
                  <div className="w-52 h-52 sm:w-60 sm:h-60 md:w-64 md:h-64 lg:w-80 lg:h-80 rounded-full overflow-hidden bg-gradient-to-b from-blue-100 to-blue-200 flex items-end justify-center relative">
                    <img 
                      src="/lovable-uploads/49230fc5-8f59-4d4d-91bf-19f37572cf16.png"
                      alt="Akash Birhade"
                      className="w-full h-full object-cover object-top group-hover:scale-110 transition-transform duration-700"
                    />
                    
                    {/* Waving Hand Animation */}
                    <div className="absolute top-12 sm:top-14 md:top-16 right-6 sm:right-7 md:right-8 text-2xl sm:text-3xl md:text-4xl animate-bounce">
                      👋
                    </div>
                  </div>
                </div>
                
                {/* Floating Elements - Responsive positions */}
                <div className="absolute -top-2 sm:-top-3 md:-top-4 -left-2 sm:-left-3 md:-left-4 w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 bg-blue-500 rounded-full animate-pulse opacity-60" />
                <div className="absolute -bottom-4 sm:-bottom-5 md:-bottom-6 -right-4 sm:-right-5 md:-right-6 w-4 h-4 sm:w-5 sm:h-5 md:w-6 md:h-6 bg-purple-500 rounded-full animate-pulse opacity-60" />
                <div className="absolute top-1/4 -left-6 sm:-left-7 md:-left-8 w-3 h-3 sm:w-4 sm:h-4 bg-teal-500 rounded-full animate-pulse opacity-60" />
                <div className="absolute bottom-1/4 -right-6 sm:-right-7 md:-right-8 w-4 h-4 sm:w-5 sm:h-5 bg-pink-500 rounded-full animate-pulse opacity-60" />
              </div>
            </div>
          </div>

          {/* Skills Preview */}
          <div className="mt-12 lg:mt-16 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
            {[
              { icon: MapPin, label: "Location", value: "Mumbai, India" },
              { icon: Calendar, label: "Experience", value: "3+ Years" },
              { icon: Award, label: "Projects", value: "50+ Completed" },
              { icon: Coffee, label: "Coffee Cups", value: "1000+ Consumed" }
            ].map((item, index) => {
              const IconComponent = item.icon;
              return (
                <div key={index} className="group relative">
                  <div className="p-3 lg:p-4 bg-white/10 dark:bg-gray-800/10 backdrop-blur-md rounded-xl border border-white/20 dark:border-gray-700/20 hover:bg-white/20 dark:hover:bg-gray-800/20 transition-all duration-300 hover:scale-105">
                    <div className="flex items-center gap-2 lg:gap-3">
                      <div className="w-8 h-8 lg:w-10 lg:h-10 bg-gradient-to-br from-blue-500 to-purple-500 rounded-lg flex items-center justify-center group-hover:rotate-12 transition-transform duration-300">
                        <IconComponent className="w-4 h-4 lg:w-5 lg:h-5 text-white" />
                      </div>
                      <div>
                        <p className="text-xs text-gray-600 dark:text-gray-400">{item.label}</p>
                        <p className="font-semibold text-gray-900 dark:text-white text-sm">{item.value}</p>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Navigation Hint */}
          <div className="mt-8 lg:mt-12 text-center">
            <button 
              onClick={() => scrollToSection('#skills')}
              className="text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors duration-300"
            >
              <div className="flex flex-col items-center gap-2">
                <span className="text-sm">Scroll to explore more</span>
                <div className="w-1 h-8 bg-gradient-to-b from-blue-500 to-transparent rounded-full animate-pulse" />
              </div>
            </button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section 
        id="about" 
        ref={aboutRef}
        className="py-16 lg:py-20 px-4 max-w-7xl mx-auto"
      >
        <div className="text-center mb-12 lg:mb-16">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-4">
            About Me
          </h2>
          <div className="w-16 lg:w-20 h-1 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full mx-auto mb-6" />
          <p className="text-base lg:text-lg text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
            I'm a passionate web developer with over 3 years of experience creating modern, 
            responsive web applications. I love turning complex problems into simple, beautiful designs.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          <div className="bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 lg:p-8 shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-200/50 dark:border-gray-700/50">
            <h3 className="text-lg lg:text-xl font-bold text-gray-900 dark:text-white mb-4">Frontend Development</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Specialized in React, TypeScript, and modern CSS frameworks to create engaging user interfaces.
            </p>
          </div>
          
          <div className="bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 lg:p-8 shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-200/50 dark:border-gray-700/50">
            <h3 className="text-lg lg:text-xl font-bold text-gray-900 dark:text-white mb-4">Backend Integration</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Experience with Node.js, APIs, and databases to build full-stack applications.
            </p>
          </div>
          
          <div className="bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm rounded-xl p-6 lg:p-8 shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-200/50 dark:border-gray-700/50 md:col-span-2 lg:col-span-1">
            <h3 className="text-lg lg:text-xl font-bold text-gray-900 dark:text-white mb-4">UI/UX Design</h3>
            <p className="text-gray-600 dark:text-gray-400">
              Focus on user-centered design principles to create intuitive and accessible experiences.
            </p>
          </div>
        </div>
      </section>
    </>
  );
};

export default Hero;
