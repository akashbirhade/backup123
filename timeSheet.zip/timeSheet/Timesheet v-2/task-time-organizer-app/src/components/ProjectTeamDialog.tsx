
import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { User, UserToAdd } from "@/integrations/api/types";
import { usersApi } from "@/integrations/api/client";
import { useToast } from "@/hooks/use-toast";
import { X, PlusCircle } from "lucide-react";

interface ProjectTeamDialogProps {
  projectId: number;
  onClose: () => void;
}

const ProjectTeamDialog: React.FC<ProjectTeamDialogProps> = ({ projectId, onClose }) => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedUser, setSelectedUser] = useState<string>("");
  const [userRole, setUserRole] = useState<string>("member");
  const [hourlyRate, setHourlyRate] = useState<string>("50");
  
  const { toast } = useToast();
  
  // For the demo, we'll use static team members
  const [teamMembers, setTeamMembers] = useState<UserToAdd[]>([
    {
      id: 1,
      firstName: "Admin",
      lastName: "User",
      email: "admin@example.com",
      role: "manager",
      hourlyRate: 100
    },
    {
      id: 2,
      firstName: "Regular",
      lastName: "User",
      email: "user@example.com",
      role: "developer",
      hourlyRate: 50
    },
    {
      id: 3,
      firstName: "Project",
      lastName: "Manager",
      email: "manager@example.com",
      role: "manager",
      hourlyRate: 75
    },
  ]);
  
  useEffect(() => {
    fetchUsers();
  }, []);
  
  const fetchUsers = async () => {
    setLoading(true);
    try {
      const response = await usersApi.getUsers();
      if (response.success && response.data) {
        setUsers(response.data);
      } else {
        toast({
          title: "Error",
          description: response.error || "Failed to load users",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleAddUser = () => {
    if (!selectedUser) {
      toast({
        title: "Error",
        description: "Please select a user",
        variant: "destructive",
      });
      return;
    }
    
    const user = users.find(u => u.id.toString() === selectedUser);
    if (!user) return;
    
    // Check if user is already added
    if (teamMembers.some(member => member.id === user.id)) {
      toast({
        title: "Error",
        description: "User is already a team member",
        variant: "destructive",
      });
      return;
    }
    
    const newTeamMember: UserToAdd = {
      id: user.id,
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email,
      role: userRole,
      hourlyRate: parseFloat(hourlyRate)
    };
    
    setTeamMembers(prev => [...prev, newTeamMember]);
    
    toast({
      title: "Success",
      description: "Team member added successfully",
    });
    
    // Reset form
    setSelectedUser("");
  };
  
  const handleRemoveUser = (userId: number) => {
    setTeamMembers(prev => prev.filter(user => user.id !== userId));
    
    toast({
      title: "Success",
      description: "Team member removed successfully",
    });
  };
  
  const roleOptions = [
    { value: "manager", label: "Project Manager" },
    { value: "lead", label: "Team Lead" },
    { value: "developer", label: "Developer" },
    { value: "designer", label: "Designer" },
    { value: "qa", label: "QA Tester" },
    { value: "member", label: "Team Member" },
  ];
  
  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'manager':
        return 'bg-purple-500';
      case 'lead':
        return 'bg-blue-500';
      case 'developer':
        return 'bg-green-500';
      case 'designer':
        return 'bg-pink-500';
      case 'qa':
        return 'bg-amber-500';
      default:
        return 'bg-gray-500';
    }
  };
  
  const getRoleLabel = (role: string) => {
    const option = roleOptions.find(o => o.value === role);
    return option ? option.label : role;
  };
  
  return (
    <div className="space-y-6">
      <div className="border rounded-md p-4 bg-slate-50">
        <h3 className="font-medium mb-4">Add Team Member</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="md:col-span-2">
            <Label htmlFor="user">User</Label>
            <Select value={selectedUser} onValueChange={setSelectedUser}>
              <SelectTrigger id="user">
                <SelectValue placeholder="Select user" />
              </SelectTrigger>
              <SelectContent>
                {users.map((user) => (
                  <SelectItem key={user.id} value={user.id.toString()}>
                    {user.firstName} {user.lastName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="role">Role</Label>
            <Select value={userRole} onValueChange={setUserRole}>
              <SelectTrigger id="role">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {roleOptions.map((role) => (
                  <SelectItem key={role.value} value={role.value}>
                    {role.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="hourlyRate">Hourly Rate ($)</Label>
            <Input
              id="hourlyRate"
              type="number"
              value={hourlyRate}
              onChange={(e) => setHourlyRate(e.target.value)}
              min="0"
              step="5"
            />
          </div>
        </div>
        
        <Button 
          className="mt-4" 
          onClick={handleAddUser}
          disabled={!selectedUser}
        >
          <PlusCircle className="mr-2 h-4 w-4" />
          Add to Team
        </Button>
      </div>
      
      <div>
        <h3 className="font-medium mb-4">Current Team Members</h3>
        
        <div className="border rounded-md overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Hourly Rate</TableHead>
                <TableHead className="w-[100px]">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {teamMembers.map((member) => (
                <TableRow key={member.id}>
                  <TableCell className="font-medium">
                    {member.firstName} {member.lastName}
                  </TableCell>
                  <TableCell>{member.email}</TableCell>
                  <TableCell>
                    <Badge className={getRoleBadgeColor(member.role)}>
                      {getRoleLabel(member.role)}
                    </Badge>
                  </TableCell>
                  <TableCell>${member.hourlyRate}/hr</TableCell>
                  <TableCell>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => handleRemoveUser(member.id)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
              
              {teamMembers.length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-4">
                    No team members added yet
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>
      
      <div className="flex justify-end space-x-2 pt-4">
        <Button onClick={onClose}>
          Done
        </Button>
      </div>
    </div>
  );
};

export default ProjectTeamDialog;
