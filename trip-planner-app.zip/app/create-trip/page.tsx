"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { DatePickerWithRange } from "@/components/date-range-picker"
import { Loader2 } from "lucide-react"

export default function CreateTripPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    destination: "",
    dateRange: {
      from: undefined,
      to: undefined,
    },
    budget: 1000,
    tripType: "",
    preferences: "",
  })

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)

    // Simulate API call to generate trip plan
    setTimeout(() => {
      setLoading(false)
      // Store trip data in localStorage for demo purposes
      localStorage.setItem(
        "tripPlan",
        JSON.stringify({
          ...formData,
          id: Date.now().toString(),
        }),
      )
      router.push("/trip-plan")
    }, 2000)
  }

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-center mb-8">Create Your Trip Plan</h1>

      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>Trip Details</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="destination">Destination</Label>
              <Input
                id="destination"
                placeholder="City, Country or Region"
                value={formData.destination}
                onChange={(e) => handleInputChange("destination", e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label>Travel Dates</Label>
              <DatePickerWithRange date={formData.dateRange} setDate={(date) => handleInputChange("dateRange", date)} />
            </div>

            <div className="space-y-2">
              <div className="flex justify-between">
                <Label htmlFor="budget">Budget (USD)</Label>
                <span className="text-sm font-medium">${formData.budget}</span>
              </div>
              <Slider
                id="budget"
                min={100}
                max={10000}
                step={100}
                value={[formData.budget]}
                onValueChange={(value) => handleInputChange("budget", value[0])}
              />
              <div className="flex justify-between text-xs text-gray-500">
                <span>$100</span>
                <span>$10,000</span>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="tripType">Trip Type</Label>
              <Select value={formData.tripType} onValueChange={(value) => handleInputChange("tripType", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select trip type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="solo">Solo Adventure</SelectItem>
                  <SelectItem value="couple">Couple Getaway</SelectItem>
                  <SelectItem value="family">Family Vacation</SelectItem>
                  <SelectItem value="friends">Friends Trip</SelectItem>
                  <SelectItem value="business">Business Trip</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="preferences">Preferences & Interests</Label>
              <Textarea
                id="preferences"
                placeholder="Tell us what you enjoy (e.g., museums, hiking, local cuisine, shopping)"
                value={formData.preferences}
                onChange={(e) => handleInputChange("preferences", e.target.value)}
                rows={4}
              />
            </div>

            <Button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700" disabled={loading}>
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generating Trip Plan...
                </>
              ) : (
                "Generate Trip Plan"
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
