
const express = require('express');
const router = express.Router();
const ExcelJS = require('exceljs');
const { format } = require('date-fns');
const { auth, checkRole } = require('../middleware/auth');

// Apply auth middleware to all routes
router.use(auth);

// Get weekly report
router.post('/weekly', async (req, res) => {
  const { startDate, endDate, userId, projectId } = req.body;
  
  try {
    let query = `
      SELECT 
        te.id, te.entry_date, te.hours, te.description,
        u.first_name, u.last_name,
        p.name as project_name,
        c.name as client_name,
        t.name as task_name
      FROM time_entries te
      JOIN users u ON te.user_id = u.id
      JOIN projects p ON te.project_id = p.id
      JOIN clients c ON p.client_id = c.id
      LEFT JOIN tasks t ON te.task_id = t.id
      WHERE te.entry_date BETWEEN $1 AND $2
    `;
    
    let queryParams = [startDate, endDate];
    let paramIndex = 3;
    
    if (userId) {
      // Regular users can only get their own data
      if (req.user.role !== 'admin' && req.user.id !== parseInt(userId)) {
        return res.status(403).json({
          success: false,
          error: 'Access denied'
        });
      }
      query += ` AND te.user_id = $${paramIndex++}`;
      queryParams.push(userId);
    } else if (req.user.role !== 'admin') {
      // Non-admins can only see their own data
      query += ` AND te.user_id = $${paramIndex++}`;
      queryParams.push(req.user.id);
    }
    
    if (projectId) {
      query += ` AND te.project_id = $${paramIndex++}`;
      queryParams.push(projectId);
    }
    
    query += ` ORDER BY te.entry_date DESC, u.last_name, u.first_name`;
    
    const result = await req.db.query(query, queryParams);
    
    // Calculate totals
    const totalHours = result.rows.reduce((sum, row) => sum + parseFloat(row.hours), 0);
    
    res.status(200).json({
      success: true,
      data: {
        entries: result.rows.map(row => ({
          id: row.id,
          date: row.entry_date,
          hours: parseFloat(row.hours),
          description: row.description,
          userName: `${row.first_name} ${row.last_name}`,
          projectName: row.project_name,
          clientName: row.client_name,
          taskName: row.task_name || 'General'
        })),
        summary: {
          totalHours,
          startDate,
          endDate,
          entryCount: result.rows.length
        }
      }
    });
  } catch (error) {
    console.error('Error generating weekly report:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

// Export report as Excel
router.get('/:type/export', auth, async (req, res) => {
  const { type } = req.params;
  const { format, startDate, endDate, userId, projectId } = req.query;
  
  if (format !== 'excel') {
    return res.status(400).json({
      success: false,
      error: 'Only Excel format is supported'
    });
  }
  
  try {
    let query = `
      SELECT 
        te.id, te.entry_date, te.hours, te.description,
        u.first_name, u.last_name,
        p.name as project_name,
        c.name as client_name,
        t.name as task_name
      FROM time_entries te
      JOIN users u ON te.user_id = u.id
      JOIN projects p ON te.project_id = p.id
      JOIN clients c ON p.client_id = c.id
      LEFT JOIN tasks t ON te.task_id = t.id
      WHERE te.entry_date BETWEEN $1 AND $2
    `;
    
    let queryParams = [startDate, endDate];
    let paramIndex = 3;
    
    if (userId) {
      // Regular users can only get their own data
      if (req.user.role !== 'admin' && req.user.id !== parseInt(userId)) {
        return res.status(403).json({
          success: false,
          error: 'Access denied'
        });
      }
      query += ` AND te.user_id = $${paramIndex++}`;
      queryParams.push(userId);
    } else if (req.user.role !== 'admin') {
      // Non-admins can only see their own data
      query += ` AND te.user_id = $${paramIndex++}`;
      queryParams.push(req.user.id);
    }
    
    if (projectId) {
      query += ` AND te.project_id = $${paramIndex++}`;
      queryParams.push(projectId);
    }
    
    query += ` ORDER BY te.entry_date DESC, u.last_name, u.first_name`;
    
    const result = await req.db.query(query, queryParams);
    
    // Create a new Excel workbook
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Time Report');
    
    // Add title and date range
    worksheet.mergeCells('A1:G1');
    const titleCell = worksheet.getCell('A1');
    titleCell.value = `${type.toUpperCase()} TIME REPORT: ${startDate} to ${endDate}`;
    titleCell.font = { size: 16, bold: true };
    titleCell.alignment = { horizontal: 'center' };
    
    // Add headers
    worksheet.addRow([]);
    worksheet.addRow(['Date', 'Employee', 'Client', 'Project', 'Task', 'Hours', 'Description']);
    
    // Style header row
    const headerRow = worksheet.getRow(3);
    headerRow.font = { bold: true };
    headerRow.eachCell((cell) => {
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: 'FFD3D3D3' }
      };
      cell.border = {
        top: { style: 'thin' },
        bottom: { style: 'thin' },
        left: { style: 'thin' },
        right: { style: 'thin' }
      };
    });
    
    // Add data rows
    for (const entry of result.rows) {
      worksheet.addRow([
        format(new Date(entry.entry_date), 'yyyy-MM-dd'),
        `${entry.first_name} ${entry.last_name}`,
        entry.client_name,
        entry.project_name,
        entry.task_name || 'General',
        parseFloat(entry.hours),
        entry.description
      ]);
    }
    
    // Add total row
    const totalRow = worksheet.addRow([
      'Total Hours:',
      '',
      '',
      '',
      '',
      result.rows.reduce((sum, row) => sum + parseFloat(row.hours), 0),
      ''
    ]);
    totalRow.font = { bold: true };
    
    // Set columns width
    worksheet.columns = [
      { width: 12 }, // Date
      { width: 20 }, // Employee
      { width: 15 }, // Client
      { width: 20 }, // Project
      { width: 15 }, // Task
      { width: 10 }, // Hours
      { width: 40 }  // Description
    ];
    
    // Generate Excel file
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename=time_report_${format(new Date(), 'yyyy-MM-dd')}.xlsx`);
    
    await workbook.xlsx.write(res);
    res.end();
  } catch (error) {
    console.error('Error exporting report:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

module.exports = router;
