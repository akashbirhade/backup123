
import React from 'react';
import { CalendarContainer } from './calendar/CalendarContainer';

interface CalendarViewProps {
  initialExpanded?: boolean;
}

const CalendarView: React.FC<CalendarViewProps> = ({ initialExpanded = false }) => {
  return <CalendarContainer initialExpanded={initialExpanded} />;
};

export default CalendarView;
