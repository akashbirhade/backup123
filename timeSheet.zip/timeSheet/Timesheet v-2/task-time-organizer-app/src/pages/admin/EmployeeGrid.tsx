import React, { useEffect, useState } from 'react';
import { usersApi, reportsApi } from '@/integrations/api/client';
import { User, Report } from '@/integrations/api/types';
import TaskSpreadsheet from '@/components/TaskSpreadsheet';
import { useNavigate } from 'react-router-dom';

const EmployeeGrid: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [performance, setPerformance] = useState<Record<number, Report['summary']>>({});
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUsersAndPerformance = async () => {
      setLoading(true);
      const usersRes = await usersApi.getUsers();
      if (usersRes.success && usersRes.data) {
        setUsers(usersRes.data);
        // Fetch performance for each user (last 30 days)
        const endDate = new Date();
        const startDate = new Date();
        startDate.setDate(endDate.getDate() - 30);
        const perf: Record<number, Report['summary']> = {};
        await Promise.all(usersRes.data.map(async (user) => {
          const reportRes = await reportsApi.generateReport('weekly', {
            startDate: startDate.toISOString().slice(0, 10),
            endDate: endDate.toISOString().slice(0, 10),
            userId: user.id,
          });
          if (reportRes.success && reportRes.data) {
            perf[user.id] = reportRes.data.summary;
          }
        }));
        setPerformance(perf);
      }
      setLoading(false);
    };
    fetchUsersAndPerformance();
  }, []);

  if (loading) return <div>Loading employees...</div>;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Employees & Performance (Last 30 Days)</h1>
        <p className="text-muted-foreground">
          Employees & Performance (Last 30 Days)
        </p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {users.map(user => (
          <div
            key={user.id}
            className="bg-white rounded shadow p-4 border flex flex-col gap-2 cursor-pointer hover:bg-gray-50 transition"
            onClick={() => navigate(`/admin/employees/${user.id}`)}
          >
            <div className="font-medium">{user.firstName} {user.lastName}</div>
            <div className="text-sm text-gray-500">{user.email}</div>
            <div className="text-xs text-gray-400">Role: {user.role}</div>
            <div className="mt-2">
              <span className="font-semibold">Total Hours (30d): </span>
              {performance[user.id]?.totalHours ?? 'N/A'}
            </div>
            <div className="text-xs text-gray-400">Entries: {performance[user.id]?.entryCount ?? 'N/A'}</div>
          </div>
        ))}
      </div>
    
    </div>
  );
};

export default EmployeeGrid;
