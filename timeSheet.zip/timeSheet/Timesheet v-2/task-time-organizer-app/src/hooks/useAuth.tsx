
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { authApi } from '@/integrations/api/client';
import { User, LoginCredentials, RegisterData, AuthState } from '@/integrations/api/types';
import { useToast } from '@/hooks/use-toast';
import { useNavigate } from 'react-router-dom';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  login: (credentials: LoginCredentials) => Promise<boolean>;
  register: (data: RegisterData) => Promise<boolean>;
  logout: () => void;
  isLoading: boolean;
  token: string | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Initialize auth state from localStorage
const getInitialAuthState = (): AuthState => {
  try {
    const storedUser = localStorage.getItem('user');
    const storedToken = localStorage.getItem('token');
    
    if (storedUser && storedToken) {
      return {
        isAuthenticated: true,
        user: JSON.parse(storedUser),
        token: storedToken
      };
    }
  } catch (error) {
    console.error('Error parsing stored auth data:', error);
    // Clear potentially corrupted data
    localStorage.removeItem('user');
    localStorage.removeItem('token');
  }
  
  return {
    isAuthenticated: false,
    user: null,
    token: null
  };
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const initialState = getInitialAuthState();
  const [user, setUser] = useState<User | null>(initialState.user);
  const [token, setToken] = useState<string | null>(initialState.token);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(initialState.isAuthenticated);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    // Check if user is already logged in
    const { user, isAuthenticated } = authApi.getCurrentUser();
    if (isAuthenticated && user) {
      setUser(user);
      setIsAuthenticated(true);
      
      // Retrieve token from localStorage
      const storedToken = localStorage.getItem('token');
      if (storedToken) {
        setToken(storedToken);
      }
    }
    setIsLoading(false);
  }, []);

  const login = async (credentials: LoginCredentials): Promise<boolean> => {
    setIsLoading(true);
    try {
      const response = await authApi.login(credentials);
      
      if (response.success && response.data) {
        const { user, token } = response.data;
        setUser(user);
        setToken(token);
        setIsAuthenticated(true);
        
        // Store auth data in localStorage
        localStorage.setItem('user', JSON.stringify(user));
        localStorage.setItem('token', token);
        
        toast({
          title: "Login successful",
          description: `Welcome back, ${user.firstName}!`,
          variant: "default",
        });
        return true;
      } else {
        toast({
          title: "Login failed",
          description: response.error || "Invalid email or password",
          variant: "destructive",
        });
        return false;
      }
    } catch (error) {
      toast({
        title: "Login failed",
        description: "An unexpected error occurred",
        variant: "destructive",
      });
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (data: RegisterData): Promise<boolean> => {
    setIsLoading(true);
    try {
      const response = await authApi.register(data);
      
      if (response.success && response.data) {
        const { user, token } = response.data;
        setUser(user);
        setToken(token);
        setIsAuthenticated(true);
        
        // Store auth data in localStorage
        localStorage.setItem('user', JSON.stringify(user));
        localStorage.setItem('token', token);
        
        toast({
          title: "Registration successful",
          description: `Welcome, ${user.firstName}!`,
          variant: "default",
        });
        return true;
      } else {
        toast({
          title: "Registration failed",
          description: response.error || "Could not create account",
          variant: "destructive",
        });
        return false;
      }
    } catch (error) {
      toast({
        title: "Registration failed",
        description: "An unexpected error occurred",
        variant: "destructive",
      });
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    // Clear auth state
    setUser(null);
    setToken(null);
    setIsAuthenticated(false);
    
    // Clear localStorage
    localStorage.removeItem('user');
    localStorage.removeItem('token');
    
    // Use API to handle any server-side logout operations
    authApi.logout();
    
    toast({
      title: "Logged out",
      description: "You have been successfully logged out",
      variant: "default",
    });
    
    // Redirect to login page
    navigate('/login');
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated,
        isAdmin: user?.role === 'admin',
        login,
        register,
        logout,
        isLoading,
        token
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
