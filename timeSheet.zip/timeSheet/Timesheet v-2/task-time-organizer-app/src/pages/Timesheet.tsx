import React, { useState, useEffect } from 'react';
import { addDays, format, isSameDay, startOfWeek, endOfWeek } from 'date-fns';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import DateRangePicker from '@/components/DateRangePicker';
import TimeEntry from '@/components/TimeEntry';
import { Timesheet as TimesheetType, Project, Task, AbsenceDay } from '@/types/timesheet';
import { Plus, Save, Edit, Check, Calendar, Flag, Umbrella, Clock, AlarmClock, ChevronLeft, ChevronRight } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
} from "@/components/ui/dialog";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useEvents } from '@/hooks/useEvents';
import { timesheetsApi } from '@/integrations/api/client';
import { TimeEntry as ApiTimeEntry } from '@/integrations/api/types';
import { useAuth } from '@/hooks/useAuth';

// Dummy data for projects - this should be dynamic from your project management system
const dummyProjects = [
  { id: 'p1', name: 'Project Alpha', clientId: 'c1', clientName: 'Client A' },
  { id: 'p2', name: 'Project Beta', clientId: 'c2', clientName: 'Client B' },
  { id: 'p3', name: 'Project Gamma', clientId: 'c1', clientName: 'Client A' },
  { id: 'p4', name: 'Project Delta', clientId: 'c3', clientName: 'Client C' },
];

// Add 2 sample rows for task1 in the timesheet by default
const sampleTasks = [
  {
    id: 't1',
    projectId: 'p1',
    description: 'Sample Task 1',
    hours: Array(7).fill('5'),
  },
  {
    id: 't2',
    projectId: 'p1',
    description: 'Sample Task 2',
    hours: Array(7).fill('3'),
  },
];

// Enhanced database for storing timesheets with better structure
const mockTimesheetDB: { [key: string]: TimesheetType } = {};

// Helper function to check if a date is weekend or has events
interface CalendarEvent {
  date: string;
  isRecurring?: boolean;
  type: string;
  name: string;
  description?: string;
}

const getDateStatus = (date: Date, events: CalendarEvent[] = []) => {
  // Add null/undefined check
  if (!date || !(date instanceof Date) || isNaN(date.getTime())) {
    console.error('Invalid date passed to getDateStatus:', date);
    return null;
  }
  
  const dayOfWeek = date.getDay();
  const dateStr = format(date, 'yyyy-MM-dd');
  const currentYear = new Date().getFullYear();
  
  // Check if it's weekend (Saturday = 6, Sunday = 0)
  if (dayOfWeek === 0 || dayOfWeek === 6) {
    return {
      type: 'holiday',
      reason: dayOfWeek === 0 ? 'Sunday' : 'Saturday',
      isWeekend: true
    };
  }
  
  // Check for events/holidays
  const event = events.find(e => {
    const eventDate = new Date(e.date);
    
    // For recurring events, check if it matches this year
    if (e.isRecurring) {
      const recurringDate = new Date(currentYear, eventDate.getMonth(), eventDate.getDate());
      return format(recurringDate, 'yyyy-MM-dd') === dateStr;
    }
    
    // For non-recurring events, check exact date
    return e.date === dateStr;
  });
  
  if (event) {
    return {
      type: event.type,
      reason: event.name,
      description: event.description,
      isWeekend: false
    };
  }
  
  return null;
};

const generateTimesheetKey = (startDate: Date, endDate: Date) => {
  return `${format(startDate, 'yyyy-MM-dd')}_${format(endDate, 'yyyy-MM-dd')}`;
};

const createNewTimesheet = (startDate: Date, endDate: Date, user?: { firstName: string; lastName: string; id?: string|number }) : TimesheetType => {
  const timesheetKey = generateTimesheetKey(startDate, endDate);
  return {
    id: `ts_${timesheetKey}`,
    employeeId: user?.id ? String(user.id) : 'e1',
    employeeName: user ? `${user.firstName} ${user.lastName}` : 'New User',
    weekStarting: startDate,
    weekEnding: endDate,
    projects: [
      // {
      //   ...dummyProjects[0],
      //   tasks: [...sampleTasks],
      // },
    ],
    status: 'draft',
    totalHours: Array(7).fill(0),
    absenceDays: []
  };
};

const Timesheet = () => {
  const { user } = useAuth();
  const { events, getEventsForDateRange } = useEvents();
  const [startDate, setStartDate] = useState<Date>(() => {
    const today = new Date();
    return startOfWeek(today, { weekStartsOn: 1 }); // Start week on Monday
  });
  const [endDate, setEndDate] = useState<Date>(() => {
    const today = new Date();
    return endOfWeek(startOfWeek(today, { weekStartsOn: 1 }), { weekStartsOn: 1 });
  });
  const [days, setDays] = useState<Date[]>([]);
  const [timesheet, setTimesheet] = useState<TimesheetType | null>(null);
  const [selectedProject, setSelectedProject] = useState<string>('');
  const [newTaskDescription, setNewTaskDescription] = useState<string>('');
  const [editingTask, setEditingTask] = useState<string | null>(null);
  const [editedTaskDescription, setEditedTaskDescription] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  
  // Absence related states
  const [isAbsenceDialogOpen, setIsAbsenceDialogOpen] = useState<boolean>(false);
  const [selectedDay, setSelectedDay] = useState<Date | null>(null);
  const [absenceType, setAbsenceType] = useState<'leave' | 'half-day' | 'holiday'>('leave');
  const [absenceNote, setAbsenceNote] = useState<string>('');

  // Generate day headers
  useEffect(() => {
    if (startDate && endDate) {
      const daysList = [];
      let currentDay = new Date(startDate);
      while (currentDay <= endDate) {
        daysList.push(new Date(currentDay));
        currentDay = addDays(currentDay, 1);
      }
      setDays(daysList);
    }
  }, [startDate, endDate]);

  // Load or create timesheet when dates change
  useEffect(() => {
    if (startDate && endDate) {
      loadTimesheetForWeek(startDate, endDate);
    }
  }, [startDate, endDate]);

  // Auto-apply events to timesheet when events change
  useEffect(() => {
    if (timesheet && days.length > 0) {
      const weekEvents = getEventsForDateRange(startDate, endDate);
      applyEventsToTimesheet(weekEvents);
    }
  }, [events, timesheet, days, startDate, endDate]);

  const applyEventsToTimesheet = (weekEvents: CalendarEvent[]) => {
    if (!timesheet) return;

    const updatedTimesheet = { ...timesheet };
    let hasChanges = false;

    days.forEach((day, dayIndex) => {
      const dateStatus = getDateStatus(day, weekEvents);
      
      if (dateStatus && (dateStatus.type === 'holiday' || dateStatus.isWeekend)) {
        // Set all hours to 0 for holidays and weekends
        updatedTimesheet.projects.forEach(project => {
          project.tasks.forEach(task => {
            if (task.hours[dayIndex] !== '0') {
              task.hours[dayIndex] = '0';
              hasChanges = true;
            }
          });
        });
        updatedTimesheet.totalHours[dayIndex] = 0;
      } else if (dateStatus && dateStatus.type === 'half-day') {
        // Limit hours to maximum 4 for half-days
        let dayTotal = 0;
        updatedTimesheet.projects.forEach(project => {
          project.tasks.forEach(task => {
            const currentHours = parseFloat(task.hours[dayIndex] || '0');
            if (currentHours > 4) {
              task.hours[dayIndex] = '4';
              hasChanges = true;
            }
            dayTotal += parseFloat(task.hours[dayIndex] || '0');
          });
        });
        if (dayTotal > 4) {
          updatedTimesheet.totalHours[dayIndex] = 4;
          hasChanges = true;
        }
      }
    });

    if (hasChanges) {
      setTimesheet(updatedTimesheet);
      saveTimesheetToDatabase(updatedTimesheet);
    }
  };

  const navigateWeek = (direction: 'next' | 'previous') => {
    const daysToAdd = direction === 'next' ? 7 : -7;
    const newStartDate = addDays(startDate, daysToAdd);
    const newEndDate = addDays(endDate, daysToAdd);
    
    setStartDate(newStartDate);
    setEndDate(newEndDate);
  };

  const loadTimesheetForWeek = async (start: Date, end: Date) => {
    setIsLoading(true);
    
    try {
      const timesheetKey = generateTimesheetKey(start, end);
      
      // Check if timesheet exists in mock database
      const existingTimesheet = mockTimesheetDB[timesheetKey];
      
      if (existingTimesheet) {
        console.log('Loading existing timesheet for week:', timesheetKey);
        setTimesheet(existingTimesheet);
        toast.success('Timesheet loaded successfully!');
      } else {
        console.log('Creating new timesheet for week:', timesheetKey);
        const newTimesheet = createNewTimesheet(start, end, user);
        mockTimesheetDB[timesheetKey] = newTimesheet;
        setTimesheet(newTimesheet);
        toast.info('New timesheet created for this week.');
      }
    } catch (error) {
      console.error('Error loading timesheet:', error);
      toast.error('Failed to load timesheet');
    } finally {
      setIsLoading(false);
    }
  };

  function isNumericId(id: unknown): id is number {
    return typeof id === 'number' && !isNaN(id);
  }

  const saveTimesheetToDatabase = async (updatedTimesheet: TimesheetType) => {
    try {
      // Flatten all time entry data from the table
      const entries: ApiTimeEntry[] = [];
      const weekEvents = getEventsForDateRange(
        updatedTimesheet.weekStarting,
        updatedTimesheet.weekEnding
      );
      const days: Date[] = [];
      let currentDay = new Date(updatedTimesheet.weekStarting);
      while (currentDay <= updatedTimesheet.weekEnding) {
        days.push(new Date(currentDay));
        currentDay = addDays(currentDay, 1);
      }
      updatedTimesheet.projects.forEach(project => {
        project.tasks.forEach(task => {
          task.hours.forEach((hour, dayIdx) => {
            const dayDate = days[dayIdx];
            const dateStatus = getDateStatus(dayDate, weekEvents);
            const hoursNum = parseFloat(hour);
            // If it's a holiday (e.g., Sunday), add a holiday entry
            if (dateStatus && (dateStatus.type === 'holiday' || dateStatus.isWeekend)) {
              entries.push({
                id: 0,
                timesheetId: isNumericId(updatedTimesheet.id) ? updatedTimesheet.id : 0,
                projectId: project.id ? Number(project.id) : undefined,
                taskId: undefined,
                entryDate: dayDate.toISOString().slice(0, 10),
                hours: 0,
                description: dateStatus.reason || 'Holiday',
                projectName: project.name,
                taskName: dateStatus.reason || 'Holiday',
              });
            } else if (!isNaN(hoursNum) && hoursNum > 0) {
              entries.push({
                id: 0,
                timesheetId: isNumericId(updatedTimesheet.id) ? updatedTimesheet.id : 0,
                projectId: project.id ? Number(project.id) : undefined,
                taskId: undefined,
                entryDate: updatedTimesheet.weekStarting ?
                  new Date(updatedTimesheet.weekStarting.getTime() + dayIdx * 24 * 60 * 60 * 1000).toISOString().slice(0, 10) : '',
                hours: hoursNum,
                description: task.description,
                projectName: project.name,
                taskName: task.description
              });
            }
          });
        });
      });

      let response;
      const payload = {
        week_starting: updatedTimesheet.weekStarting.toISOString().slice(0, 10),
        week_ending: updatedTimesheet.weekEnding.toISOString().slice(0, 10),
        status: updatedTimesheet.status,
        entries: entries.map(entry => ({
          ...entry,
          projectId: entry.projectId ?? null, // ensure projectId is always present
        })),
      };
      if (isNumericId(updatedTimesheet.id)) {
        response = await timesheetsApi.updateTimesheet(updatedTimesheet.id, payload);
      } else {
        response = await timesheetsApi.createTimesheet(payload);
        // If timesheet already exists, update local state with returned ID and switch to update (PUT)
        if (response.message === 'A timesheet for this week already exists' && response.data?.id) {
          setTimesheet({ ...updatedTimesheet, id: response.data.id });
          await timesheetsApi.updateTimesheet(response.data.id, payload);
        } else if (response.success && response.data && response.data.id) {
          setTimesheet({ ...updatedTimesheet, id: response.data.id });
        }
      }
      if (!response.success) {
        toast.error('Failed to save timesheet: ' + response.error);
      }
    } catch (error) {
      toast.error('Error saving timesheet');
      console.error(error);
    }
  };

  const handleDateChange = (start: Date, end: Date) => {
    setStartDate(start);
    setEndDate(end);
  };

  const handleHoursChange = (value: string, dayIndex: number, taskId: string) => {
    if (!timesheet) return;

    const day = days[dayIndex];
    const weekEvents = getEventsForDateRange(startDate, endDate);
    const dateStatus = getDateStatus(day, weekEvents);
    
    // Prevent input on holidays and weekends
    if (dateStatus && (dateStatus.type === 'holiday' || dateStatus.isWeekend)) {
      toast.error(`Cannot log time on ${dateStatus.reason}`);
      return;
    }
    
    // Limit half-day hours
    if (dateStatus && dateStatus.type === 'half-day' && parseFloat(value) > 4) {
      toast.error('Half-day allows maximum 4 hours');
      value = '4';
    }

    const updatedTimesheet = { ...timesheet };
    const numValue = value === '' ? '0' : value;

    // Update the hours for the specific task
    updatedTimesheet.projects = updatedTimesheet.projects.map(project => {
      const updatedTasks = project.tasks.map(task => {
        if (task.id === taskId) {
          const updatedHours = [...task.hours];
          updatedHours[dayIndex] = value;
          return { ...task, hours: updatedHours };
        }
        return task;
      });
      return { ...project, tasks: updatedTasks };
    });

    // Recalculate total hours for each day
    const totalDays = updatedTimesheet.totalHours.length;
    const newTotalHours = Array(totalDays).fill(0);

    updatedTimesheet.projects.forEach(project => {
      project.tasks.forEach(task => {
        task.hours.forEach((hourStr, idx) => {
          const hours = hourStr === '' ? 0 : parseFloat(hourStr);
          if (!isNaN(hours)) {
            newTotalHours[idx] += hours;
          }
        });
      });
    });

    updatedTimesheet.totalHours = newTotalHours;
    setTimesheet(updatedTimesheet);
    saveTimesheetToDatabase(updatedTimesheet);
  };

  const handleAddTask = () => {
    if (!selectedProject || !newTaskDescription || !timesheet) return;

    const projectToUpdate = timesheet.projects.find(p => p.id === selectedProject);
    
    if (!projectToUpdate) {
      // Project doesn't exist in timesheet yet, add it
      const projectData = dummyProjects.find(p => p.id === selectedProject);
      if (!projectData) return;
      
      const newProject: Project = {
        ...projectData,
        tasks: [
          {
            id: `t${Date.now()}`,
            projectId: selectedProject,
            description: newTaskDescription,
            hours: Array(days.length).fill('0')
          }
        ]
      };
      
      const updatedTimesheet = {
        ...timesheet,
        projects: [...timesheet.projects, newProject]
      };
      
      setTimesheet(updatedTimesheet);
      saveTimesheetToDatabase(updatedTimesheet);
    } else {
      // Project exists, just add the task
      const newTask: Task = {
        id: `t${Date.now()}`,
        projectId: selectedProject,
        description: newTaskDescription,
        hours: Array(days.length).fill('0')
      };
      
      const updatedTimesheet = {
        ...timesheet,
        projects: timesheet.projects.map(project => {
          if (project.id === selectedProject) {
            return {
              ...project,
              tasks: [...project.tasks, newTask]
            };
          }
          return project;
        })
      };
      
      setTimesheet(updatedTimesheet);
      saveTimesheetToDatabase(updatedTimesheet);
    }
    
    // Reset form
    setNewTaskDescription('');
    toast.success('Task added successfully!');
  };

  const handleSubmitTimesheet = () => {
    if (!timesheet) return;
    
    const updatedTimesheet = {
      ...timesheet,
      status: 'submitted' as const
    };
    
    setTimesheet(updatedTimesheet);
    saveTimesheetToDatabase(updatedTimesheet);
    toast.success("Timesheet submitted successfully!");
  };

  const calculateWeeklyTotal = (taskHours: string[]) => {
    return taskHours.reduce((total, hours) => {
      return total + (hours === '' ? 0 : parseFloat(hours));
    }, 0);
  };

  const calculateTotalHours = () => {
    if (!timesheet) return 0;
    
    return timesheet.totalHours.reduce((sum, hours) => sum + hours, 0);
  };

  const handleEditDescription = (taskId: string, currentDescription: string) => {
    setEditingTask(taskId);
    setEditedTaskDescription(currentDescription);
  };

  const handleSaveDescription = (taskId: string) => {
    if (!timesheet) return;

    const updatedTimesheet = {
      ...timesheet,
      projects: timesheet.projects.map(project => ({
        ...project,
        tasks: project.tasks.map(task =>
          task.id === taskId
            ? { ...task, description: editedTaskDescription }
            : task
        ),
      })),
    };

    setTimesheet(updatedTimesheet);
    saveTimesheetToDatabase(updatedTimesheet);
    setEditingTask(null);
    toast.success("Task description updated!");
  };

  // New functions for absence management
  const openAbsenceDialog = (day: Date) => {
    // Add validation for day parameter
    if (!day || !(day instanceof Date) || isNaN(day.getTime())) {
      toast.error('Invalid date selected');
      return;
    }
    
    const weekEvents = getEventsForDateRange(startDate, endDate);
    const dateStatus = getDateStatus(day, weekEvents);
    
    // Don't allow absence recording on weekends or existing holidays
    if (dateStatus && (dateStatus.isWeekend || dateStatus.type === 'holiday')) {
      toast.error(`Cannot record absence on ${dateStatus.reason} - it's already marked as ${dateStatus.type}`);
      return;
    }
    
    setSelectedDay(day);
    
    // Check if there's already an absence for this day
    if (timesheet) {
      const existingAbsence = timesheet.absenceDays.find(absence => 
        isSameDay(new Date(absence.date), day)
      );
      
      if (existingAbsence) {
        setAbsenceType(existingAbsence.type);
        setAbsenceNote(existingAbsence.note || '');
      } else {
        setAbsenceType('leave');
        setAbsenceNote('');
      }
    }
    
    setIsAbsenceDialogOpen(true);
  };
  
  const handleAbsenceSubmit = () => {
    if (!timesheet || !selectedDay) return;
    
    const updatedTimesheet = { ...timesheet };
    
    // Remove any existing absence for this day
    const filteredAbsences = updatedTimesheet.absenceDays.filter(absence => 
      !isSameDay(new Date(absence.date), selectedDay)
    );
    
    // Add the new absence
    const newAbsence: AbsenceDay = {
      date: selectedDay,
      type: absenceType,
      note: absenceNote.trim() || undefined
    };
    
    updatedTimesheet.absenceDays = [...filteredAbsences, newAbsence];
    
    // For half day, allow 4 hours of work, for leave/holiday set all hours to 0
    const dayIndex = days.findIndex(day => isSameDay(day, selectedDay));
    
    if (dayIndex !== -1) {
      // Set all task hours for this day based on absence type
      updatedTimesheet.projects = updatedTimesheet.projects.map(project => ({
        ...project,
        tasks: project.tasks.map(task => {
          const updatedHours = [...task.hours];
          if (absenceType === 'half-day') {
            const currentHours = parseFloat(updatedHours[dayIndex] || '0');
            if (currentHours > 4) {
              updatedHours[dayIndex] = '4';
            }
          } else {
            updatedHours[dayIndex] = '0';
          }
          return { ...task, hours: updatedHours };
        })
      }));
      
      // Update total hours for the day
      const newTotalHours = [...updatedTimesheet.totalHours];
      if (absenceType === 'half-day') {
        newTotalHours[dayIndex] = Math.min(newTotalHours[dayIndex], 4);
      } else {
        newTotalHours[dayIndex] = 0;
      }
      updatedTimesheet.totalHours = newTotalHours;
    }
    
    setTimesheet(updatedTimesheet);
    saveTimesheetToDatabase(updatedTimesheet);
    setIsAbsenceDialogOpen(false);
    toast.success(`${absenceType === 'holiday' ? 'Holiday' : absenceType === 'half-day' ? 'Half-day' : 'Leave'} recorded successfully!`);
  };

  const getAbsenceForDay = (day: Date) => {
    // Add validation for day parameter
    if (!timesheet || !day || !(day instanceof Date) || isNaN(day.getTime())) {
      return null;
    }
    
    const weekEvents = getEventsForDateRange(startDate, endDate);
    
    // First check for system events/weekends
    const dateStatus = getDateStatus(day, weekEvents);
    if (dateStatus) {
      return {
        date: day,
        type: dateStatus.type as 'leave' | 'half-day' | 'holiday',
        note: dateStatus.reason,
        isSystemGenerated: true
      };
    }
    
    // Then check for user-recorded absences
    return timesheet.absenceDays.find(absence => isSameDay(new Date(absence.date), day));
  };

  const renderAbsenceIndicator = (day: Date) => {
    // Add validation for day parameter
    if (!day || !(day instanceof Date) || isNaN(day.getTime())) {
      return null;
    }
    
    const absence = getAbsenceForDay(day);
    if (!absence) return null;

    let icon;
    let colorClass;
    const tooltip = absence.note; 
    
    switch (absence.type) {
      case 'leave':
        icon = <Umbrella className="h-4 w-4" />; 
        colorClass = "bg-red-100 text-red-800";
        break;
      case 'half-day':
        icon = <AlarmClock className="h-4 w-4" />;
        colorClass = "bg-amber-100 text-amber-800";
        break;
      case 'holiday':
        icon = <Flag className="h-4 w-4" />;
        colorClass = absence.isSystemGenerated ? "bg-blue-100 text-blue-800" : "bg-red-100 text-red-800";
        break;
    }
    
    return (
      <div className={`absolute top-0 right-0 flex items-center p-1 rounded-full ${colorClass}`} title={tooltip}>
        {icon}
      </div>
    );
  };

  if (isLoading) {
    return <div className="flex justify-center items-center h-64">Loading timesheet...</div>;
  }

  if (!timesheet) {
    return <div className="flex justify-center items-center h-64">No timesheet found for this week.</div>;
  }

  const weekEvents = getEventsForDateRange(startDate, endDate);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight whitespace-nowrap">Weekly Timesheet</h1>
          <p className="text-muted-foreground">
            {timesheet.employeeName} - {format(startDate, "MMM d")} to {format(endDate, "MMM d, yyyy")}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigateWeek('previous')}
            disabled={isLoading}
          >
            <ChevronLeft className="h-4 w-4 mr-1" />
            Previous Week
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigateWeek('next')}
            disabled={isLoading}
          >
            Next Week
            <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
          <DateRangePicker onDateChange={handleDateChange} />
        </div>
      </div>

      <Card>
        <CardHeader className="bg-primary text-white">
          <CardTitle>Weekly Time Sheet</CardTitle>
        </CardHeader>

        <CardContent className="p-0 overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr>
                <th className="timesheet-header w-48 whitespace-nowrap">Client Name</th>
                <th className="timesheet-header w-48 whitespace-nowrap">Project Name</th>
                <th className="timesheet-header flex-1 whitespace-nowrap">JIRA Issue/Work Description</th>
                {days.map((day, i) => {
                  const dateStatus = getDateStatus(day, weekEvents);
                  return (
                    <th key={i} className="timesheet-header relative whitespace-nowrap">
                      <div className="flex justify-between items-center">
                        <div>
                          <div>{format(day, "dd-MM-yyyy")}</div>
                          <div className="flex items-center gap-1">
                            {format(day, "EEEE")}
                            {/* {dateStatus && (
                              <span className={`text-xs px-1 rounded ${
                                dateStatus.isWeekend ? 'bg-blue-200 text-blue-800' : 
                                dateStatus.type === 'holiday' ? 'bg-red-200 text-red-800' :
                                'bg-amber-200 text-amber-800'
                              }`}>
                                {dateStatus.type}
                              </span>
                            )} */}
                          </div>
                        </div>
                        {/* {timesheet.status === 'draft' && !dateStatus && (
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-7 w-7 p-0">
                                <Clock className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => openAbsenceDialog(day)}>
                                <Calendar className="mr-2 h-4 w-4" />
                                <span>Record Absence</span>
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        )} */}
                      </div>
                      {renderAbsenceIndicator(day)}
                    </th>
                  );
                })}
                <th className="timesheet-header">Weekly Totals</th>
              </tr>
            </thead>
            <tbody>
               <tr className="bg-gray-100">
                <td colSpan={3} className="p-2 border border-gray-300 text-right font-bold">
                  Status
                </td>
                {days.map((day, i) => {
                  const dateStatus = getDateStatus(day, weekEvents);
                  return (
                    <td key={i} className="time-cell font-bold border border-gray-300">
                      {dateStatus ? (
                        <span className={`text-xs px-1 rounded ${
                        dateStatus.isWeekend ? 'bg-blue-200 text-blue-800' :
                        dateStatus.type === 'holiday' ? 'bg-red-200 text-red-800' :
                        'bg-amber-200 text-amber-800'
                      }`}>
                        {dateStatus.type}
                      </span>
                      ) : (
                        <span className="text-xs text-gray-400">-</span>
                      )}
                       
                          {timesheet.status === 'draft' && !dateStatus && (
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-7 w-7 p-0">
                                <Clock className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => openAbsenceDialog(day)}>
                                <Calendar className="mr-2 h-4 w-4" />
                                <span>Record Absence</span>
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        )}
                    </td>
                  );
                })}
                <td className="time-cell font-bold border border-gray-300">
                  {calculateTotalHours()}
                </td>
              </tr>

              {timesheet.projects.map((project) => (
                <React.Fragment key={project.id}>
                  {project.tasks.map((task, taskIndex) => (
                    <tr key={task.id} className="timesheet-row task-row">
                      {taskIndex === 0 && (
                        <>
                          <td
                            className="p-2 border border-gray-300 align-top"
                            rowSpan={project.tasks.length}
                          >
                            {project.clientName}
                          </td>
                          <td
                            className="p-2 border border-gray-300 align-top"
                            rowSpan={project.tasks.length}
                          >
                            <div className="flex flex-col gap-2">
                              {/* <span>{project.name}</span> */}
                              {timesheet.status === 'draft' && (
                                <Select
                                  value={project.id}
                                  onValueChange={newProjectId => {
                                    // Update the project for all tasks in this group
                                    if (!timesheet) return;
                                    const updatedTimesheet = {
                                      ...timesheet,
                                      projects: timesheet.projects.map(p =>
                                        p.id === project.id
                                          ? {
                                              ...dummyProjects.find(dp => dp.id === newProjectId),
                                              tasks: p.tasks.map(t => ({ ...t, projectId: newProjectId })),
                                            }
                                          : p
                                      ),
                                    };
                                    setTimesheet(updatedTimesheet);
                                    saveTimesheetToDatabase(updatedTimesheet);
                                  }}
                                >
                                  <SelectTrigger className="w-full sm:w-[180px]">
                                    <SelectValue placeholder="Select Project" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {dummyProjects.map(dp => (
                                      <SelectItem key={dp.id} value={dp.id}>
                                        {dp.name}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              )}
                            </div>
                          </td>
                        </>
                      )}
                      <td className="p-2 border border-gray-300">
                        {editingTask === task.id ? (
                          <div className="flex items-center gap-2">
                            <Textarea
                              value={editedTaskDescription}
                              onChange={(e) => setEditedTaskDescription(e.target.value)}
                              className="min-h-[40px] text-sm resize-none p-1"
                              rows={2}
                            />
                            <Button 
                              size="sm" 
                              variant="ghost" 
                              onClick={() => handleSaveDescription(task.id)}
                              className="h-8 w-8 p-0"
                            >
                              <Check className="h-4 w-4" />
                            </Button>
                          </div>
                        ) : (
                          <div className="flex justify-between items-center group">
                            <span>{task.description}</span>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleEditDescription(task.id, task.description)}
                              className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                              disabled={timesheet.status !== 'draft'}
                            >
                              <Edit className="h-3 w-3" />
                            </Button>
                          </div>
                        )}
                      </td>
                      {task.hours.map((hour, dayIndex) => {
                        const dayAbsence = getAbsenceForDay(days[dayIndex]);
                        const dateStatus = getDateStatus(days[dayIndex], weekEvents);
                        const isDisabled = timesheet.status !== 'draft' || 
                          (dayAbsence?.type === 'leave' || dayAbsence?.type === 'holiday') ||
                          (dateStatus?.type === 'holiday') ||
                          (dateStatus?.isWeekend);
                        
                        let colorClass = '';
                        if (dayAbsence || dateStatus) {
                          const absenceType = dayAbsence?.type || dateStatus?.type;
                          if (absenceType === 'leave' || absenceType === 'holiday') {
                            colorClass = dateStatus?.isWeekend ? 'bg-blue-50' : 'bg-red-50';
                          } else if (absenceType === 'half-day') {
                            colorClass = 'bg-amber-50';
                          }
                        }
                        
                        return (
                          <td key={dayIndex} className={`time-cell ${colorClass}`}>
                            <TimeEntry
                              value={hour}
                              day={dayIndex}
                              taskId={task.id}
                              onChange={handleHoursChange}
                              disabled={isDisabled}
                              maxValue={dayAbsence?.type === 'half-day' ? 4 : undefined}
                            />
                          </td>
                        );
                      })}
                      <td className="time-cell font-semibold">
                        {calculateWeeklyTotal(task.hours)}
                      </td>
                    </tr>
                  ))}
                </React.Fragment>
              ))}

              <tr className="bg-gray-100">
                <td colSpan={3} className="p-2 border border-gray-300 text-right font-bold">
                  Total Daily Hours
                </td>
                {timesheet.totalHours.map((total, i) => {
                  const dayAbsence = getAbsenceForDay(days[i]);
                  const dateStatus = getDateStatus(days[i], weekEvents);
                  let bgClass = '';
                  let statusText = '';
                  
                  if (dayAbsence || dateStatus) {
                    const absenceType = dayAbsence?.type || dateStatus?.type;
                    const reason = dayAbsence?.note || dateStatus?.reason;
                    
                    if (absenceType === 'leave' || absenceType === 'holiday') {
                      bgClass = dateStatus?.isWeekend ? 'bg-blue-100' : 'bg-red-100';
                      statusText = reason || 'Holiday';
                    } else if (absenceType === 'half-day') {
                      bgClass = 'bg-amber-100';
                      statusText = 'Half-day';
                    }
                  }
                  
                  return (
                    <td key={i} className={`time-cell font-bold border border-gray-300 ${bgClass}`}>
                      {total}
                      {statusText && (
                         <div className="text-xs">
                          {statusText}
                        </div>
                      )}
                    </td>
                  );
                })}
                <td className="time-cell font-bold border border-gray-300">
                  {calculateTotalHours()}
                </td>
              </tr>
            </tbody>
          </table>
        </CardContent>
        
        <CardFooter className="flex flex-col md:flex-row gap-4 p-4 items-start">
          <div className="flex flex-1 flex-col sm:flex-row gap-2 w-full">
            <Select value={selectedProject} onValueChange={setSelectedProject}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <SelectValue placeholder="Select Project" />
              </SelectTrigger>
              <SelectContent>
                {dummyProjects.map(project => (
                  <SelectItem key={project.id} value={project.id}>
                    {project.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <div className="flex flex-1 gap-2">
              <Input
                placeholder="Task description"
                value={newTaskDescription}
                onChange={(e) => setNewTaskDescription(e.target.value)}
                className="flex-1"
              />
              <Button onClick={handleAddTask} disabled={!selectedProject || !newTaskDescription}>
                <Plus className="h-4 w-4 mr-1" /> Add Task
              </Button>
            </div>
          </div>
          
          <Button 
            variant="default" 
            onClick={handleSubmitTimesheet}
            disabled={timesheet.status !== 'draft' || calculateTotalHours() === 0}
          >
            <Save className="h-4 w-4 mr-1" /> Submit Timesheet
          </Button>
        </CardFooter>
      </Card>

      {/* Absence Dialog */}
      <Dialog open={isAbsenceDialogOpen} onOpenChange={setIsAbsenceDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Record Absence</DialogTitle>
            <DialogDescription>
              {selectedDay && `Record absence for ${format(selectedDay, "EEEE, MMMM d, yyyy")}`}
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <RadioGroup value={absenceType} onValueChange={(value) => setAbsenceType(value as 'leave' | 'half-day' | 'holiday')}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="leave" id="leave" />
                <Label htmlFor="leave" className="flex items-center">
                  <Umbrella className="h-4 w-4 mr-2" /> Full Day Leave
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="half-day" id="half-day" />
                <Label htmlFor="half-day" className="flex items-center">
                  <AlarmClock className="h-4 w-4 mr-2" /> Half Day
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="holiday" id="holiday" />
                <Label htmlFor="holiday" className="flex items-center">
                  <Flag className="h-4 w-4 mr-2" /> Holiday
                </Label>
              </div>
            </RadioGroup>
            
            <div className="mt-4">
              <Label htmlFor="note">Note (Optional)</Label>
              <Textarea
                id="note"
                value={absenceNote}
                onChange={(e) => setAbsenceNote(e.target.value)}
                placeholder="Add a note about this absence"
                className="mt-1"
              />
            </div>
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsAbsenceDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button onClick={handleAbsenceSubmit}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Timesheet;
