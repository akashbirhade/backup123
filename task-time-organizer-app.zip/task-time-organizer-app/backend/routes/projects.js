
const express = require('express');
const router = express.Router();
const { auth, checkRole } = require('../middleware/auth');

// Apply auth middleware to all routes
router.use(auth);

// Get all projects (based on user access)
router.get('/', async (req, res) => {
  try {
    let query;
    let queryParams = [];
    
    if (req.user.role === 'admin') {
      // Admins can see all projects
      query = `
        SELECT 
          p.*, 
          c.name as client_name,
          COALESCE(COUNT(DISTINCT pu.user_id), 0) as user_count,
          COALESCE(SUM(te.hours), 0) as total_hours
        FROM projects p
        JOIN clients c ON p.client_id = c.id
        LEFT JOIN project_users pu ON p.id = pu.project_id
        LEFT JOIN time_entries te ON p.id = te.project_id
        GROUP BY p.id, c.name
        ORDER BY p.name
      `;
    } else {
      // Regular users can only see assigned projects
      query = `
        SELECT 
          p.*, 
          c.name as client_name,
          COALESCE(COUNT(DISTINCT pu2.user_id), 0) as user_count,
          COALESCE(SUM(te.hours), 0) as total_hours
        FROM projects p
        JOIN clients c ON p.client_id = c.id
        JOIN project_users pu ON p.id = pu.project_id AND pu.user_id = $1
        LEFT JOIN project_users pu2 ON p.id = pu2.project_id
        LEFT JOIN time_entries te ON p.id = te.project_id
        GROUP BY p.id, c.name
        ORDER BY p.name
      `;
      queryParams.push(req.user.id);
    }
    
    const result = await req.db.query(query, queryParams);
    
    res.status(200).json({
      success: true,
      data: result.rows.map(project => ({
        id: project.id,
        name: project.name,
        clientId: project.client_id,
        clientName: project.client_name,
        description: project.description,
        startDate: project.start_date,
        endDate: project.end_date,
        status: project.status,
        userCount: parseInt(project.user_count),
        totalHours: parseFloat(project.total_hours)
      }))
    });
  } catch (error) {
    console.error('Error fetching projects:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

// Get a single project with tasks and team members
router.get('/:id', async (req, res) => {
  try {
    // Check if user has access to the project
    const accessQuery = req.user.role === 'admin'
      ? 'SELECT id FROM projects WHERE id = $1'
      : 'SELECT p.id FROM projects p JOIN project_users pu ON p.id = pu.project_id WHERE p.id = $1 AND pu.user_id = $2';
    
    const accessParams = req.user.role === 'admin'
      ? [req.params.id]
      : [req.params.id, req.user.id];
    
    const accessResult = await req.db.query(accessQuery, accessParams);
    
    if (accessResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'Project not found or access denied'
      });
    }
    
    // Get project details
    const projectQuery = `
      SELECT 
        p.*,
        c.name as client_name
      FROM projects p
      JOIN clients c ON p.client_id = c.id
      WHERE p.id = $1
    `;
    
    const projectResult = await req.db.query(projectQuery, [req.params.id]);
    
    if (projectResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'Project not found'
      });
    }
    
    const project = projectResult.rows[0];
    
    // Get tasks
    const tasksQuery = 'SELECT * FROM tasks WHERE project_id = $1 ORDER BY name';
    const tasksResult = await req.db.query(tasksQuery, [req.params.id]);
    
    // Get team members
    const teamQuery = `
      SELECT 
        u.id, u.first_name, u.last_name, u.email, 
        pu.role as project_role, pu.hourly_rate
      FROM users u
      JOIN project_users pu ON u.id = pu.user_id
      WHERE pu.project_id = $1
      ORDER BY u.last_name, u.first_name
    `;
    
    const teamResult = await req.db.query(teamQuery, [req.params.id]);
    
    // Get time entries summary
    const timeEntriesQuery = `
      SELECT 
        DATE_TRUNC('month', entry_date) as month,
        SUM(hours) as total_hours
      FROM time_entries
      WHERE project_id = $1
      GROUP BY DATE_TRUNC('month', entry_date)
      ORDER BY month DESC
    `;
    
    const timeEntriesResult = await req.db.query(timeEntriesQuery, [req.params.id]);
    
    res.status(200).json({
      success: true,
      data: {
        id: project.id,
        name: project.name,
        clientId: project.client_id,
        clientName: project.client_name,
        description: project.description,
        startDate: project.start_date,
        endDate: project.end_date,
        status: project.status,
        tasks: tasksResult.rows,
        team: teamResult.rows.map(member => ({
          id: member.id,
          firstName: member.first_name,
          lastName: member.last_name,
          email: member.email,
          role: member.project_role,
          hourlyRate: member.hourly_rate
        })),
        timeEntries: timeEntriesResult.rows.map(entry => ({
          month: entry.month,
          totalHours: parseFloat(entry.total_hours)
        }))
      }
    });
  } catch (error) {
    console.error('Error fetching project:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

// Create new project (admin only)
router.post('/', checkRole('admin'), async (req, res) => {
  const { name, clientId, description, startDate, endDate, status, tasks = [] } = req.body;
  
  try {
    // Start a transaction
    await req.db.query('BEGIN');
    
    // Create the project
    const projectResult = await req.db.query(
      `INSERT INTO projects 
        (name, client_id, description, start_date, end_date, status) 
       VALUES ($1, $2, $3, $4, $5, $6) 
       RETURNING id`,
      [name, clientId, description, startDate, endDate, status || 'active']
    );
    
    const projectId = projectResult.rows[0].id;
    
    // Add tasks if provided
    if (tasks && tasks.length > 0) {
      const taskValues = tasks.map(task => 
        `(${projectId}, '${task.name}', ${task.description ? `'${task.description}'` : 'NULL'})`
      ).join(', ');
      
      await req.db.query(
        `INSERT INTO tasks (project_id, name, description) VALUES ${taskValues}`
      );
    }
    
    // Add the creator as a project member with manager role
    await req.db.query(
      `INSERT INTO project_users (project_id, user_id, role)
       VALUES ($1, $2, $3)`,
      [projectId, req.user.id, 'manager']
    );
    
    await req.db.query('COMMIT');
    
    res.status(201).json({
      success: true,
      data: {
        id: projectId,
        name,
        clientId,
        description,
        startDate,
        endDate,
        status: status || 'active'
      }
    });
  } catch (error) {
    await req.db.query('ROLLBACK');
    console.error('Error creating project:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

// Update a project (admin only)
router.put('/:id', checkRole('admin'), async (req, res) => {
  const { name, clientId, description, startDate, endDate, status } = req.body;
  
  try {
    // Check if project exists
    const projectResult = await req.db.query(
      'SELECT id FROM projects WHERE id = $1',
      [req.params.id]
    );
    
    if (projectResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'Project not found'
      });
    }
    
    // Update project
    await req.db.query(
      `UPDATE projects 
       SET name = $1, client_id = $2, description = $3, 
           start_date = $4, end_date = $5, status = $6, updated_at = NOW()
       WHERE id = $7`,
      [name, clientId, description, startDate, endDate, status, req.params.id]
    );
    
    res.status(200).json({
      success: true,
      data: {
        id: parseInt(req.params.id),
        name,
        clientId,
        description,
        startDate,
        endDate,
        status
      }
    });
  } catch (error) {
    console.error('Error updating project:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

// Add task to project
router.post('/:id/tasks', checkRole('admin'), async (req, res) => {
  const { name, description } = req.body;
  
  try {
    // Check if project exists
    const projectResult = await req.db.query(
      'SELECT id FROM projects WHERE id = $1',
      [req.params.id]
    );
    
    if (projectResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'Project not found'
      });
    }
    
    // Add task
    const taskResult = await req.db.query(
      `INSERT INTO tasks (project_id, name, description)
       VALUES ($1, $2, $3)
       RETURNING id`,
      [req.params.id, name, description]
    );
    
    const taskId = taskResult.rows[0].id;
    
    res.status(201).json({
      success: true,
      data: {
        id: taskId,
        projectId: parseInt(req.params.id),
        name,
        description
      }
    });
  } catch (error) {
    console.error('Error adding task:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

// Add user to project
router.post('/:id/users', checkRole('admin'), async (req, res) => {
  const { userId, role, hourlyRate } = req.body;
  
  try {
    // Check if project exists
    const projectResult = await req.db.query(
      'SELECT id FROM projects WHERE id = $1',
      [req.params.id]
    );
    
    if (projectResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'Project not found'
      });
    }
    
    // Check if user exists
    const userResult = await req.db.query(
      'SELECT id, first_name, last_name FROM users WHERE id = $1',
      [userId]
    );
    
    if (userResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }
    
    // Check if user is already assigned to project
    const existingResult = await req.db.query(
      'SELECT id FROM project_users WHERE project_id = $1 AND user_id = $2',
      [req.params.id, userId]
    );
    
    if (existingResult.rows.length > 0) {
      return res.status(400).json({
        success: false,
        error: 'User is already assigned to this project'
      });
    }
    
    // Add user to project
    await req.db.query(
      `INSERT INTO project_users (project_id, user_id, role, hourly_rate)
       VALUES ($1, $2, $3, $4)`,
      [req.params.id, userId, role || 'member', hourlyRate]
    );
    
    res.status(201).json({
      success: true,
      data: {
        projectId: parseInt(req.params.id),
        userId,
        firstName: userResult.rows[0].first_name,
        lastName: userResult.rows[0].last_name,
        role: role || 'member',
        hourlyRate
      }
    });
  } catch (error) {
    console.error('Error adding user to project:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

// Remove user from project
router.delete('/:id/users/:userId', checkRole('admin'), async (req, res) => {
  try {
    // Check if project exists
    const projectResult = await req.db.query(
      'SELECT id FROM projects WHERE id = $1',
      [req.params.id]
    );
    
    if (projectResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'Project not found'
      });
    }
    
    // Remove user from project
    await req.db.query(
      'DELETE FROM project_users WHERE project_id = $1 AND user_id = $2',
      [req.params.id, req.params.userId]
    );
    
    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (error) {
    console.error('Error removing user from project:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

module.exports = router;
