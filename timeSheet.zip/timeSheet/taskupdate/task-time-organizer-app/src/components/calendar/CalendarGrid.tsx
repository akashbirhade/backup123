
import React from 'react';
import { Calendar } from "@/components/ui/calendar";
import { isWeekend } from "date-fns";
import { useCalendarStore } from "@/stores/calendarStore";
import { CalendarDay } from "./CalendarDay";

interface CalendarGridProps {
  monthsOffset: number[];
  onDayClick: (date: Date | undefined) => void;
  isMobile: boolean;
}

export const CalendarGrid = ({ 
  monthsOffset, 
  onDayClick, 
  isMobile 
}: CalendarGridProps) => {
  const { calendarEntries, companyHolidays } = useCalendarStore();

  // Define modifiers for the calendar
  const modifiers = {
    weekend: (date: Date) => isWeekend(date),
    holiday: (date: Date) => !!companyHolidays.find(holiday => 
      isWeekend(date) ? false : holiday.date.getDate() === date.getDate() && 
      holiday.date.getMonth() === date.getMonth()
    ),
    booked: (date: Date) => !!calendarEntries.find(entry => 
      entry.date.getDate() === date.getDate() && 
      entry.date.getMonth() === date.getMonth() && 
      entry.date.getFullYear() === date.getFullYear()
    ),
  };

  // Create modifier styles object
  const modifierStyles = {
    weekend: { fontWeight: 'bold' as const },
    holiday: { fontWeight: 'bold' as const },
    booked: { fontWeight: 'normal' as const }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
      {monthsOffset.map((offset) => {
        const month = new Date();
        month.setMonth(month.getMonth() - offset);
        return (
          <Calendar
            key={offset}
            mode="default"
            month={month}
            onDayClick={onDayClick}
            modifiers={modifiers}
            modifierStyles={modifierStyles}
            className="border rounded-md shadow-sm"
            classNames={{
              day: (date) => CalendarDay(date)
            }}
          />
        );
      })}
    </div>
  );
};
