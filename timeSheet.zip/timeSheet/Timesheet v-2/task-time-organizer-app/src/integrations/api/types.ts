// User types
export interface User {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  role: string;
  createdAt?: string;
}

export interface UserToAdd extends User {
  hourlyRate: number;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface LoginResponse {
  user: User;
  token: string;
}

export interface RegisterData {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  role: 'user' | 'admin';
}

export interface RegisterResponse {
  user: User;
  token: string;
}

export interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
  token: string | null;
}

// Project types
export interface Project {
  id: number;
  name: string;
  clientId: number;
  clientName: string;
  description?: string;
  startDate: string;
  endDate: string;
  status: string;
  userCount?: number;
  totalHours: number;
}

// Timesheet types
export interface Timesheet {
  id: number;
  userId: number;
  status: 'draft' | 'submitted' | 'approved' | 'rejected';
  week_starting: string;
  week_ending: string;
  totalHours: number;
  userName?: string;
  entries?: TimeEntry[];
}

export interface TimeEntry {
  id: number;
  timesheetId: number;
  projectId: number;
  taskId?: number;
  entryDate: string;
  hours: number;
  description: string;
  projectName?: string;
  taskName?: string;
}

// Report types
export interface Report {
  entries: ReportEntry[];
  summary: {
    totalHours: number;
    startDate: string;
    endDate: string;
    entryCount: number;
  };
}

export interface ReportEntry {
  id: number;
  date: string;
  hours: number;
  description: string;
  userName: string;
  projectName: string;
  clientName: string;
  taskName?: string;
}

// API Response type
export interface ApiResponse<T> {
  success: boolean;
  data: T | null;
  error: string | null;
}
