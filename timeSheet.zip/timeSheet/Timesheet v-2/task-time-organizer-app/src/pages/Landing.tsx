
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Clock, BarChart, Calendar, Users } from 'lucide-react';
import Logo from '@/components/Logo';

const Landing: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <Logo />
            <div className="flex space-x-4">
              <Button asChild variant="outline">
                <Link to="/login">Login</Link>
              </Button>
              <Button asChild>
                <Link to="/register">Get Started</Link>
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 sm:text-5xl md:text-6xl">
              Time Tracking Made Simple
            </h1>
            <p className="mt-3 max-w-md mx-auto text-base text-gray-500 sm:text-lg md:mt-5 md:text-xl md:max-w-3xl">
              Manage your projects, track time, and generate reports with our intuitive timesheet application.
            </p>
            <div className="mt-5 max-w-md mx-auto sm:flex sm:justify-center md:mt-8">
              <div className="rounded-md shadow">
                <Button asChild size="lg" className="w-full">
                  <Link to="/register">Start Free Trial</Link>
                </Button>
              </div>
              <div className="mt-3 rounded-md shadow sm:mt-0 sm:ml-3">
                <Button asChild variant="outline" size="lg" className="w-full">
                  <Link to="/login">Sign In</Link>
                </Button>
              </div>
            </div>
          </div>

          {/* Demo Accounts */}
          <div className="mt-16">
            <Card className="max-w-md mx-auto">
              <CardHeader>
                <CardTitle className="text-center">Try Demo Accounts</CardTitle>
                <CardDescription className="text-center">
                  Experience the full functionality with our demo accounts
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-3 bg-blue-50 rounded-lg">
                  <h4 className="font-medium text-blue-900">Admin Demo</h4>
                  <p className="text-sm text-blue-700">Email: admin@example.com</p>
                  <p className="text-sm text-blue-700">Password: admin123</p>
                </div>
                <div className="p-3 bg-green-50 rounded-lg">
                  <h4 className="font-medium text-green-900">User Demo</h4>
                  <p className="text-sm text-green-700">Email: user@example.com</p>
                  <p className="text-sm text-green-700">Password: user123</p>
                </div>
                <Button asChild className="w-full">
                  <Link to="/login">Try Demo</Link>
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Features */}
          <div className="mt-20">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                {
                  icon: Clock,
                  title: 'Time Tracking',
                  description: 'Track time spent on projects and tasks with precision.'
                },
                {
                  icon: BarChart,
                  title: 'Reports',
                  description: 'Generate detailed reports and export to Excel.'
                },
                {
                  icon: Calendar,
                  title: 'Calendar View',
                  description: 'Visualize your schedule and deadlines in calendar format.'
                },
                {
                  icon: Users,
                  title: 'Team Management',
                  description: 'Manage team members and project assignments.'
                }
              ].map((feature, index) => (
                <Card key={index} className="text-center">
                  <CardContent className="pt-6">
                    <feature.icon className="h-12 w-12 mx-auto text-primary mb-4" />
                    <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                    <p className="text-gray-600 text-sm">{feature.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Landing;
