"use client"

import { useEffect, useRef, useState } from "react"
import { MapPin } from "lucide-react"

export default function PropertyMap({ properties, convertPrice }) {
  const mapRef = useRef(null)
  const [selectedProperty, setSelectedProperty] = useState(null)
  const [mapLoaded, setMapLoaded] = useState(false)
  const [map, setMap] = useState(null)
  const [markers, setMarkers] = useState([])

  useEffect(() => {
    // Load Google Maps API script
    if (!mapLoaded) {
      // In a real app, we would load the actual Google Maps API
      // For this demo, we'll simulate Google Maps with a canvas
      setMapLoaded(true)
      initializeMap()
    } else if (map && properties.length > 0) {
      // Add markers for properties
      addPropertyMarkers()
    }
  }, [mapLoaded, properties, map])

  const initializeMap = () => {
    if (!mapRef.current) return

    // Simulate Google Maps initialization
    const canvas = mapRef.current
    const ctx = canvas.getContext("2d")
    const dpr = window.devicePixelRatio || 1

    // Set canvas dimensions accounting for device pixel ratio
    const rect = canvas.getBoundingClientRect()
    canvas.width = rect.width * dpr
    canvas.height = rect.height * dpr
    ctx.scale(dpr, dpr)

    // Draw map background (simulating Google Maps)
    ctx.fillStyle = "#e8f0f7" // Light blue background
    ctx.fillRect(0, 0, rect.width, rect.height)

    // Draw some map features
    drawMapFeatures(ctx, rect)

    setMap({ ctx, rect, dpr })
  }

  const drawMapFeatures = (ctx, rect) => {
    // Draw roads
    ctx.strokeStyle = "#ffffff"
    ctx.lineWidth = 3

    // Main roads
    for (let i = 0; i < 5; i++) {
      const y = ((i + 1) * rect.height) / 6
      ctx.beginPath()
      ctx.moveTo(0, y)
      ctx.lineTo(rect.width, y)
      ctx.stroke()
    }

    for (let i = 0; i < 5; i++) {
      const x = ((i + 1) * rect.width) / 6
      ctx.beginPath()
      ctx.moveTo(x, 0)
      ctx.lineTo(x, rect.height)
      ctx.stroke()
    }

    // Secondary roads
    ctx.strokeStyle = "#ffffff"
    ctx.lineWidth = 1

    for (let i = 0; i < 10; i++) {
      const y = ((i + 1) * rect.height) / 11
      ctx.beginPath()
      ctx.moveTo(0, y)
      ctx.lineTo(rect.width, y)
      ctx.stroke()
    }

    for (let i = 0; i < 10; i++) {
      const x = ((i + 1) * rect.width) / 11
      ctx.beginPath()
      ctx.moveTo(x, 0)
      ctx.lineTo(x, rect.height)
      ctx.stroke()
    }

    // Draw some "blocks"
    ctx.fillStyle = "#d9e6f2"
    for (let i = 0; i < 20; i++) {
      const x = Math.random() * rect.width
      const y = Math.random() * rect.height
      const width = 20 + Math.random() * 60
      const height = 20 + Math.random() * 60

      ctx.fillRect(x, y, width, height)
    }

    // Draw some "parks"
    ctx.fillStyle = "#c8e6c9"
    for (let i = 0; i < 5; i++) {
      const x = Math.random() * rect.width
      const y = Math.random() * rect.height
      const radius = 15 + Math.random() * 30

      ctx.beginPath()
      ctx.arc(x, y, radius, 0, Math.PI * 2)
      ctx.fill()
    }

    // Draw some "water"
    ctx.fillStyle = "#bbdefb"
    ctx.beginPath()
    ctx.arc(rect.width * 0.8, rect.height * 0.2, 50, 0, Math.PI * 2)
    ctx.fill()

    // Add Google Maps-like controls
    ctx.fillStyle = "#fff"
    ctx.strokeStyle = "#ddd"
    ctx.lineWidth = 1

    // Zoom controls
    ctx.fillRect(rect.width - 40, rect.height / 2 - 40, 30, 80)
    ctx.strokeRect(rect.width - 40, rect.height / 2 - 40, 30, 80)

    ctx.fillStyle = "#666"
    ctx.font = "bold 16px Arial"
    ctx.textAlign = "center"
    ctx.fillText("+", rect.width - 25, rect.height / 2 - 20)
    ctx.fillText("−", rect.width - 25, rect.height / 2 + 20)

    // Google logo
    ctx.fillStyle = "#fff"
    ctx.fillRect(10, rect.height - 30, 100, 20)

    ctx.fillStyle = "#4285F4"
    ctx.font = "bold 12px Arial"
    ctx.textAlign = "left"
    ctx.fillText("Google", 15, rect.height - 15)

    ctx.fillStyle = "#EA4335"
    ctx.fillText("Maps", 60, rect.height - 15)
  }

  const addPropertyMarkers = () => {
    if (!map || !properties.length) return

    const { ctx, rect, dpr } = map

    // Clear previous markers
    ctx.clearRect(0, 0, rect.width * dpr, rect.height * dpr)
    ctx.scale(dpr, dpr)

    // Redraw map
    drawMapFeatures(ctx, rect)

    // Normalize coordinates to fit canvas
    const points = properties.map((property) => ({
      x: (property.coordinates.x / 100) * (rect.width - 40) + 20,
      y: (property.coordinates.y / 100) * (rect.height - 40) + 20,
      property: property,
    }))

    // Store markers for click detection
    setMarkers(points)

    // Draw property markers
    points.forEach((point) => {
      // Draw marker pin
      ctx.fillStyle = point.property.featured ? "#10b981" : "#3b82f6"

      // Draw pin
      ctx.beginPath()
      ctx.arc(point.x, point.y - 8, 8, 0, Math.PI * 2)
      ctx.fill()

      // Draw pin pointer
      ctx.beginPath()
      ctx.moveTo(point.x - 5, point.y - 5)
      ctx.lineTo(point.x, point.y + 5)
      ctx.lineTo(point.x + 5, point.y - 5)
      ctx.fill()

      // Draw price label
      ctx.fillStyle = "#fff"
      ctx.font = "bold 10px Arial"
      ctx.textAlign = "center"
      ctx.fillText(convertPrice(point.property.price).substring(0, 4), point.x, point.y - 6)
    })

    // Add click event listener to show property info
    mapRef.current.onclick = (e) => {
      const rect = mapRef.current.getBoundingClientRect()
      const x = (e.clientX - rect.left) * dpr
      const y = (e.clientY - rect.top) * dpr

      // Check if click is on a property marker
      for (const point of points) {
        const dx = x - point.x * dpr
        const dy = y - (point.y - 8) * dpr // Adjust for pin height
        const distance = Math.sqrt(dx * dx + dy * dy)

        if (distance <= 10 * dpr) {
          setSelectedProperty(point.property)
          return
        }
      }

      // If click is not on a marker, clear selection
      setSelectedProperty(null)
    }
  }

  return (
    <div className="relative w-full h-full">
      <canvas ref={mapRef} className="w-full h-full rounded-md" style={{ width: "100%", height: "100%" }} />

      {selectedProperty && (
        <div className="absolute bottom-4 left-4 right-4 bg-white p-4 rounded-lg shadow-lg">
          <div className="flex">
            <div className="w-24 h-24 bg-gray-200 rounded-md overflow-hidden mr-4">
              <img
                src={selectedProperty.image || "/placeholder.svg"}
                alt={selectedProperty.title}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold">{selectedProperty.title}</h3>
              <p className="text-sm text-gray-600 flex items-center">
                <MapPin className="h-3 w-3 mr-1" />
                {selectedProperty.location}
              </p>
              <div className="flex items-center mt-1 text-xs">
                <span className="text-amber-500 mr-1">★</span>
                <span>{selectedProperty.rating}</span>
                <span className="text-gray-500 ml-1">({selectedProperty.reviews} reviews)</span>
              </div>
              <div className="mt-2 font-medium">
                {convertPrice(selectedProperty.price)} <span className="text-gray-500 text-sm">/ night</span>
              </div>
            </div>
          </div>
          <button
            className="absolute top-2 right-2 text-gray-500 hover:text-gray-700"
            onClick={() => setSelectedProperty(null)}
          >
            ✕
          </button>
        </div>
      )}

      <div className="absolute top-4 right-4 bg-white p-2 rounded-md shadow-sm text-xs">
        <div className="flex items-center mb-1">
          <div className="w-3 h-3 rounded-full bg-emerald-600 mr-1"></div>
          <span>Featured Property</span>
        </div>
        <div className="flex items-center">
          <div className="w-3 h-3 rounded-full bg-blue-500 mr-1"></div>
          <span>Regular Property</span>
        </div>
      </div>
    </div>
  )
}
