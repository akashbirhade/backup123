import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Clock, Calendar, BarChart, User } from "lucide-react";
import CalendarView from '@/components/CalendarView';
import { useAuth } from '@/hooks/useAuth';

const Dashboard = () => {
  const { user } = useAuth();
  const currentDate = new Date();
  const currentWeek = Math.ceil((currentDate.getDate()) / 7);
  const monthName = currentDate.toLocaleString('default', { month: 'long' });

  // Dummy data
  const weeklyHours = 32;
  const monthlyHours = 128;
  const targetHours = 40;
  const projectHours = [
    { name: "Project Alpha", hours: 12, color: "bg-blue-500" },
    { name: "Project Beta", hours: 8, color: "bg-green-500" },
    { name: "Project Gamma", hours: 10, color: "bg-purple-500" },
    { name: "Project Delta", hours: 2, color: "bg-yellow-500" },
  ];

  const recentTasks = [
    { project: "Project Alpha", task: "UI Design Implementation", date: "May 7, 2025", hours: 8 },
    { project: "Project Beta", task: "API Integration", date: "May 6, 2025", hours: 6 },
    { project: "Project Alpha", task: "Bug Fixes", date: "May 5, 2025", hours: 4 },
    { project: "Project Gamma", task: "Client Meeting", date: "May 4, 2025", hours: 2 },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">
            {user ? `Welcome back, ${user.firstName} ${user.lastName}. Here's your timesheet summary.` : "Welcome back. Here's your timesheet summary."}
          </p>
        </div>
        <div className="mt-4 md:mt-0 bg-white p-3 rounded-lg shadow-sm border">
          <p className="text-sm text-muted-foreground">{monthName} - Week {currentWeek}</p>
          <p className="text-2xl font-bold">{new Date().toLocaleDateString('en-US', { weekday: 'long', day: 'numeric' })}</p>
        </div>
      </div>

      <Tabs defaultValue="week" className="space-y-6">
        <TabsList>
          <TabsTrigger value="week">This Week</TabsTrigger>
          <TabsTrigger value="month">This Month</TabsTrigger>
        </TabsList>
        <TabsContent value="week" className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Hours Logged</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{weeklyHours} hrs</div>
                <p className="text-xs text-muted-foreground">
                  {weeklyHours < targetHours ? `${targetHours - weeklyHours} hours below` : `${weeklyHours - targetHours} hours above`} target
                </p>
                <Progress className="mt-2" value={(weeklyHours / targetHours) * 100} />
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Projects</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">4</div>
                <p className="text-xs text-muted-foreground">
                  Active projects this week
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Utilization</CardTitle>
                <BarChart className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {Math.round((weeklyHours / targetHours) * 100)}%
                </div>
                <p className="text-xs text-muted-foreground">
                  Weekly utilization rate
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Pending Approval</CardTitle>
                <User className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">1</div>
                <p className="text-xs text-muted-foreground">
                  Timesheet awaiting approval
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Weekly Project Distribution</CardTitle>
                <CardDescription>
                  Hours logged per project this week
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {projectHours.map((project) => (
                    <div key={project.name} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="font-medium">{project.name}</div>
                        <div className="text-sm text-muted-foreground">{project.hours} hrs</div>
                      </div>
                      <div className="h-2 w-full rounded-full bg-secondary">
                        <div
                          className={`h-full rounded-full ${project.color}`}
                          style={{ width: `${(project.hours / weeklyHours) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recent Tasks</CardTitle>
                <CardDescription>
                  Your most recent time entries
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentTasks.map((task, i) => (
                    <div key={i} className="flex items-center justify-between border-b pb-2 last:border-0">
                      <div>
                        <p className="font-medium">{task.task}</p>
                        <p className="text-sm text-muted-foreground">{task.project}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">{task.hours} hrs</p>
                        <p className="text-sm text-muted-foreground">{task.date}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Calendar View */}
          <CalendarView />
        </TabsContent>
        <TabsContent value="month" className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Monthly Hours</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{monthlyHours} hrs</div>
                <p className="text-xs text-muted-foreground">
                  Monthly target: 160 hours
                </p>
                <Progress className="mt-2" value={(monthlyHours / 160) * 100} />
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Projects</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">5</div>
                <p className="text-xs text-muted-foreground">
                  Active projects this month
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Utilization</CardTitle>
                <BarChart className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {Math.round((monthlyHours / 160) * 100)}%
                </div>
                <p className="text-xs text-muted-foreground">
                  Monthly utilization rate
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Completed</CardTitle>
                <User className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">3</div>
                <p className="text-xs text-muted-foreground">
                  Timesheets submitted this month
                </p>
              </CardContent>
            </Card>
          </div>
          
          {/* Calendar View also for month tab */}
          <CalendarView />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Dashboard;
