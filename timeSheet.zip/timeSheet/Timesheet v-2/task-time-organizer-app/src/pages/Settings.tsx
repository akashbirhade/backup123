
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from 'sonner';

const Settings = () => {
  const handleSaveNotifications = () => {
    toast.success("Notification settings saved!");
  };
  
  const handleSaveDisplay = () => {
    toast.success("Display settings saved!");
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
        <p className="text-muted-foreground">
          Manage your app preferences and settings
        </p>
      </div>
      
      <Tabs defaultValue="notifications">
        <div className="flex justify-center mb-6">
          <TabsList>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
            <TabsTrigger value="display">Display</TabsTrigger>
            <TabsTrigger value="admin">Admin Settings</TabsTrigger>
          </TabsList>
        </div>
        
        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Email Notifications</CardTitle>
              <CardDescription>
                Configure when you'll receive email notifications
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between space-x-2">
                <Label htmlFor="timesheet-approval">Timesheet Approvals</Label>
                <Switch id="timesheet-approval" defaultChecked />
              </div>
              <div className="flex items-center justify-between space-x-2">
                <Label htmlFor="deadline-reminder">Deadline Reminders</Label>
                <Switch id="deadline-reminder" defaultChecked />
              </div>
              <div className="flex items-center justify-between space-x-2">
                <Label htmlFor="project-updates">Project Updates</Label>
                <Switch id="project-updates" />
              </div>
              <div className="flex items-center justify-between space-x-2">
                <Label htmlFor="weekly-summary">Weekly Summaries</Label>
                <Switch id="weekly-summary" defaultChecked />
              </div>
              
              <Separator className="my-4" />
              
              <div className="flex justify-end">
                <Button onClick={handleSaveNotifications}>Save Changes</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="display" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Display Settings</CardTitle>
              <CardDescription>
                Customize how the application looks
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between space-x-2">
                <Label htmlFor="show-weekends">Show Weekends in Timesheet</Label>
                <Switch id="show-weekends" defaultChecked />
              </div>
              <div className="flex items-center justify-between space-x-2">
                <Label htmlFor="default-view">Default to Weekly View</Label>
                <Switch id="default-view" />
              </div>
              <div className="flex items-center justify-between space-x-2">
                <Label htmlFor="group-projects">Group by Projects</Label>
                <Switch id="group-projects" defaultChecked />
              </div>
              <div className="flex items-center justify-between space-x-2">
                <Label htmlFor="compact-mode">Compact Mode</Label>
                <Switch id="compact-mode" />
              </div>
              
              <Separator className="my-4" />
              
              <div className="flex justify-end">
                <Button onClick={handleSaveDisplay}>Save Changes</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="admin" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Administrator Settings</CardTitle>
              <CardDescription>
                These settings are only available to administrators
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 text-center p-8">
              <p className="text-muted-foreground">
                You don't have administrator privileges to access these settings.
              </p>
              <Button variant="outline">Request Access</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Settings;
