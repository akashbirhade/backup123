
import React, { useState, useEffect } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, FileDown, Users, Edit } from "lucide-react";
import { projectsApi } from "@/integrations/api/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Project } from "@/integrations/api/types";
import ProjectForm from "@/components/ProjectForm";
import ProjectTeamDialog from "@/components/ProjectTeamDialog";

const Projects = () => {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isTeamDialogOpen, setIsTeamDialogOpen] = useState(false);
  
  const { isAdmin } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    fetchProjects();
  }, []);

  const fetchProjects = async () => {
    setLoading(true);
    try {
      const response = await projectsApi.getProjects();
      if (response.success && response.data) {
        setProjects(response.data);
      } else {
        toast({
          title: "Error",
          description: response.error || "Failed to load projects",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleProjectCreate = async (projectData: Partial<Project>) => {
    try {
      const response = await projectsApi.createProject(projectData);
      
      if (response.success && response.data) {
        toast({
          title: "Success",
          description: "Project created successfully",
        });
        setIsFormOpen(false);
        fetchProjects();
      } else {
        toast({
          title: "Error",
          description: response.error || "Failed to create project",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An unexpected error occurred",
        variant: "destructive",
      });
    }
  };

  const handleProjectUpdate = async (projectData: Partial<Project>) => {
    if (!selectedProject) return;
    
    try {
      const response = await projectsApi.updateProject(selectedProject.id, projectData);
      
      if (response.success && response.data) {
        toast({
          title: "Success",
          description: "Project updated successfully",
        });
        setIsFormOpen(false);
        fetchProjects();
      } else {
        toast({
          title: "Error",
          description: response.error || "Failed to update project",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An unexpected error occurred",
        variant: "destructive",
      });
    }
  };

  const renderStatus = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-500">Active</Badge>;
      case 'completed':
        return <Badge variant="secondary">Completed</Badge>;
      case 'upcoming':
        return <Badge className="bg-blue-500">Upcoming</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Projects</h1>
          <p className="text-muted-foreground">
            Overview of all projects and their hour allocations
          </p>
        </div>
        
        {isAdmin && (
          <Button onClick={() => {
            setSelectedProject(null);
            setIsFormOpen(true);
          }}>
            <Plus className="mr-2 h-4 w-4" /> Add Project
          </Button>
        )}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Projects</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Project Name</TableHead>
                  <TableHead>Client</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Start Date</TableHead>
                  <TableHead>End Date</TableHead>
                  <TableHead className="text-right">Hours Budget</TableHead>
                  <TableHead className="text-right">Hours Used</TableHead>
                  <TableHead className="text-right">Remaining</TableHead>
                  {isAdmin && <TableHead className="text-right">Actions</TableHead>}
                </TableRow>
              </TableHeader>
              <TableBody>
                {projects.map((project) => {
                  // For demo purposes, we'll estimate budget based on totalHours
                  const budget = Math.round(project.totalHours * 1.33);
                  const remaining = budget - project.totalHours;
                  const percentUsed = project.totalHours > 0 ? ((project.totalHours / budget) * 100).toFixed(1) : "0.0";
                  
                  return (
                    <TableRow key={project.id}>
                      <TableCell className="font-medium">{project.name}</TableCell>
                      <TableCell>{project.clientName}</TableCell>
                      <TableCell>{renderStatus(project.status)}</TableCell>
                      <TableCell>{project.startDate}</TableCell>
                      <TableCell>{project.endDate}</TableCell>
                      <TableCell className="text-right">{budget} hrs</TableCell>
                      <TableCell className="text-right">{project.totalHours} hrs ({percentUsed}%)</TableCell>
                      <TableCell className={`text-right font-medium ${
                        remaining < 0 ? 'text-red-600' : 
                        remaining < budget * 0.2 ? 'text-amber-600' : 
                        'text-green-600'
                      }`}>
                        {remaining} hrs
                      </TableCell>
                      
                      {isAdmin && (
                        <TableCell className="text-right">
                          <div className="flex justify-end space-x-2">
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => {
                                setSelectedProject(project);
                                setIsTeamDialogOpen(true);
                              }}
                            >
                              <Users className="h-4 w-4" />
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => {
                                setSelectedProject(project);
                                setIsFormOpen(true);
                              }}
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      )}
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
      
      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>
              {selectedProject ? `Edit Project: ${selectedProject.name}` : "Create New Project"}
            </DialogTitle>
          </DialogHeader>
          <ProjectForm 
            project={selectedProject} 
            onSubmit={selectedProject ? handleProjectUpdate : handleProjectCreate}
            onCancel={() => setIsFormOpen(false)}
          />
        </DialogContent>
      </Dialog>
      
      <Dialog open={isTeamDialogOpen} onOpenChange={setIsTeamDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>
              {selectedProject ? `Manage Team: ${selectedProject.name}` : "Project Team"}
            </DialogTitle>
          </DialogHeader>
          {selectedProject && (
            <ProjectTeamDialog 
              projectId={selectedProject.id}
              onClose={() => setIsTeamDialogOpen(false)}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Projects;
