
import React, { useState } from 'react';
import { Calendar } from "@/components/ui/calendar";
import { format, isSameDay } from "date-fns";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown, ChevronUp, CalendarDays } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";

interface CalendarEntry {
  date: Date;
  status: 'complete' | 'partial' | 'missing';
  hours: number;
  tasks: { project: string; description: string; hours: number }[];
}

interface CalendarViewProps {
  initialExpanded?: boolean;
}

// Demo data for calendar entries
const getDummyEntries = (): CalendarEntry[] => {
  const today = new Date();
  const entries: CalendarEntry[] = [];
  
  // Generate entries for the past 60 days
  for (let i = 0; i < 60; i++) {
    const date = new Date();
    date.setDate(today.getDate() - i);
    
    // Random status
    const statusOptions = ['complete', 'partial', 'missing'] as const;
    const status = statusOptions[Math.floor(Math.random() * 3)];
    
    // Generate hours based on status
    const hours = status === 'complete' ? 8 : status === 'partial' ? Math.floor(Math.random() * 7) + 1 : 0;
    
    // Generate tasks
    const numTasks = status === 'missing' ? 0 : Math.floor(Math.random() * 3) + 1;
    const tasks = [];
    const projects = ['Project Alpha', 'Project Beta', 'Project Gamma', 'Project Delta'];
    
    for (let j = 0; j < numTasks; j++) {
      tasks.push({
        project: projects[Math.floor(Math.random() * projects.length)],
        description: `Task ${j + 1} for ${format(date, 'MMM dd')}`,
        hours: Math.floor(Math.random() * 4) + 1
      });
    }
    
    entries.push({
      date,
      status,
      hours,
      tasks
    });
  }
  
  return entries;
};

const CalendarView: React.FC<CalendarViewProps> = ({ initialExpanded = false }) => {
  const [selectedMonth, setSelectedMonth] = useState<Date>(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isExpanded, setIsExpanded] = useState(initialExpanded);
  const isMobile = useIsMobile();
  
  const calendarEntries = getDummyEntries();
  
  const handleDayClick = (date: Date | undefined) => {
    if (date) {
      setSelectedDate(date);
      setIsDialogOpen(true);
    }
  };

  const getEntryForDate = (date: Date) => {
    return calendarEntries.find(entry => isSameDay(entry.date, date));
  };

  const getDayClassNames = (date: Date) => {
    const entry = getEntryForDate(date);
    
    if (!entry) return "";
    
    switch (entry.status) {
      case 'complete':
        return "bg-green-100 text-green-800 hover:bg-green-200";
      case 'partial':
        return "bg-amber-100 text-amber-800 hover:bg-amber-200";
      case 'missing':
        return "bg-red-100 text-red-800 hover:bg-red-200";
      default:
        return "";
    }
  };

  // Define modifiers for the calendar
  const modifiers = {
    booked: (date: Date) => !!getEntryForDate(date),
  };

  // Correct implementation for modifiers styles
  const modifiersStyles = {
    booked: (date: Date) => {
      const className = getDayClassNames(date);
      return { color: '', backgroundColor: '' }; // Return empty styles, we'll use className
    }
  };

  return (
    <>
      <Collapsible 
        open={isExpanded} 
        onOpenChange={setIsExpanded}
        className="w-full"
      >
        <Card className="mt-6">
          <CardHeader className="pb-3 flex flex-row justify-between items-center">
            <CardTitle className="text-xl flex items-center gap-2">
              <CalendarDays className="h-5 w-5" />
              Timesheet Calendar
            </CardTitle>
            <CollapsibleTrigger className="hover:bg-gray-100 rounded-full p-2">
              {isExpanded ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
            </CollapsibleTrigger>
          </CardHeader>
          
          <CollapsibleContent>
            <CardContent>
              <div className="text-sm mb-3">
                <Badge className="mr-2 bg-green-500">Complete</Badge>
                <Badge className="mr-2 bg-amber-400">Partial</Badge>
                <Badge className="bg-red-500">Missing</Badge>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                {[0, 1, 2].map((offset) => {
                  const month = new Date();
                  month.setMonth(month.getMonth() - offset);
                  return (
                    <Calendar
                      key={offset}
                      mode="default"
                      month={month}
                      onDayClick={handleDayClick}
                      modifiers={modifiers}
                      styles={{
                        ...Object.entries(modifiers).reduce((acc, [name, fn]) => {
                          acc[`day_${name}`] = { fontWeight: 'normal' };
                          return acc;
                        }, {} as Record<string, React.CSSProperties>)
                      }}
                      // modifiersClassNames={{
                      //   booked: (date) => getDayClassNames(date)
                      // }}
                      className="border rounded-md shadow-sm"
                    />
                  
                  );
                })}
              </div>
              
              {isMobile ? null : (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[3, 4, 5].map((offset) => {
                    const month = new Date();
                    month.setMonth(month.getMonth() - offset);
                    return (
                      <Calendar
                        key={offset}
                        mode="default"
                        month={month}
                        onDayClick={handleDayClick}
                        modifiers={modifiers}
                        styles={{
                          // Removed invalid property 'day_today'
                          ...Object.entries(modifiers).reduce((acc, [name, fn]) => {
                            acc[`day_${name}`] = { fontWeight: 'normal' };
                            return acc;
                          }, {} as Record<string, React.CSSProperties>)
                        }}
                        // modifiersClassNames={{
                        //   booked: getDayClassNames
                        // }}
                        className="border rounded-md shadow-sm"
                      />
                    );
                  })}
                </div>
              )}
            </CardContent>
          </CollapsibleContent>
        </Card>
      </Collapsible>

      {selectedDate && (
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle className="text-xl font-bold">
                {format(selectedDate, 'EEEE, MMMM d, yyyy')}
              </DialogTitle>
            </DialogHeader>
            
            <div className="py-4">
              {(() => {
                const entry = getEntryForDate(selectedDate);
                
                if (!entry) {
                  return <p>No timesheet data available for this date.</p>;
                }
                
                return (
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-semibold">Status</p>
                        <Badge 
                          className={
                            entry.status === 'complete' ? "bg-green-500" : 
                            entry.status === 'partial' ? "bg-amber-400" : 
                            "bg-red-500"
                          }
                        >
                          {entry.status.charAt(0).toUpperCase() + entry.status.slice(1)}
                        </Badge>
                      </div>
                      <div>
                        <p className="font-semibold">Total Hours</p>
                        <p className="text-xl font-bold">{entry.hours}</p>
                      </div>
                    </div>
                    
                    {entry.tasks.length > 0 ? (
                      <div>
                        <p className="font-semibold mb-2">Tasks</p>
                        {entry.tasks.map((task, i) => (
                          <div key={i} className="border-b pb-2 mb-2 last:border-0">
                            <div className="flex justify-between">
                              <p className="font-medium">{task.description}</p>
                              <p>{task.hours} hrs</p>
                            </div>
                            <p className="text-sm text-gray-500">{task.project}</p>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p>No tasks logged for this day.</p>
                    )}
                  </div>
                );
              })()}
            </div>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
};

export default CalendarView;
