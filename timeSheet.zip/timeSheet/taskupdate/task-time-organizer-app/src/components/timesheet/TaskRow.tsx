
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Check, Edit } from 'lucide-react';
import { toast } from 'sonner';
import TimeEntry from '@/components/TimeEntry';
import { Task, AbsenceDay } from '@/types/timesheet';

interface TaskRowProps {
  task: Task;
  isFirstTaskInProject: boolean;
  clientName: string;
  projectName: string;
  days: Date[];
  absenceDays: AbsenceDay[];
  readOnly: boolean;
  onHoursChange: (value: string, dayIndex: number, taskId: string) => void;
  onDescriptionChange: (taskId: string, description: string) => void;
}

const TaskRow: React.FC<TaskRowProps> = ({
  task,
  isFirstTaskInProject,
  clientName,
  projectName,
  days,
  absenceDays,
  readOnly,
  onHoursChange,
  onDescriptionChange
}) => {
  const [editingDescription, setEditingDescription] = useState<boolean>(false);
  const [editedDescription, setEditedDescription] = useState<string>(task.description);

  const handleEditDescription = () => {
    setEditingDescription(true);
    setEditedDescription(task.description);
  };

  const handleSaveDescription = () => {
    onDescriptionChange(task.id, editedDescription);
    setEditingDescription(false);
    toast.success("Task description updated!");
  };

  const getAbsenceForDay = (day: Date) => {
    return absenceDays.find(absence => 
      new Date(absence.date).getDate() === day.getDate() &&
      new Date(absence.date).getMonth() === day.getMonth() &&
      new Date(absence.date).getFullYear() === day.getFullYear()
    );
  };

  const calculateWeeklyTotal = (hours: string[]) => {
    return hours.reduce((total, hourStr) => {
      return total + (hourStr === '' ? 0 : parseFloat(hourStr));
    }, 0);
  };

  return (
    <tr className="timesheet-row task-row">
      {isFirstTaskInProject && (
        <>
          <td
            className="p-2 border border-gray-300 align-top"
            rowSpan={1} // This will be adjusted by the parent component
          >
            {clientName}
          </td>
          <td
            className="p-2 border border-gray-300 align-top"
            rowSpan={1} // This will be adjusted by the parent component
          >
            {projectName}
          </td>
        </>
      )}
      <td className="p-2 border border-gray-300">
        {editingDescription ? (
          <div className="flex items-center gap-2">
            <Textarea
              value={editedDescription}
              onChange={(e) => setEditedDescription(e.target.value)}
              className="min-h-[40px] text-sm resize-none p-1"
              rows={2}
            />
            <Button 
              size="sm" 
              variant="ghost" 
              onClick={handleSaveDescription}
              className="h-8 w-8 p-0"
            >
              <Check className="h-4 w-4" />
            </Button>
          </div>
        ) : (
          <div className="flex justify-between items-center group">
            <span>{task.description}</span>
            {!readOnly && (
              <Button
                size="sm"
                variant="ghost"
                onClick={handleEditDescription}
                className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <Edit className="h-3 w-3" />
              </Button>
            )}
          </div>
        )}
      </td>
      {task.hours.map((hour, dayIndex) => {
        const dayAbsence = getAbsenceForDay(days[dayIndex]);
        const isDisabled = readOnly || 
          (dayAbsence?.type === 'leave' || dayAbsence?.type === 'holiday');
        
        let colorClass = '';
        if (dayAbsence) {
          if (dayAbsence.type === 'leave' || dayAbsence.type === 'holiday') {
            colorClass = 'bg-red-50';
          } else if (dayAbsence.type === 'half-day') {
            colorClass = 'bg-amber-50';
          }
        }
        
        return (
          <td key={dayIndex} className={`time-cell ${colorClass}`}>
            <TimeEntry
              value={hour}
              day={dayIndex}
              taskId={task.id}
              onChange={onHoursChange}
              disabled={isDisabled}
              maxValue={dayAbsence?.type === 'half-day' ? 4 : undefined}
            />
          </td>
        );
      })}
      <td className="time-cell font-semibold">
        {calculateWeeklyTotal(task.hours)}
      </td>
    </tr>
  );
};

export default TaskRow;
