
// import React, { useState } from 'react';
// import { Calendar } from '@/components/ui/calendar';
// import {
//   Card,
//   CardContent,
//   CardDescription,
//   CardHeader,
//   CardTitle,
// } from '@/components/ui/card';
// import { format } from 'date-fns';

// type CalendarEvent = {
//   id: string;
//   date: Date;
//   title: string;
//   type: 'meeting' | 'deadline' | 'reminder';
// };

// const CalendarView: React.FC = () => {
//   const [date, setDate] = useState<Date | undefined>(new Date());
  
//   // Sample calendar events
//   const events: CalendarEvent[] = [
//     {
//       id: '1',
//       date: new Date(2025, 4, 15),
//       title: 'Team Meeting',
//       type: 'meeting',
//     },
//     {
//       id: '2',
//       date: new Date(2025, 4, 20),
//       title: 'Project Deadline',
//       type: 'deadline',
//     },
//     {
//       id: '3',
//       date: new Date(2025, 4, 22),
//       title: 'Client Call',
//       type: 'meeting',
//     },
//     {
//       id: '4',
//       date: new Date(2025, 4, 28),
//       title: 'Report Due',
//       type: 'reminder',
//     },
//   ];

//   // Filter events for the selected date
//   const selectedDateEvents = events.filter(
//     (event) => date && event.date.toDateString() === date.toDateString()
//   );

//   // Function to get event indicator classes for a date
//   const getDateClass = (day: Date) => {
//     const dayEvents = events.filter(
//       (event) => event.date.toDateString() === day.toDateString()
//     );
    
//     if (dayEvents.length === 0) return {};
    
//     // Just return class names as a string
//     let classNames = 'relative';
    
//     if (dayEvents.some(e => e.type === 'meeting')) {
//       classNames += ' after:absolute after:bottom-1 after:left-1/2 after:-translate-x-1/2 after:h-1 after:w-1 after:rounded-full after:bg-blue-500';
//     }
//     if (dayEvents.some(e => e.type === 'deadline')) {
//       classNames += ' before:absolute before:top-1 before:right-1 before:h-1 before:w-1 before:rounded-full before:bg-red-500';
//     }
//     if (dayEvents.some(e => e.type === 'reminder')) {
//       classNames += ' after:absolute after:top-1 after:left-1 after:h-1 after:w-1 after:rounded-full after:bg-yellow-500';
//     }
    
//     return { className: classNames };
//   };

//   // Function to format date for display
//   const formatDate = (date: Date | undefined): string => {
//     return date ? format(date, 'MMMM d, yyyy') : '';
//   };

//   return (
//     <div className="flex flex-col md:flex-row gap-6 w-full">
//       <div className="w-full md:w-1/2">
//         <Card>
//           <CardHeader>
//             <CardTitle>Calendar</CardTitle>
//             <CardDescription>
//               View and manage your schedule
//             </CardDescription>
//           </CardHeader>
//           <CardContent>
//             <Calendar
//               mode="single"
//               selected={date}
//               onSelect={setDate}
//               modifiers={{
//                 booked: events.map(event => event.date),
//               }}
//               modifiersClassNames={{
//                 booked: 'font-bold text-primary',
//               }}
//               modifiersStyles={{
//                 booked: { fontWeight: 'bold' },
//               }}
//               // The following is fixed to match the type
//               styles={{
//                 day: (date) => getDateClass(date),
//                 caption: { className: 'font-medium text-lg' },
//                 head_cell: { className: 'text-muted-foreground font-normal text-sm' },
//               }}
//             />
//           </CardContent>
//         </Card>
//       </div>

//       <div className="w-full md:w-1/2">
//         <Card>
//           <CardHeader>
//             <CardTitle>
//               {formatDate(date)}
//             </CardTitle>
//             <CardDescription>
//               Events for the selected date
//             </CardDescription>
//           </CardHeader>
//           <CardContent>
//             {selectedDateEvents.length > 0 ? (
//               <div className="space-y-3">
//                 {selectedDateEvents.map((event) => (
//                   <div
//                     key={event.id}
//                     className="flex items-center p-3 border rounded-lg"
//                   >
//                     <div
//                       className={`h-3 w-3 rounded-full mr-3 ${
//                         event.type === 'meeting'
//                           ? 'bg-blue-500'
//                           : event.type === 'deadline'
//                           ? 'bg-red-500'
//                           : 'bg-yellow-500'
//                       }`}
//                     ></div>
//                     <div>
//                       <p className="font-medium">{event.title}</p>
//                       <p className="text-sm text-muted-foreground capitalize">
//                         {event.type}
//                       </p>
//                     </div>
//                   </div>
//                 ))}
//               </div>
//             ) : (
//               <p className="text-center text-muted-foreground">
//                 No events for this date
//               </p>
//             )}
//           </CardContent>
//         </Card>
//       </div>
//     </div>
//   );
// };

// export default CalendarView;


import React, { useState } from 'react';
import { Calendar } from "@/components/ui/calendar";
import { format, isSameDay } from "date-fns";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { ChevronDown, ChevronUp, CalendarDays } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";

interface CalendarEntry {
  date: Date;
  status: 'complete' | 'partial' | 'missing';
  hours: number;
  tasks: { project: string; description: string; hours: number }[];
}

interface CalendarViewProps {
  initialExpanded?: boolean;
}

// Demo data for calendar entries
const getDummyEntries = (): CalendarEntry[] => {
  const today = new Date();
  const entries: CalendarEntry[] = [];
  
  // Generate entries for the past 60 days
  for (let i = 0; i < 60; i++) {
    const date = new Date();
    date.setDate(today.getDate() - i);
    
    // Random status
    const statusOptions = ['complete', 'partial', 'missing'] as const;
    const status = statusOptions[Math.floor(Math.random() * 3)];
    
    // Generate hours based on status
    const hours = status === 'complete' ? 8 : status === 'partial' ? Math.floor(Math.random() * 7) + 1 : 0;
    
    // Generate tasks
    const numTasks = status === 'missing' ? 0 : Math.floor(Math.random() * 3) + 1;
    const tasks = [];
    const projects = ['Project Alpha', 'Project Beta', 'Project Gamma', 'Project Delta'];
    
    for (let j = 0; j < numTasks; j++) {
      tasks.push({
        project: projects[Math.floor(Math.random() * projects.length)],
        description: `Task ${j + 1} for ${format(date, 'MMM dd')}`,
        hours: Math.floor(Math.random() * 4) + 1
      });
    }
    
    entries.push({
      date,
      status,
      hours,
      tasks
    });
  }
  
  return entries;
};

const CalendarView: React.FC<CalendarViewProps> = ({ initialExpanded = false }) => {
  const [selectedMonth, setSelectedMonth] = useState<Date>(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isExpanded, setIsExpanded] = useState(initialExpanded);
  const isMobile = useIsMobile();
  
  const calendarEntries = getDummyEntries();
  
  const handleDayClick = (date: Date | undefined) => {
    if (date) {
      setSelectedDate(date);
      setIsDialogOpen(true);
    }
  };

  const getEntryForDate = (date: Date) => {
    return calendarEntries.find(entry => isSameDay(entry.date, date));
  };

  const getDayClassNames = (date: Date) => {
    const entry = getEntryForDate(date);
    
    if (!entry) return "";
    
    switch (entry.status) {
      case 'complete':
        return "bg-green-100 text-green-800 hover:bg-green-200";
      case 'partial':
        return "bg-amber-100 text-amber-800 hover:bg-amber-200";
      case 'missing':
        return "bg-red-100 text-red-800 hover:bg-red-200";
      default:
        return "";
    }
  };

  // Define modifiers for the calendar
  const modifiers = {
    booked: (date: Date) => !!getEntryForDate(date),
  };

  // Correct implementation for modifiers styles
  const modifiersStyles = {
    booked: (date: Date) => {
      const className = getDayClassNames(date);
      return { color: '', backgroundColor: '' }; // Return empty styles, we'll use className
    }
  };

  return (
    <>
      <Collapsible 
        open={isExpanded} 
        onOpenChange={setIsExpanded}
        className="w-full"
      >
        <Card className="mt-6">
          <CardHeader className="pb-3 flex flex-row justify-between items-center">
            <CardTitle className="text-xl flex items-center gap-2">
              <CalendarDays className="h-5 w-5" />
              Timesheet Calendar
            </CardTitle>
            <CollapsibleTrigger className="hover:bg-gray-100 rounded-full p-2">
              {isExpanded ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
            </CollapsibleTrigger>
          </CardHeader>
          
          <CollapsibleContent>
            <CardContent>
              <div className="text-sm mb-3">
                <Badge className="mr-2 bg-green-500">Complete</Badge>
                <Badge className="mr-2 bg-amber-400">Partial</Badge>
                <Badge className="bg-red-500">Missing</Badge>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                {[0, 1, 2].map((offset) => {
                  const month = new Date();
                  month.setMonth(month.getMonth() - offset);
                  return (
                    <Calendar
                      key={offset}
                      mode="default"
                      month={month}
                      onDayClick={handleDayClick}
                      modifiers={modifiers}
                      styles={{
                        ...Object.entries(modifiers).reduce((acc, [name, fn]) => {
                          acc[`day_${name}`] = { fontWeight: 'normal' };
                          return acc;
                        }, {} as Record<string, any>)
                      }}
                      // modifiersClassNames={{
                      //   booked: (date) => getDayClassNames(date)
                      // }}
                      className="border rounded-md shadow-sm"
                    />
                  
                  );
                })}
              </div>
              
              {isMobile ? null : (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[3, 4, 5].map((offset) => {
                    const month = new Date();
                    month.setMonth(month.getMonth() - offset);
                    return (
                      <Calendar
                        key={offset}
                        mode="default"
                        month={month}
                        onDayClick={handleDayClick}
                        modifiers={modifiers}
                        styles={{
                          // Removed invalid property 'day_today'
                          ...Object.entries(modifiers).reduce((acc, [name, fn]) => {
                            acc[`day_${name}`] = { fontWeight: 'normal' };
                            return acc;
                          }, {} as Record<string, any>)
                        }}
                        // modifiersClassNames={{
                        //   booked: getDayClassNames
                        // }}
                        className="border rounded-md shadow-sm"
                      />
                    );
                  })}
                </div>
              )}
            </CardContent>
          </CollapsibleContent>
        </Card>
      </Collapsible>

      {selectedDate && (
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle className="text-xl font-bold">
                {format(selectedDate, 'EEEE, MMMM d, yyyy')}
              </DialogTitle>
            </DialogHeader>
            
            <div className="py-4">
              {(() => {
                const entry = getEntryForDate(selectedDate);
                
                if (!entry) {
                  return <p>No timesheet data available for this date.</p>;
                }
                
                return (
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-semibold">Status</p>
                        <Badge 
                          className={
                            entry.status === 'complete' ? "bg-green-500" : 
                            entry.status === 'partial' ? "bg-amber-400" : 
                            "bg-red-500"
                          }
                        >
                          {entry.status.charAt(0).toUpperCase() + entry.status.slice(1)}
                        </Badge>
                      </div>
                      <div>
                        <p className="font-semibold">Total Hours</p>
                        <p className="text-xl font-bold">{entry.hours}</p>
                      </div>
                    </div>
                    
                    {entry.tasks.length > 0 ? (
                      <div>
                        <p className="font-semibold mb-2">Tasks</p>
                        {entry.tasks.map((task, i) => (
                          <div key={i} className="border-b pb-2 mb-2 last:border-0">
                            <div className="flex justify-between">
                              <p className="font-medium">{task.description}</p>
                              <p>{task.hours} hrs</p>
                            </div>
                            <p className="text-sm text-gray-500">{task.project}</p>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p>No tasks logged for this day.</p>
                    )}
                  </div>
                );
              })()}
            </div>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
};

export default CalendarView;
