
export interface Timesheet {
  id: string;
  employeeId: string;
  employeeName: string;
  weekStarting: Date;
  weekEnding: Date;
  projects: Project[];
  status: 'draft' | 'submitted' | 'approved';
  totalHours: number[];
  absenceDays: AbsenceDay[];
}

export interface Project {
  id: string;
  name: string;
  clientId: string;
  clientName: string;
  tasks: Task[];
}

export interface Task {
  id: string;
  projectId: string;
  description: string;
  hours: string[];
}

export interface AbsenceDay {
  date: Date;
  type: 'leave' | 'half-day' | 'holiday';
  note?: string;
  isSystemGenerated?: boolean;
}
