"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import {
  MapPin,
  Calendar,
  DollarSign,
  Users,
  Clock,
  Sparkles,
  Loader2,
  Sun,
  Cloud,
  Umbrella,
  AlertTriangle,
  Map,
  CalendarClock,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"
import { format, addDays } from "date-fns"

export default function TripPlannerPage() {
  const router = useRouter()
  const [destination, setDestination] = useState("")
  const [startDate, setStartDate] = useState<Date | undefined>(undefined)
  const [endDate, setEndDate] = useState<Date | undefined>(undefined)
  const [budget, setBudget] = useState([500])
  const [travelers, setTravelers] = useState("2")
  const [interests, setInterests] = useState("")
  const [loading, setLoading] = useState(false)
  const [plan, setPlan] = useState<TripPlan | null>(null)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    // Simulate AI processing
    setTimeout(() => {
      setPlan(generateMockTripPlan(destination, startDate, endDate, budget[0], Number.parseInt(travelers)))
      setLoading(false)
    }, 3000)
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-2 text-center">AI Trip Planner</h1>
      <p className="text-gray-600 text-center mb-8">
        Let our AI assistant create a personalized travel itinerary for you
      </p>

      {!plan ? (
        <Card className="max-w-2xl mx-auto">
          <CardHeader>
            <CardTitle>Plan Your Trip</CardTitle>
            <CardDescription>Fill in the details below and our AI will create a custom itinerary</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-medium">Destination</label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <Input
                    placeholder="Where do you want to go?"
                    className="pl-10"
                    value={destination}
                    onChange={(e) => setDestination(e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Start Date</label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-full justify-start text-left font-normal">
                        <Calendar className="mr-2 h-4 w-4" />
                        {startDate ? format(startDate, "PPP") : "Select date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <CalendarComponent
                        mode="single"
                        selected={startDate}
                        onSelect={setStartDate}
                        initialFocus
                        disabled={(date) => date < new Date()}
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">End Date</label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-full justify-start text-left font-normal">
                        <Calendar className="mr-2 h-4 w-4" />
                        {endDate ? format(endDate, "PPP") : "Select date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <CalendarComponent
                        mode="single"
                        selected={endDate}
                        onSelect={setEndDate}
                        initialFocus
                        disabled={(date) => !startDate || date <= startDate}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Budget (per person)</label>
                <div className="flex items-center">
                  <DollarSign className="h-5 w-5 text-gray-400 mr-2" />
                  <Slider defaultValue={[500]} max={5000} step={100} value={budget} onValueChange={setBudget} />
                  <span className="ml-4 min-w-[60px] text-right">${budget[0]}</span>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Number of Travelers</label>
                <div className="relative">
                  <Users className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <Select value={travelers} onValueChange={setTravelers}>
                    <SelectTrigger className="pl-10">
                      <SelectValue placeholder="Select number of travelers" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1">1 traveler</SelectItem>
                      <SelectItem value="2">2 travelers</SelectItem>
                      <SelectItem value="3">3 travelers</SelectItem>
                      <SelectItem value="4">4 travelers</SelectItem>
                      <SelectItem value="5+">5+ travelers</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Interests & Preferences</label>
                <Textarea
                  placeholder="Tell us what you enjoy (e.g., museums, outdoor activities, local cuisine, etc.)"
                  value={interests}
                  onChange={(e) => setInterests(e.target.value)}
                  className="min-h-[100px]"
                />
              </div>
            </form>
          </CardContent>
          <CardFooter>
            <Button
              onClick={handleSubmit}
              className="w-full bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600"
              disabled={loading || !destination || !startDate || !endDate}
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generating your plan...
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-4 w-4" />
                  Generate AI Trip Plan
                </>
              )}
            </Button>
          </CardFooter>
        </Card>
      ) : (
        <div className="max-w-5xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">Your Trip to {plan.destination}</h2>
            <Button variant="outline" onClick={() => setPlan(null)}>
              Create New Plan
            </Button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Tabs defaultValue="itinerary">
                <TabsList className="mb-6">
                  <TabsTrigger value="itinerary">Itinerary</TabsTrigger>
                  <TabsTrigger value="accommodations">Accommodations</TabsTrigger>
                  <TabsTrigger value="dining">Dining</TabsTrigger>
                  <TabsTrigger value="map">Map</TabsTrigger>
                </TabsList>

                <TabsContent value="itinerary" className="space-y-6">
                  {plan.days.map((day, index) => (
                    <Card key={index}>
                      <CardHeader className="pb-2">
                        <CardTitle>
                          Day {index + 1}: {day.title}
                        </CardTitle>
                        <CardDescription>
                          {day.date && format(new Date(day.date), "EEEE, MMMM d, yyyy")}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          {day.activities.map((activity, actIndex) => (
                            <div key={actIndex} className="flex">
                              <div className="mr-4 flex flex-col items-center">
                                <div className="h-8 w-8 rounded-full bg-teal-100 text-teal-600 flex items-center justify-center">
                                  <Clock className="h-4 w-4" />
                                </div>
                                {actIndex < day.activities.length - 1 && (
                                  <div className="w-0.5 h-full bg-gray-200 mt-2" />
                                )}
                              </div>
                              <div className="flex-1">
                                <h4 className="font-medium">
                                  {activity.time} - {activity.title}
                                </h4>
                                <p className="text-gray-600 text-sm mt-1">{activity.description}</p>
                                {activity.cost && (
                                  <Badge variant="outline" className="mt-2">
                                    <DollarSign className="h-3 w-3 mr-1" />
                                    {activity.cost}
                                  </Badge>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </TabsContent>

                <TabsContent value="accommodations">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {plan.accommodations.map((accommodation, index) => (
                      <Card key={index}>
                        <div className="h-48 overflow-hidden">
                          <img
                            src={`/placeholder.svg?height=300&width=500&text=Accommodation+${index + 1}`}
                            alt={accommodation.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <CardHeader className="pb-2">
                          <CardTitle>{accommodation.name}</CardTitle>
                          <CardDescription>{accommodation.location}</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <p className="text-gray-600 mb-2">{accommodation.description}</p>
                          <div className="flex justify-between items-center">
                            <Badge variant="outline">
                              <DollarSign className="h-3 w-3 mr-1" />
                              {accommodation.priceRange}
                            </Badge>
                            <div className="flex items-center">
                              <Star className="h-4 w-4 text-yellow-500 mr-1" />
                              <span>{accommodation.rating}</span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="dining">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {plan.dining.map((restaurant, index) => (
                      <Card key={index}>
                        <div className="h-48 overflow-hidden">
                          <img
                            src={`/placeholder.svg?height=300&width=500&text=Restaurant+${index + 1}`}
                            alt={restaurant.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <CardHeader className="pb-2">
                          <CardTitle>{restaurant.name}</CardTitle>
                          <CardDescription>{restaurant.cuisine}</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <p className="text-gray-600 mb-2">{restaurant.description}</p>
                          <div className="flex justify-between items-center">
                            <Badge variant="outline">
                              <DollarSign className="h-3 w-3 mr-1" />
                              {restaurant.priceRange}
                            </Badge>
                            <div className="flex items-center">
                              <Star className="h-4 w-4 text-yellow-500 mr-1" />
                              <span>{restaurant.rating}</span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="map">
                  <Card>
                    <CardHeader>
                      <CardTitle>Trip Map</CardTitle>
                      <CardDescription>Visualize your itinerary on the map</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="h-[500px] bg-gray-100 rounded-lg flex items-center justify-center">
                        <div className="text-center">
                          <Map className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                          <p className="text-gray-600">Map would be displayed here with Google Maps integration</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>

            <div>
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Trip Summary</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-start">
                        <MapPin className="h-5 w-5 text-gray-500 mr-3 mt-0.5" />
                        <div>
                          <h4 className="font-medium">Destination</h4>
                          <p className="text-gray-600">{plan.destination}</p>
                        </div>
                      </div>

                      <div className="flex items-start">
                        <Calendar className="h-5 w-5 text-gray-500 mr-3 mt-0.5" />
                        <div>
                          <h4 className="font-medium">Dates</h4>
                          <p className="text-gray-600">
                            {plan.startDate && format(new Date(plan.startDate), "MMM d")} -{" "}
                            {plan.endDate && format(new Date(plan.endDate), "MMM d, yyyy")}
                          </p>
                          <p className="text-gray-600">{plan.days.length} days</p>
                        </div>
                      </div>

                      <div className="flex items-start">
                        <DollarSign className="h-5 w-5 text-gray-500 mr-3 mt-0.5" />
                        <div>
                          <h4 className="font-medium">Estimated Budget</h4>
                          <p className="text-gray-600">${plan.budget} per person</p>
                        </div>
                      </div>

                      <div className="flex items-start">
                        <Users className="h-5 w-5 text-gray-500 mr-3 mt-0.5" />
                        <div>
                          <h4 className="font-medium">Travelers</h4>
                          <p className="text-gray-600">
                            {plan.travelers} {plan.travelers === 1 ? "person" : "people"}
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Weather & Alerts</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                        <div className="flex items-center">
                          <Sun className="h-8 w-8 text-yellow-500 mr-3" />
                          <div>
                            <h4 className="font-medium">Weather Forecast</h4>
                            <p className="text-gray-600 text-sm">Mostly sunny, 75°F</p>
                          </div>
                        </div>
                        <span className="text-sm text-gray-500">Day 1</span>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center">
                          <Cloud className="h-8 w-8 text-gray-400 mr-3" />
                          <div>
                            <h4 className="font-medium">Weather Forecast</h4>
                            <p className="text-gray-600 text-sm">Partly cloudy, 72°F</p>
                          </div>
                        </div>
                        <span className="text-sm text-gray-500">Day 2</span>
                      </div>

                      <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                        <div className="flex items-center">
                          <Umbrella className="h-8 w-8 text-blue-500 mr-3" />
                          <div>
                            <h4 className="font-medium">Weather Forecast</h4>
                            <p className="text-gray-600 text-sm">Light rain, 68°F</p>
                          </div>
                        </div>
                        <span className="text-sm text-gray-500">Day 3</span>
                      </div>

                      <div className="mt-6 p-3 bg-amber-50 rounded-lg border border-amber-200">
                        <div className="flex items-start">
                          <AlertTriangle className="h-5 w-5 text-amber-500 mr-2 mt-0.5" />
                          <div>
                            <h4 className="font-medium text-amber-800">Local Alert</h4>
                            <p className="text-amber-700 text-sm">
                              Cultural festival taking place in the city center on Day 2. Expect crowds and some road
                              closures.
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Local Events</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {plan.events.map((event, index) => (
                        <div key={index} className="flex items-start">
                          <CalendarClock className="h-5 w-5 text-teal-500 mr-3 mt-0.5" />
                          <div>
                            <h4 className="font-medium">{event.name}</h4>
                            <p className="text-gray-600 text-sm">{event.date}</p>
                            <p className="text-gray-600 text-sm mt-1">{event.description}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Button className="w-full mt-6">Download Itinerary PDF</Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// Mock data types and generator
type Activity = {
  time: string
  title: string
  description: string
  cost?: string
}

type Day = {
  title: string
  date: string
  activities: Activity[]
}

type Accommodation = {
  name: string
  location: string
  description: string
  priceRange: string
  rating: number
}

type Restaurant = {
  name: string
  cuisine: string
  description: string
  priceRange: string
  rating: number
}

type Event = {
  name: string
  date: string
  description: string
}

type TripPlan = {
  destination: string
  startDate: string
  endDate: string
  budget: number
  travelers: number
  days: Day[]
  accommodations: Accommodation[]
  dining: Restaurant[]
  events: Event[]
}

function generateMockTripPlan(
  destination: string,
  startDate?: Date,
  endDate?: Date,
  budget = 500,
  travelers = 2,
): TripPlan {
  // Calculate number of days
  const start = startDate || new Date()
  const end = endDate || addDays(start, 3)
  const dayCount = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24))

  // Generate days
  const days: Day[] = []
  for (let i = 0; i < dayCount; i++) {
    const currentDate = addDays(start, i)
    days.push({
      title:
        i === 0 ? "Arrival & Exploration" : i === dayCount - 1 ? "Final Day & Departure" : `Exploring ${destination}`,
      date: currentDate.toISOString(),
      activities: [
        {
          time: "09:00 AM",
          title: i === 0 ? "Arrival & Check-in" : "Breakfast at hotel",
          description:
            i === 0 ? "Arrive at your accommodation and get settled in" : "Start your day with a delicious breakfast",
          cost: i === 0 ? undefined : "$15-25",
        },
        {
          time: "10:30 AM",
          title: `Visit ${["Museum", "Historical Site", "Local Market", "Gardens"][i % 4]}`,
          description: `Explore the famous ${["art collections", "historical landmarks", "local products", "beautiful flora"][i % 4]} of ${destination}`,
          cost: "$20-30",
        },
        {
          time: "01:00 PM",
          title: "Lunch break",
          description: `Enjoy ${["local cuisine", "street food", "seafood", "traditional dishes"][i % 4]} at a popular spot`,
          cost: "$15-25",
        },
        {
          time: "03:00 PM",
          title: `${["Walking Tour", "Boat Ride", "Shopping", "Cultural Experience"][i % 4]}`,
          description: `${["Discover hidden gems with a local guide", "See the city from the water", "Find unique souvenirs", "Immerse yourself in local traditions"][i % 4]}`,
          cost: "$25-40",
        },
        {
          time: "07:00 PM",
          title: "Dinner",
          description: `${["Fine dining experience", "Casual local restaurant", "Rooftop dining with views", "Authentic experience"][i % 4]}`,
          cost: "$30-50",
        },
      ],
    })
  }

  // Generate accommodations
  const accommodations: Accommodation[] = [
    {
      name: `${destination} Grand Hotel`,
      location: `Downtown ${destination}`,
      description: "Luxurious hotel with excellent amenities and central location",
      priceRange: "$$$",
      rating: 4.7,
    },
    {
      name: `${destination} Boutique Inn`,
      location: `Historic District, ${destination}`,
      description: "Charming boutique accommodation with unique character",
      priceRange: "$$",
      rating: 4.5,
    },
  ]

  // Generate dining options
  const dining: Restaurant[] = [
    {
      name: `${destination} Gourmet`,
      cuisine: "Fine Dining / International",
      description: "Award-winning restaurant featuring local ingredients with international techniques",
      priceRange: "$$$",
      rating: 4.8,
    },
    {
      name: "Local Flavors",
      cuisine: "Traditional",
      description: "Authentic local cuisine in a cozy atmosphere",
      priceRange: "$$",
      rating: 4.6,
    },
    {
      name: "Street Food Market",
      cuisine: "Various / Street Food",
      description: "Vibrant market with various local street food options",
      priceRange: "$",
      rating: 4.4,
    },
    {
      name: "Waterfront Bistro",
      cuisine: "Seafood / Mediterranean",
      description: "Fresh seafood with beautiful views of the water",
      priceRange: "$$$",
      rating: 4.5,
    },
  ]

  // Generate events
  const events: Event[] = [
    {
      name: `${destination} Cultural Festival`,
      date: format(addDays(start, 1), "MMMM d, yyyy"),
      description: "Annual festival celebrating local culture with music, dance, and food",
    },
    {
      name: "Artisan Market",
      date: format(addDays(start, 2), "MMMM d, yyyy"),
      description: "Local craftsmen showcase their unique creations",
    },
  ]

  return {
    destination,
    startDate: start.toISOString(),
    endDate: end.toISOString(),
    budget,
    travelers,
    days,
    accommodations,
    dining,
    events,
  }
}

function Star({ className }: { className?: string }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className={className}>
      <path
        fillRule="evenodd"
        d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.007 5.404.433c1.164.093 1.636 1.545.749 2.305l-4.117 3.527 1.257 5.273c.271 1.136-.964 2.033-1.96 1.425L12 18.354 7.373 21.18c-.996.608-2.231-.29-1.96-1.425l1.257-5.273-4.117-3.527c-.887-.76-.415-2.212.749-2.305l5.404-.433 2.082-5.006z"
        clipRule="evenodd"
      />
    </svg>
  )
}
