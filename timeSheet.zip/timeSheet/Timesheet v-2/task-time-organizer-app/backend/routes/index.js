
const express = require('express');
const router = express.Router();
const authRoutes = require('./auth');
const timesheetRoutes = require('./timesheets');
const projectRoutes = require('./projects');
const reportRoutes = require('./reports');
const userRoutes = require('./users');

// Auth routes
router.use('/auth', authRoutes);

// Protected routes
router.use('/timesheets', timesheetRoutes);
router.use('/projects', projectRoutes);
router.use('/reports', reportRoutes);
router.use('/users', userRoutes);

module.exports = router;
