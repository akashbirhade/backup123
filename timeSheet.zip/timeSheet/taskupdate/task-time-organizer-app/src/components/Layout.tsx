
import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { BarChart, Calendar, Clock, User, FileText, Settings, LogOut } from 'lucide-react';
import Logo from './Logo';
import { cn } from '@/lib/utils';
import CalendarView from './CalendarView';
import { useAuth } from '@/context/AuthContext';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from 'sonner';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const location = useLocation();
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  
  const handleLogout = () => {
    logout();
    toast.success("Logged out successfully");
    navigate('/login');
  };
  
  let navItems = [
    { name: 'Dashboard', path: '/', icon: BarChart },
    { name: 'Calendar', path: '/calendar', icon: Calendar },
    { name: 'Timesheet', path: '/timesheet', icon: Clock },
    { name: 'Projects', path: '/projects', icon: FileText },
    { name: 'Profile', path: '/profile', icon: User },
  ];
  
  // Add Reports page only for admin users
  if (user?.role === 'admin') {
    navItems = [
      ...navItems,
      { name: 'Reports', path: '/reports', icon: FileText },
    ];
  }

  return (
    <div className="flex h-screen">
      {/* Sidebar */}
      <div className="hidden md:flex flex-col w-64 bg-sidebar min-h-screen p-4">
        <div className="mb-8">
          <Logo />
        </div>
        <nav className="flex-1">
          <ul className="space-y-2">
            {navItems.map((item) => (
              <li key={item.path}>
                <Link
                  to={item.path}
                  className={cn(
                    "flex items-center px-4 py-3 rounded-md hover:bg-sidebar-accent transition-colors",
                    location.pathname === item.path ? "bg-primary text-white" : "text-gray-200"
                  )}
                >
                  <item.icon className="h-5 w-5 mr-3" />
                  {item.name}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        
        <div className="mt-auto space-y-2">
          <Link
            to="/settings"
            className="flex items-center px-4 py-3 text-gray-200 rounded-md hover:bg-sidebar-accent transition-colors"
          >
            <Settings className="h-5 w-5 mr-3" />
            Settings
          </Link>
          
          <button
            onClick={handleLogout}
            className="w-full flex items-center px-4 py-3 text-gray-200 rounded-md hover:bg-sidebar-accent transition-colors"
          >
            <LogOut className="h-5 w-5 mr-3" />
            Logout
          </button>
        </div>
      </div>

      {/* Mobile header */}
      <div className="md:hidden fixed top-0 left-0 right-0 bg-sidebar z-10">
        <div className="flex items-center justify-between p-4">
          <Logo />
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Avatar className="h-8 w-8 cursor-pointer">
                <AvatarFallback>{user?.name.charAt(0) || 'U'}</AvatarFallback>
              </Avatar>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>My Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {navItems.map(item => (
                <DropdownMenuItem key={item.path} asChild>
                  <Link to={item.path} className="flex items-center">
                    <item.icon className="h-4 w-4 mr-2" />
                    {item.name}
                  </Link>
                </DropdownMenuItem>
              ))}
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link to="/settings" className="flex items-center">
                  <Settings className="h-4 w-4 mr-2" />
                  Settings
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={handleLogout} className="flex items-center text-red-600">
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Content */}
        <main className="flex-1 overflow-y-auto p-4 md:p-8 bg-gray-50">
          <div className="md:hidden h-16"></div> {/* Spacer for mobile header */}
          {children}
        </main>
      </div>
    </div>
  );
};

export default Layout;
