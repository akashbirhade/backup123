import React from 'react';
import CalendarView from '@/components/CalendarView';
import TaskCalendarView from '@/components/TaskCalendarView'; // Import the new component
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

const CalendarPage: React.FC = () => {
  return (
    <div className="container mx-auto p-1 space-y-6">
      <div className="flex flex-col space-y-2">
        <h1 className="text-3xl font-bold">Calendar</h1>
        <p className="text-muted-foreground">
          View and manage project timelines, meetings, and deadlines
        </p>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Monthly Calendar</CardTitle>
          <CardDescription>See your project timelines, meetings, and deadlines in a monthly view.</CardDescription>
        </CardHeader>
        <CardContent>
          <CalendarView />
        </CardContent>
      </Card>

      {/* New Task Entry Calendar */}
      <TaskCalendarView />
    </div>
  );
};

export default CalendarPage;
