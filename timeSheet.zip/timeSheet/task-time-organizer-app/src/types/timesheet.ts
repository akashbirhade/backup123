
export interface Task {
  id: string;
  projectId: string;
  description: string;
  hours: string[];
}

export interface Project {
  id: string;
  name: string;
  clientId: string;
  clientName: string;
  tasks: Task[];
}

export interface Timesheet {
  id: string;
  employeeId: string;
  employeeName: string;
  weekStarting: Date;
  weekEnding: Date;
  projects: Project[];
  status: 'draft' | 'submitted' | 'approved' | 'rejected';
  totalHours: number[];
}

export interface CalendarDay {
  date: Date;
  status: 'complete' | 'partial' | 'missing';
  hours: number;
  tasks: {
    id: string;
    projectId: string;
    projectName: string;
    description: string;
    hours: number;
  }[];
}
