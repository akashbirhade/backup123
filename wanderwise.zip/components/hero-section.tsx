"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Search, Calendar, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"
import { format } from "date-fns"
import CurrencySelector from "./currency-selector"

export default function HeroSection() {
  const router = useRouter()
  const [location, setLocation] = useState("")
  const [date, setDate] = useState<Date | undefined>(undefined)
  const [showCalendar, setShowCalendar] = useState(false)

  const handleSearch = () => {
    if (location) {
      const searchParams = new URLSearchParams()
      searchParams.set("location", location)
      if (date) {
        searchParams.set("date", format(date, "yyyy-MM-dd"))
      }
      router.push(`/properties?${searchParams.toString()}`)
    }
  }

  return (
    <div className="relative h-[600px] w-full">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: "url('/placeholder.svg?height=600&width=1600')",
          backgroundPosition: "center",
        }}
      >
        <div className="absolute inset-0 bg-black/40" />
      </div>

      <div className="relative h-full flex flex-col items-center justify-center text-white px-4">
        <h1 className="text-5xl md:text-6xl font-bold mb-4 text-center">Discover the World with WanderWise</h1>
        <p className="text-xl md:text-2xl mb-8 text-center max-w-3xl">
          AI-powered travel planning for stress-free adventures
        </p>

        <Card className="w-full max-w-4xl bg-white/95 backdrop-blur-sm shadow-lg">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-grow">
                <MapPin className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                <Input
                  placeholder="Where are you going?"
                  className="pl-10 h-12"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                />
              </div>

              <Popover open={showCalendar} onOpenChange={setShowCalendar}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className="h-12 flex items-center justify-start pl-3 text-left font-normal"
                    onClick={() => setShowCalendar(true)}
                  >
                    <Calendar className="mr-2 h-5 w-5 text-gray-400" />
                    {date ? format(date, "PPP") : "Select date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <CalendarComponent
                    mode="single"
                    selected={date}
                    onSelect={(date) => {
                      setDate(date)
                      setShowCalendar(false)
                    }}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>

              <Button className="h-12 bg-teal-600 hover:bg-teal-700" onClick={handleSearch}>
                <Search className="mr-2 h-5 w-5" />
                Search
              </Button>
            </div>

            <div className="mt-4 flex justify-end">
              <CurrencySelector />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
