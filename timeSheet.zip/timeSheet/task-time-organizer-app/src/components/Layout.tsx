
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { BarChart, Calendar, Clock, User, FileText, Settings } from 'lucide-react';
import Logo from './Logo';
import { cn } from '@/lib/utils';
import CalendarView from './CalendarView';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const location = useLocation();
  
  const navItems = [
    { name: 'Dashboard', path: '/', icon: BarChart },
    { name: 'Calendar', path: '/calendar', icon: Calendar },
    { name: 'Timesheet', path: '/timesheet', icon: Clock },
    { name: 'Projects', path: '/projects', icon: FileText },
    { name: 'Reports', path: '/reports', icon: FileText },
    { name: 'Profile', path: '/profile', icon: User },
  ];

  return (
    <div className="flex h-screen">
      {/* Sidebar */}
      <div className="hidden md:flex flex-col w-64 bg-sidebar min-h-screen p-4">
        <div className="mb-8">
          <Logo />
        </div>
        <nav className="flex-1">
          <ul className="space-y-2">
            {navItems.map((item) => (
              <li key={item.path}>
                <Link
                  to={item.path}
                  className={cn(
                    "flex items-center px-4 py-3 rounded-md hover:bg-sidebar-accent transition-colors",
                    location.pathname === item.path ? "bg-primary text-white" : "text-gray-200"
                  )}
                >
                  <item.icon className="h-5 w-5 mr-3" />
                  {item.name}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        
        <div className="mt-auto">
          <Link
            to="/settings"
            className="flex items-center px-4 py-3 text-gray-200 rounded-md hover:bg-sidebar-accent transition-colors"
          >
            <Settings className="h-5 w-5 mr-3" />
            Settings
          </Link>
        </div>
      </div>

      {/* Mobile header */}
      <div className="md:hidden fixed top-0 left-0 right-0 bg-sidebar z-10">
        <div className="flex items-center justify-between p-4">
          <Logo />
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Content */}
        <main className="flex-1 overflow-y-auto p-4 md:p-8 bg-gray-50">
          <div className="md:hidden h-16"></div> {/* Spacer for mobile header */}
          {children}
        </main>
      </div>
    </div>
  );
};

export default Layout;
