
import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

const FloatingOrb = ({ position, color, scale }: { position: [number, number, number], color: string, scale: number }) => {
  const meshRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.5) * 0.2;
      meshRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.3) * 0.2;
    }
  });

  return (
    <group>
      <mesh ref={meshRef} position={position} scale={scale}>
        <sphereGeometry args={[1, 32, 32]} />
        <meshStandardMaterial
          color={color}
          transparent
          opacity={0.6}
          roughness={0.1}
          metalness={0.8}
          emissive={color}
          emissiveIntensity={0.2}
        />
      </mesh>
    </group>
  );
};

const ThreeScene = () => {
  return (
    <>
      <ambientLight intensity={0.3} />
      <pointLight position={[10, 10, 10]} color="#ffffff" intensity={0.8} />
      <pointLight position={[-10, -10, -10]} color="#3b82f6" intensity={0.5} />
      
      <FloatingOrb position={[-4, 2, -5]} color="#3b82f6" scale={0.8} />
      <FloatingOrb position={[4, -2, -8]} color="#8b5cf6" scale={1.2} />
      <FloatingOrb position={[2, 3, -6]} color="#06b6d4" scale={0.6} />
      <FloatingOrb position={[-3, -1, -4]} color="#ec4899" scale={0.9} />
      <FloatingOrb position={[1, -3, -7]} color="#10b981" scale={0.7} />
    </>
  );
};

export default ThreeScene;
