"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Upload, X, ImageIcon } from "lucide-react"

export function PhotoUpload({ onPhotosChange }) {
  const [photos, setPhotos] = useState([])
  const [dragActive, setDragActive] = useState(false)

  // Handle drag events
  const handleDrag = (e) => {
    e.preventDefault()
    e.stopPropagation()
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true)
    } else if (e.type === "dragleave") {
      setDragActive(false)
    }
  }

  // Simulate file drop
  const handleDrop = (e) => {
    e.preventDefault()
    e.stopPropagation()
    setDragActive(false)

    // In a real app, we would process the actual files
    // For this demo, we'll create mock photo objects
    const newPhotos = [
      {
        id: Date.now(),
        name: "property-photo-1.jpg",
        preview: "/placeholder.svg?height=200&width=300",
        size: "2.4 MB",
      },
      {
        id: Date.now() + 1,
        name: "property-photo-2.jpg",
        preview: "/placeholder.svg?height=200&width=300",
        size: "1.8 MB",
      },
    ]

    const updatedPhotos = [...photos, ...newPhotos]
    setPhotos(updatedPhotos)

    if (onPhotosChange) {
      onPhotosChange(updatedPhotos)
    }
  }

  // Simulate file selection
  const handleFileSelect = () => {
    // In a real app, we would open a file picker
    // For this demo, we'll create a mock photo object
    const newPhoto = {
      id: Date.now(),
      name: `property-photo-${photos.length + 1}.jpg`,
      preview: "/placeholder.svg?height=200&width=300",
      size: "1.2 MB",
    }

    const updatedPhotos = [...photos, newPhoto]
    setPhotos(updatedPhotos)

    if (onPhotosChange) {
      onPhotosChange(updatedPhotos)
    }
  }

  // Remove a photo
  const removePhoto = (id) => {
    const updatedPhotos = photos.filter((photo) => photo.id !== id)
    setPhotos(updatedPhotos)

    if (onPhotosChange) {
      onPhotosChange(updatedPhotos)
    }
  }

  return (
    <div className="space-y-4">
      <div
        className={`border-2 border-dashed rounded-lg p-6 text-center ${
          dragActive ? "border-emerald-500 bg-emerald-50" : "border-gray-300"
        }`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
      >
        <Upload className="h-8 w-8 mx-auto text-gray-400 mb-2" />
        <p className="text-sm text-gray-600 mb-2">Drag and drop your photos here, or click to browse</p>
        <p className="text-xs text-gray-500 mb-4">Recommended: At least 5 high-quality photos</p>
        <Button type="button" variant="outline" size="sm" onClick={handleFileSelect}>
          Upload Photos
        </Button>
      </div>

      {photos.length > 0 && (
        <div>
          <h3 className="text-sm font-medium mb-2">Uploaded Photos ({photos.length})</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {photos.map((photo) => (
              <div key={photo.id} className="relative group">
                <div className="aspect-video bg-gray-100 rounded-md overflow-hidden">
                  <img
                    src={photo.preview || "/placeholder.svg"}
                    alt={photo.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <button
                  type="button"
                  className="absolute top-2 right-2 bg-white rounded-full p-1 shadow-sm opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={() => removePhoto(photo.id)}
                >
                  <X className="h-4 w-4 text-gray-600" />
                </button>
                <div className="text-xs text-gray-500 mt-1 truncate">{photo.name}</div>
              </div>
            ))}
            <div
              className="aspect-video border-2 border-dashed border-gray-300 rounded-md flex items-center justify-center cursor-pointer hover:bg-gray-50"
              onClick={handleFileSelect}
            >
              <div className="text-center">
                <ImageIcon className="h-6 w-6 mx-auto text-gray-400 mb-1" />
                <span className="text-xs text-gray-500">Add more</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
