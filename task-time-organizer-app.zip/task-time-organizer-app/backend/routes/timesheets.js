
const express = require('express');
const router = express.Router();
const { auth } = require('../middleware/auth');
const { format, startOfWeek, endOfWeek, addDays, parseISO } = require('date-fns');

// Middleware to apply auth to all routes
router.use(auth);

// Get timesheets for current user
router.get('/', async (req, res) => {
  try {
    const { startDate, endDate, status } = req.query;
    let query = `
      SELECT t.*, 
      COALESCE(SUM(te.hours), 0) AS total_hours
      FROM timesheets t
      LEFT JOIN time_entries te ON t.id = te.timesheet_id
      WHERE t.user_id = $1
    `;
    
    const queryParams = [req.user.id];
    let paramCounter = 2;
    
    if (startDate) {
      query += ` AND t.week_starting >= $${paramCounter}`;
      queryParams.push(startDate);
      paramCounter++;
    }
    
    if (endDate) {
      query += ` AND t.week_starting <= $${paramCounter}`;
      queryParams.push(endDate);
      paramCounter++;
    }
    
    if (status) {
      query += ` AND t.status = $${paramCounter}`;
      queryParams.push(status);
      paramCounter++;
    }
    
    query += ' GROUP BY t.id ORDER BY t.week_starting DESC';
    
    const result = await req.db.query(query, queryParams);
    
    res.status(200).json({
      success: true,
      data: result.rows
    });
  } catch (error) {
    console.error('Error fetching timesheets:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

// Get a single timesheet with time entries
router.get('/:id', async (req, res) => {
  try {
    // Get timesheet
    const timesheetResult = await req.db.query(
      `SELECT t.*,
        u.first_name, u.last_name,
        COALESCE(SUM(te.hours), 0) AS total_hours
      FROM timesheets t
      JOIN users u ON t.user_id = u.id
      LEFT JOIN time_entries te ON t.id = te.timesheet_id
      WHERE t.id = $1 AND (t.user_id = $2 OR $3 = 'admin')
      GROUP BY t.id, u.first_name, u.last_name`,
      [req.params.id, req.user.id, req.user.role]
    );
    
    if (timesheetResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'Timesheet not found or access denied'
      });
    }
    
    const timesheet = timesheetResult.rows[0];
    
    // Get time entries
    const entriesResult = await req.db.query(
      `SELECT te.*, 
        p.name as project_name, 
        c.name as client_name,
        t.name as task_name
      FROM time_entries te
      LEFT JOIN projects p ON te.project_id = p.id
      LEFT JOIN clients c ON p.client_id = c.id
      LEFT JOIN tasks t ON te.task_id = t.id
      WHERE te.timesheet_id = $1
      ORDER BY te.entry_date, p.name`,
      [req.params.id]
    );
    
    // Group entries by day
    const dailyEntries = {};
    
    entriesResult.rows.forEach(entry => {
      const dateStr = entry.entry_date.toISOString().split('T')[0];
      
      if (!dailyEntries[dateStr]) {
        dailyEntries[dateStr] = {
          date: entry.entry_date,
          totalHours: 0,
          entries: []
        };
      }
      
      dailyEntries[dateStr].entries.push({
        id: entry.id,
        projectId: entry.project_id,
        projectName: entry.project_name,
        clientName: entry.client_name,
        taskId: entry.task_id,
        taskName: entry.task_name,
        description: entry.description,
        hours: entry.hours
      });
      
      dailyEntries[dateStr].totalHours += parseFloat(entry.hours);
    });
    
    // Get absences
    const absenceResult = await req.db.query(
      `SELECT a.*, at.name as absence_type_name
      FROM absences a
      JOIN absence_types at ON a.absence_type_id = at.id
      WHERE a.user_id = $1 
      AND a.start_date <= $2 AND a.end_date >= $3`,
      [
        timesheet.user_id,
        endOfWeek(parseISO(timesheet.week_starting)),
        startOfWeek(parseISO(timesheet.week_starting))
      ]
    );
    
    res.status(200).json({
      success: true,
      data: {
        id: timesheet.id,
        userId: timesheet.user_id,
        employeeName: `${timesheet.first_name} ${timesheet.last_name}`,
        weekStarting: timesheet.week_starting,
        status: timesheet.status,
        totalHours: timesheet.total_hours,
        submittedAt: timesheet.submitted_at,
        approvedAt: timesheet.approved_at,
        dailyEntries,
        absences: absenceResult.rows
      }
    });
  } catch (error) {
    console.error('Error fetching timesheet:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

// Create a new timesheet
router.post('/', async (req, res) => {
  const { weekStarting } = req.body;
  
  try {
    // Check if timesheet already exists for this week
    const existingResult = await req.db.query(
      'SELECT id FROM timesheets WHERE user_id = $1 AND week_starting = $2',
      [req.user.id, weekStarting]
    );
    
    if (existingResult.rows.length > 0) {
      return res.status(400).json({
        success: false,
        error: 'A timesheet for this week already exists'
      });
    }
    
    // Create a new timesheet
    const result = await req.db.query(
      'INSERT INTO timesheets (user_id, week_starting, status) VALUES ($1, $2, $3) RETURNING id',
      [req.user.id, weekStarting, 'draft']
    );
    
    const timesheetId = result.rows[0].id;
    
    res.status(201).json({
      success: true,
      data: {
        id: timesheetId,
        userId: req.user.id,
        weekStarting,
        status: 'draft'
      }
    });
  } catch (error) {
    console.error('Error creating timesheet:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

// Add time entry
router.post('/:id/entries', async (req, res) => {
  const { projectId, taskId, entryDate, hours, description } = req.body;
  
  try {
    // Check if timesheet exists and belongs to user
    const timesheetResult = await req.db.query(
      'SELECT status FROM timesheets WHERE id = $1 AND user_id = $2',
      [req.params.id, req.user.id]
    );
    
    if (timesheetResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'Timesheet not found or access denied'
      });
    }
    
    const timesheet = timesheetResult.rows[0];
    
    if (timesheet.status !== 'draft') {
      return res.status(400).json({
        success: false,
        error: 'Cannot modify a submitted or approved timesheet'
      });
    }
    
    // Create time entry
    const result = await req.db.query(
      `INSERT INTO time_entries 
        (timesheet_id, user_id, project_id, task_id, entry_date, hours, description) 
       VALUES ($1, $2, $3, $4, $5, $6, $7) 
       RETURNING id`,
      [req.params.id, req.user.id, projectId, taskId, entryDate, hours, description]
    );
    
    const entryId = result.rows[0].id;
    
    // Get the project and task names
    const projectResult = await req.db.query(
      `SELECT p.name as project_name, c.name as client_name
       FROM projects p
       JOIN clients c ON p.client_id = c.id
       WHERE p.id = $1`,
      [projectId]
    );
    
    const taskResult = await req.db.query(
      'SELECT name FROM tasks WHERE id = $1',
      [taskId]
    );
    
    res.status(201).json({
      success: true,
      data: {
        id: entryId,
        timesheetId: parseInt(req.params.id),
        projectId,
        projectName: projectResult.rows[0]?.project_name,
        clientName: projectResult.rows[0]?.client_name,
        taskId,
        taskName: taskResult.rows[0]?.name,
        entryDate,
        hours,
        description
      }
    });
  } catch (error) {
    console.error('Error adding time entry:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

// Update time entry
router.put('/entries/:entryId', async (req, res) => {
  const { hours, description } = req.body;
  
  try {
    // Check if time entry exists and belongs to user
    const entryResult = await req.db.query(
      `SELECT te.*, t.status
       FROM time_entries te
       JOIN timesheets t ON te.timesheet_id = t.id
       WHERE te.id = $1 AND te.user_id = $2`,
      [req.params.entryId, req.user.id]
    );
    
    if (entryResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'Time entry not found or access denied'
      });
    }
    
    const entry = entryResult.rows[0];
    
    if (entry.status !== 'draft') {
      return res.status(400).json({
        success: false,
        error: 'Cannot modify a submitted or approved timesheet'
      });
    }
    
    // Update time entry
    await req.db.query(
      'UPDATE time_entries SET hours = $1, description = $2, updated_at = NOW() WHERE id = $3',
      [hours, description, req.params.entryId]
    );
    
    res.status(200).json({
      success: true,
      data: {
        id: parseInt(req.params.entryId),
        hours,
        description,
        updatedAt: new Date()
      }
    });
  } catch (error) {
    console.error('Error updating time entry:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

// Delete time entry
router.delete('/entries/:entryId', async (req, res) => {
  try {
    // Check if time entry exists and belongs to user
    const entryResult = await req.db.query(
      `SELECT te.*, t.status
       FROM time_entries te
       JOIN timesheets t ON te.timesheet_id = t.id
       WHERE te.id = $1 AND te.user_id = $2`,
      [req.params.entryId, req.user.id]
    );
    
    if (entryResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'Time entry not found or access denied'
      });
    }
    
    const entry = entryResult.rows[0];
    
    if (entry.status !== 'draft') {
      return res.status(400).json({
        success: false,
        error: 'Cannot modify a submitted or approved timesheet'
      });
    }
    
    // Delete time entry
    await req.db.query(
      'DELETE FROM time_entries WHERE id = $1',
      [req.params.entryId]
    );
    
    res.status(200).json({
      success: true,
      data: {}
    });
  } catch (error) {
    console.error('Error deleting time entry:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

// Submit timesheet
router.put('/:id/submit', async (req, res) => {
  try {
    // Check if timesheet exists and belongs to user
    const timesheetResult = await req.db.query(
      'SELECT status FROM timesheets WHERE id = $1 AND user_id = $2',
      [req.params.id, req.user.id]
    );
    
    if (timesheetResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        error: 'Timesheet not found or access denied'
      });
    }
    
    const timesheet = timesheetResult.rows[0];
    
    if (timesheet.status !== 'draft') {
      return res.status(400).json({
        success: false,
        error: 'Timesheet is already submitted or approved'
      });
    }
    
    // Submit timesheet
    await req.db.query(
      'UPDATE timesheets SET status = $1, submitted_at = NOW(), updated_at = NOW() WHERE id = $2',
      ['submitted', req.params.id]
    );
    
    res.status(200).json({
      success: true,
      data: {
        id: parseInt(req.params.id),
        status: 'submitted',
        submittedAt: new Date()
      }
    });
  } catch (error) {
    console.error('Error submitting timesheet:', error);
    res.status(500).json({
      success: false,
      error: 'Server error'
    });
  }
});

module.exports = router;
