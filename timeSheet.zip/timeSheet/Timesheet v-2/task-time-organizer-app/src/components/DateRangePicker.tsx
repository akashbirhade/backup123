
import * as React from "react";
import { format, startOfWeek, endOfWeek, addWeeks, subWeeks } from "date-fns";
import { Calendar as CalendarIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

interface DateRangePickerProps {
  onDateChange: (startDate: Date, endDate: Date) => void;
}

const DateRangePicker: React.FC<DateRangePickerProps> = ({ onDateChange }) => {
  const today = new Date();
  const [date, setDate] = React.useState<Date>(today);
  const [weekStart, setWeekStart] = React.useState(startOfWeek(today, { weekStartsOn: 0 }));
  const [weekEnd, setWeekEnd] = React.useState(endOfWeek(today, { weekStartsOn: 0 }));
  
  const handleDateChange = (newDate: Date | undefined) => {
    if (!newDate) return;
    
    setDate(newDate);
    const start = startOfWeek(newDate, { weekStartsOn: 0 });
    const end = endOfWeek(newDate, { weekStartsOn: 0 });
    
    setWeekStart(start);
    setWeekEnd(end);
    onDateChange(start, end);
  };
  
  const navigateWeek = (direction: 'next' | 'previous') => {
    const newDate = direction === 'next' ? addWeeks(date, 1) : subWeeks(date, 1);
    handleDateChange(newDate);
  };

  React.useEffect(() => {
    onDateChange(weekStart, weekEnd);
  }, []);

  return (
    <div className="flex flex-col sm:flex-row gap-2 items-center">
      <Button
        variant="outline"
        size="sm"
        onClick={() => navigateWeek('previous')}
        className="h-9"
      >
        Previous Week
      </Button>
      
      <Popover>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            className={cn(
              "w-full justify-start text-left font-normal px-4 sm:w-auto"
            )}
          >
            <CalendarIcon className="mr-2 h-4 w-4" />
            <span>
              {format(weekStart, "MMM d")} - {format(weekEnd, "MMM d, yyyy")}
            </span>
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <Calendar
            mode="single"
            selected={date}
            onSelect={handleDateChange}
            initialFocus
            className="p-3 pointer-events-auto"
          />
        </PopoverContent>
      </Popover>
      
      <Button
        variant="outline"
        size="sm"
        onClick={() => navigateWeek('next')}
        className="h-9"
      >
        Next Week
      </Button>
    </div>
  );
};

export default DateRangePicker;
