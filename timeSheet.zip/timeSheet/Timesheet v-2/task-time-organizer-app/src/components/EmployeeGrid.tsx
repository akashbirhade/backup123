import * as React from 'react';
import { DataGrid, GridColDef } from '@mui/x-data-grid';

// Dummy employee data
const rows = [
  { id: 1, firstName: 'John', lastName: 'Doe', email: 'john.doe@email.com', role: 'Developer', totalHours: 120, entryCount: 15 },
  { id: 2, firstName: 'Jane', lastName: 'Smith', email: 'jane.smith@email.com', role: 'Designer', totalHours: 98, entryCount: 12 },
  { id: 3, firstName: 'Alice', lastName: 'Johnson', email: 'alice.j@email.com', role: 'Manager', totalHours: 110, entryCount: 14 },
  { id: 4, firstName: 'Bob', lastName: 'Brown', email: 'bob.b@email.com', role: 'QA', totalHours: 105, entryCount: 13 },
];

const columns: GridColDef[] = [
  { field: 'firstName', headerName: 'First Name', flex: 1 },
  { field: 'lastName', headerName: 'Last Name', flex: 1 },
  { field: 'email', headerName: 'Email', flex: 1.5 },
  { field: 'role', headerName: 'Role', flex: 1 },
  { field: 'totalHours', headerName: 'Total Hours (30d)', flex: 1, type: 'number' },
  { field: 'entryCount', headerName: 'Entries', flex: 1, type: 'number' },
];

const EmployeeGrid: React.FC = () => {
  return (
    <div className="mt-6" style={{ height: 400, width: '100%' }}>
      <h3 className="text-lg font-semibold mb-2">Employees & Performance (Last 30 Days)</h3>
      <DataGrid
        rows={rows}
        columns={columns}
        // pageSize={5}
        // rowsPerPageOptions={[5]}
        // disableRowSelectionOnClick
        // autoHeight
      />
    </div>
  );
};

export default EmployeeGrid;
