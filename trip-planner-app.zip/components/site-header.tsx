"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  navigationMenuTriggerStyle,
} from "@/components/ui/navigation-menu"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Globe, Menu, X, User, LogIn, Home, Map, PlaneLanding, Building, HelpCircle } from "lucide-react"
import { cn } from "@/lib/utils"

export function SiteHeader() {
  const pathname = usePathname()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [currency, setCurrency] = useState("USD")

  const isActive = (path) => pathname === path

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/" className="flex items-center gap-2">
            <Globe className="h-6 w-6 text-emerald-600" />
            <span className="hidden font-bold text-xl sm:inline-block">TravelSage</span>
          </Link>
          <div className="hidden md:flex">
            <NavigationMenu>
              <NavigationMenuList>
                <NavigationMenuItem>
                  <Link href="/" legacyBehavior passHref>
                    <NavigationMenuLink className={navigationMenuTriggerStyle()}>
                      <Home className="mr-2 h-4 w-4" />
                      Home
                    </NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <NavigationMenuTrigger>
                    <PlaneLanding className="mr-2 h-4 w-4" />
                    Explore
                  </NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <ul className="grid gap-3 p-4 md:w-[400px] lg:w-[500px] lg:grid-cols-2">
                      <li className="row-span-3">
                        <NavigationMenuLink asChild>
                          <a
                            className="flex h-full w-full select-none flex-col justify-end rounded-md bg-gradient-to-b from-emerald-500 to-emerald-700 p-6 no-underline outline-none focus:shadow-md"
                            href="/properties"
                          >
                            <div className="mt-4 mb-2 text-lg font-medium text-white">Featured Destinations</div>
                            <p className="text-sm leading-tight text-white/90">
                              Discover our handpicked selection of stunning properties in the world's most beautiful
                              locations.
                            </p>
                          </a>
                        </NavigationMenuLink>
                      </li>
                      <ListItem href="/properties?location=paris" title="Paris">
                        City of Lights and romance
                      </ListItem>
                      <ListItem href="/properties?location=bali" title="Bali">
                        Tropical paradise with stunning beaches
                      </ListItem>
                      <ListItem href="/properties?location=tokyo" title="Tokyo">
                        Modern metropolis with rich culture
                      </ListItem>
                      <ListItem href="/properties?location=newyork" title="New York">
                        The city that never sleeps
                      </ListItem>
                    </ul>
                  </NavigationMenuContent>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <Link href="/properties" legacyBehavior passHref>
                    <NavigationMenuLink className={navigationMenuTriggerStyle()}>
                      <Building className="mr-2 h-4 w-4" />
                      Properties
                    </NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>
                <NavigationMenuItem>
                  <Link href="/create-trip" legacyBehavior passHref>
                    <NavigationMenuLink className={navigationMenuTriggerStyle()}>
                      <Map className="mr-2 h-4 w-4" />
                      Plan Trip
                    </NavigationMenuLink>
                  </Link>
                </NavigationMenuItem>
              </NavigationMenuList>
            </NavigationMenu>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="hidden md:flex items-center">
            <select
              className="text-sm border-none focus:ring-0"
              value={currency}
              onChange={(e) => setCurrency(e.target.value)}
            >
              <option value="USD">$ USD</option>
              <option value="EUR">€ EUR</option>
              <option value="GBP">£ GBP</option>
              <option value="JPY">¥ JPY</option>
              <option value="INR">₹ INR</option>
            </select>
          </div>

          <div className="hidden md:flex items-center gap-4">
            <Link href="/host">
              <Button variant="outline" size="sm">
                List Your Property
              </Button>
            </Link>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-full">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="/placeholder.svg?height=32&width=32" alt="User" />
                    <AvatarFallback>
                      <User className="h-4 w-4" />
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>
                  <User className="mr-2 h-4 w-4" />
                  <span>Profile</span>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Building className="mr-2 h-4 w-4" />
                  <span>My Properties</span>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Map className="mr-2 h-4 w-4" />
                  <span>My Trips</span>
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <HelpCircle className="mr-2 h-4 w-4" />
                  <span>Help</span>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <LogIn className="mr-2 h-4 w-4" />
                  <span>Sign out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t">
          <div className="flex flex-col space-y-3 p-4">
            <Link
              href="/"
              className={cn(
                "flex items-center rounded-md px-3 py-2 text-sm font-medium",
                isActive("/") ? "bg-emerald-100 text-emerald-900" : "text-gray-700 hover:bg-gray-100",
              )}
              onClick={() => setMobileMenuOpen(false)}
            >
              <Home className="mr-2 h-4 w-4" />
              Home
            </Link>
            <Link
              href="/properties"
              className={cn(
                "flex items-center rounded-md px-3 py-2 text-sm font-medium",
                isActive("/properties") ? "bg-emerald-100 text-emerald-900" : "text-gray-700 hover:bg-gray-100",
              )}
              onClick={() => setMobileMenuOpen(false)}
            >
              <Building className="mr-2 h-4 w-4" />
              Properties
            </Link>
            <Link
              href="/create-trip"
              className={cn(
                "flex items-center rounded-md px-3 py-2 text-sm font-medium",
                isActive("/create-trip") ? "bg-emerald-100 text-emerald-900" : "text-gray-700 hover:bg-gray-100",
              )}
              onClick={() => setMobileMenuOpen(false)}
            >
              <Map className="mr-2 h-4 w-4" />
              Plan Trip
            </Link>
            <Link
              href="/host"
              className={cn(
                "flex items-center rounded-md px-3 py-2 text-sm font-medium",
                isActive("/host") ? "bg-emerald-100 text-emerald-900" : "text-gray-700 hover:bg-gray-100",
              )}
              onClick={() => setMobileMenuOpen(false)}
            >
              <Building className="mr-2 h-4 w-4" />
              List Your Property
            </Link>
            <div className="pt-2 pb-1">
              <p className="px-3 text-xs font-semibold text-gray-500 uppercase">Currency</p>
              <select
                className="mt-1 block w-full rounded-md border-gray-300 text-sm"
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
              >
                <option value="USD">$ USD</option>
                <option value="EUR">€ EUR</option>
                <option value="GBP">£ GBP</option>
                <option value="JPY">¥ JPY</option>
                <option value="INR">₹ INR</option>
              </select>
            </div>
          </div>
        </div>
      )}
    </header>
  )
}

function ListItem({ className, title, children, ...props }) {
  return (
    <li>
      <NavigationMenuLink asChild>
        <a
          className={cn(
            "block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-emerald-50 hover:text-emerald-900 focus:bg-emerald-50 focus:text-emerald-900",
            className,
          )}
          {...props}
        >
          <div className="text-sm font-medium leading-none">{title}</div>
          <p className="line-clamp-2 text-sm leading-snug text-gray-500">{children}</p>
        </a>
      </NavigationMenuLink>
    </li>
  )
}
