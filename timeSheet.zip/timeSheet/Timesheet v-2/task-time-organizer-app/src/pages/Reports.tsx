
import React, { useState } from 'react';
import { Calendar as CalendarIcon, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { format } from 'date-fns';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { cn } from '@/lib/utils';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const Reports = () => {
  const [month, setMonth] = useState<string>(format(new Date(), 'MMMM'));
  const [year, setYear] = useState<string>(format(new Date(), 'yyyy'));
  const [date, setDate] = useState<Date | undefined>(new Date());
  const [reportType, setReportType] = useState<string>("monthly");

  // Dummy data for the reports
  const monthlyData = [
    { name: 'Week 1', 'Project Alpha': 20, 'Project Beta': 10, 'Project Gamma': 8 },
    { name: 'Week 2', 'Project Alpha': 15, 'Project Beta': 15, 'Project Gamma': 10 },
    { name: 'Week 3', 'Project Alpha': 10, 'Project Beta': 20, 'Project Gamma': 12 },
    { name: 'Week 4', 'Project Alpha': 12, 'Project Beta': 18, 'Project Gamma': 5 },
  ];

  const projectData = [
    { name: 'Project Alpha', hours: 57, target: 60, utilization: 95 },
    { name: 'Project Beta', hours: 63, target: 50, utilization: 126 },
    { name: 'Project Gamma', hours: 35, target: 40, utilization: 87.5 },
    { name: 'Project Delta', hours: 12, target: 20, utilization: 60 },
    { name: 'Other Projects', hours: 8, target: 10, utilization: 80 },
  ];

  const years = ['2023', '2024', '2025', '2026'];
  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const handleDateSelect = (selectedDate: Date | undefined) => {
    setDate(selectedDate);
    if (selectedDate) {
      setMonth(format(selectedDate, 'MMMM'));
      setYear(format(selectedDate, 'yyyy'));
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Reports</h1>
        <p className="text-muted-foreground">
          View and export timesheet reports
        </p>
      </div>

      <Card className="overflow-hidden">
        <CardHeader className="bg-muted">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <CardTitle>Time Reports</CardTitle>

            <div className="flex flex-wrap gap-2">
              <Select value={reportType} onValueChange={setReportType}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="Report Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="monthly">Monthly</SelectItem>
                  <SelectItem value="project">By Project</SelectItem>
                  <SelectItem value="employee">By Employee</SelectItem>
                </SelectContent>
              </Select>

              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {date ? format(date, 'MMMM yyyy') : <span>Pick a month</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={date}
                    onSelect={handleDateSelect}
                    initialFocus
                    className={cn("p-3 pointer-events-auto")}
                  />
                </PopoverContent>
              </Popover>

              <Button variant="outline">
                <Download className="mr-2 h-4 w-4" /> Export
              </Button>
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-6">
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              {reportType === 'monthly' ? (
                <BarChart
                  data={monthlyData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis label={{ value: 'Hours', angle: -90, position: 'insideLeft' }} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="Project Alpha" stackId="a" fill="#8884d8" />
                  <Bar dataKey="Project Beta" stackId="a" fill="#82ca9d" />
                  <Bar dataKey="Project Gamma" stackId="a" fill="#ffc658" />
                </BarChart>
              ) : (
                <BarChart
                  data={projectData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis label={{ value: 'Hours', angle: -90, position: 'insideLeft' }} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="hours" fill="#8884d8" name="Hours Logged" />
                  <Bar dataKey="target" fill="#82ca9d" name="Target Hours" />
                </BarChart>
              )}
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {reportType === 'monthly' && (
        <Card>
          <CardHeader>
            <CardTitle>Monthly Summary - {month} {year}</CardTitle>
          </CardHeader>
          <CardContent>
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-2">Project</th>
                  <th className="text-right py-3 px-2">Hours</th>
                  <th className="text-right py-3 px-2">Budget</th>
                  <th className="text-right py-3 px-2">Utilization</th>
                </tr>
              </thead>
              <tbody>
                {projectData.map((project, index) => (
                  <tr key={index} className="border-b">
                    <td className="py-3 px-2">{project.name}</td>
                    <td className="text-right py-3 px-2">{project.hours}</td>
                    <td className="text-right py-3 px-2">{project.target}</td>
                    <td className="text-right py-3 px-2">{project.utilization}%</td>
                  </tr>
                ))}
                <tr className="border-b font-bold">
                  <td className="py-3 px-2">Total</td>
                  <td className="text-right py-3 px-2">
                    {projectData.reduce((sum, project) => sum + project.hours, 0)}
                  </td>
                  <td className="text-right py-3 px-2">
                    {projectData.reduce((sum, project) => sum + project.target, 0)}
                  </td>
                  <td className="text-right py-3 px-2">
                    {Math.round(projectData.reduce((sum, project) => sum + project.hours, 0) / 
                      projectData.reduce((sum, project) => sum + project.target, 0) * 100)}%
                  </td>
                </tr>
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default Reports;
