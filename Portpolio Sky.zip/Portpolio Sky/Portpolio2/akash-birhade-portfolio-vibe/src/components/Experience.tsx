
import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Card, CardContent } from '@/components/ui/card';

gsap.registerPlugin(ScrollTrigger);

const Experience = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const timelineRef = useRef<HTMLDivElement>(null);

  const experiences = [
    {
      company: "Periscope",
      position: "Frontend Developer",
      duration: "2023 - Present",
      description: "Leading frontend development initiatives, working with React and modern JavaScript frameworks. Responsible for creating responsive user interfaces and implementing complex UI/UX designs.",
      technologies: ["React", "TypeScript", "Redux", "Material-UI", "GSAP"],
      color: "from-blue-500 to-cyan-600"
    },
    {
      company: "Viser",
      position: "Web Developer",
      duration: "2022 - 2023",
      description: "Developed and maintained multiple web applications using React and Node.js. Collaborated with cross-functional teams to deliver high-quality software solutions.",
      technologies: ["React", "Node.js", "MongoDB", "Express.js", "JavaScript"],
      color: "from-purple-500 to-pink-600"
    },
    {
      company: "Naresh IT",
      position: "Junior Developer",
      duration: "2021 - 2022",
      description: "Started my professional journey learning web development fundamentals. Worked on various projects to build strong foundation in frontend and backend technologies.",
      technologies: ["HTML5", "CSS3", "JavaScript", "React", "Python"],
      color: "from-green-500 to-teal-600"
    }
  ];

  useEffect(() => {
    const section = sectionRef.current;
    const timeline = timelineRef.current;

    if (section && timeline) {
      const timelineItems = timeline.querySelectorAll('.timeline-item');
      
      gsap.fromTo(timelineItems,
        { x: -100, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.8,
          stagger: 0.3,
          scrollTrigger: {
            trigger: section,
            start: "top 80%",
            end: "bottom 20%",
            toggleActions: "play none none reverse"
          }
        }
      );

      // Animate timeline line
      const timelineLine = timeline.querySelector('.timeline-line');
      if (timelineLine) {
        gsap.fromTo(timelineLine,
          { height: '0%' },
          {
            height: '100%',
            duration: 2,
            scrollTrigger: {
              trigger: section,
              start: "top 80%",
              end: "bottom 20%",
              toggleActions: "play none none reverse"
            }
          }
        );
      }
    }
  }, []);

  return (
    <section id="experience" ref={sectionRef} className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Professional Experience
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300">
            My journey in the world of web development
          </p>
        </div>

        <div ref={timelineRef} className="relative">
          {/* Timeline line */}
          <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gray-300 dark:bg-gray-600">
            <div className="timeline-line absolute top-0 left-0 w-full bg-gradient-to-b from-blue-500 to-purple-600" />
          </div>

          <div className="space-y-12">
            {experiences.map((exp, index) => (
              <div key={index} className="timeline-item relative pl-20">
                {/* Timeline dot */}
                <div className={`absolute left-6 w-4 h-4 bg-gradient-to-r ${exp.color} rounded-full border-4 border-white dark:border-gray-900 shadow-lg`} />
                
                <Card className="shadow-xl hover:shadow-2xl transition-shadow duration-300 bg-white/50 dark:bg-gray-900/50 backdrop-blur-sm border-0">
                  <CardContent className="p-6">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-bold text-gray-800 dark:text-gray-200">
                          {exp.position}
                        </h3>
                        <p className={`text-lg font-semibold bg-gradient-to-r ${exp.color} bg-clip-text text-transparent`}>
                          {exp.company}
                        </p>
                      </div>
                      <span className="text-sm font-medium text-gray-500 dark:text-gray-400 bg-gray-100 dark:bg-gray-800 px-3 py-1 rounded-full mt-2 md:mt-0">
                        {exp.duration}
                      </span>
                    </div>

                    <p className="text-gray-600 dark:text-gray-300 mb-4 leading-relaxed">
                      {exp.description}
                    </p>

                    <div className="flex flex-wrap gap-2">
                      {exp.technologies.map((tech, techIndex) => (
                        <span
                          key={techIndex}
                          className="px-3 py-1 text-xs font-medium bg-gradient-to-r from-blue-100 to-purple-100 dark:from-blue-900 dark:to-purple-900 text-blue-800 dark:text-blue-200 rounded-full"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Experience;
