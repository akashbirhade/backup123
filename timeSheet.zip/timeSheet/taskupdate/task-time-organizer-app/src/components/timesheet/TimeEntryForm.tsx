
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus } from 'lucide-react';
import { toast } from 'sonner';
import { Project } from '@/types/timesheet';

interface TimeEntryFormProps {
  projects: Project[];
  onAddTask: (projectId: string, description: string) => void;
  disabled: boolean;
}

const TimeEntryForm: React.FC<TimeEntryFormProps> = ({ projects, onAddTask, disabled }) => {
  const [selectedProject, setSelectedProject] = useState<string>('');
  const [newTaskDescription, setNewTaskDescription] = useState<string>('');

  const handleAddTask = () => {
    if (!selectedProject || !newTaskDescription) return;
    
    onAddTask(selectedProject, newTaskDescription);
    setNewTaskDescription('');
    toast.success("Task added successfully");
  };

  return (
    <div className="flex flex-1 flex-col sm:flex-row gap-2 w-full">
      <Select value={selectedProject} onValueChange={setSelectedProject} disabled={disabled}>
        <SelectTrigger className="w-full sm:w-[180px]">
          <SelectValue placeholder="Select Project" />
        </SelectTrigger>
        <SelectContent>
          {projects.map(project => (
            <SelectItem key={project.id} value={project.id}>
              {project.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      
      <div className="flex flex-1 gap-2">
        <Input
          placeholder="Task description"
          value={newTaskDescription}
          onChange={(e) => setNewTaskDescription(e.target.value)}
          className="flex-1"
          disabled={disabled}
        />
        <Button 
          onClick={handleAddTask} 
          disabled={disabled || !selectedProject || !newTaskDescription}
        >
          <Plus className="h-4 w-4 mr-1" /> Add Task
        </Button>
      </div>
    </div>
  );
};

export default TimeEntryForm;
