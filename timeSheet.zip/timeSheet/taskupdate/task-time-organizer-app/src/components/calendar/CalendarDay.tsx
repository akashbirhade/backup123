
import { format, isSameDay, isWeekend } from "date-fns";
import { useCalendarStore } from "@/stores/calendarStore";

export interface CalendarDayStyleProps {
  date: Date;
}

export const CalendarDay = ({ date }: CalendarDayStyleProps) => {
  const { calendarEntries, companyHolidays } = useCalendarStore();

  const getEntryForDate = (date: Date) => {
    return calendarEntries.find(entry => isSameDay(entry.date, date));
  };

  const getHolidayForDate = (date: Date) => {
    return companyHolidays.find(holiday => isSameDay(holiday.date, date));
  };

  if (isWeekend(date)) {
    return "bg-blue-100 text-blue-800 hover:bg-blue-200";
  }
  
  const holiday = getHolidayForDate(date);
  if (holiday) {
    return "bg-purple-100 text-purple-800 hover:bg-purple-200";
  }
  
  const entry = getEntryForDate(date);
  if (!entry) return "";
  
  switch (entry.status) {
    case 'complete':
      return "bg-green-100 text-green-800 hover:bg-green-200";
    case 'partial':
      return "bg-amber-100 text-amber-800 hover:bg-amber-200";
    case 'missing':
      return "bg-red-100 text-red-800 hover:bg-red-200";
    default:
      return "";
  }
};
